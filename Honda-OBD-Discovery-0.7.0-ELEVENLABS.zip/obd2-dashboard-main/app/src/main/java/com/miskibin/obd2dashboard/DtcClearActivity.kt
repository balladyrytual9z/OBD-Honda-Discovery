package com.miskibin.obd2dashboard

import android.app.Activity
import android.os.Bundle
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.service.ObdConnectionService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withTimeoutOrNull

/** One-tap, no-screen launcher action. Uses the existing shared BLE/diagnostic owner. */
class DtcClearActivity : Activity() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setBackgroundDrawableResource(android.R.color.transparent)
        runClear()
    }

    private fun runClear() {
        ObdConnectionService.start(applicationContext)
        scope.launch {
            val result = try {
                if (ObdHolder.connection.state.value !is ConnectionState.Connected) {
                    val started = ObdHolder.autoConnect(applicationContext)
                    if (!started) throw IllegalStateException("Brak zapisanego adaptera")
                    val connected = withTimeoutOrNull(20_000L) {
                        ObdHolder.connection.state.firstConnectedOrError()
                    }
                    if (connected !is ConnectionState.Connected) throw IllegalStateException("Nie udało się połączyć z adapterem")
                }
                val accepted = ObdHolder.connection.clearDtcs()
                val after = ObdHolder.connection.refreshDiagnostics()
                when {
                    !accepted -> "NIEPOTWIERDZONE: ECU/adapter nie zaakceptował kasowania; nie uznaję DTC za skasowane."
                    after == null -> "KOMENDA PRZYJĘTA, WERYFIKACJA NIEUDANA: nie udało się ponownie odczytać DTC."
                    after.stored.isEmpty() && after.pending.isEmpty() -> "KASOWANIE PRZYJĘTE: brak zapisanych i oczekujących DTC w ponownym odczycie. Kody trwałe mogą pozostać."
                    else -> "KASOWANIE PRZYJĘTE, POZOSTAŁY DTC: ${after.all.joinToString { it.code }}"
                }
            } catch (e: Exception) {
                "BŁĄD: ${e.message ?: e.javaClass.simpleName}"
            }
            getSharedPreferences("obd_dtc_clear", MODE_PRIVATE).edit()
                .putString("last_result", result)
                .putLong("last_result_at", System.currentTimeMillis())
                .apply()
            sendBroadcast(android.content.Intent(ACTION_RESULT).putExtra("result", result))
            finish()
        }
    }

    override fun onDestroy() { scope.cancel(); super.onDestroy() }

    companion object {
        const val ACTION_CLEAR = "com.miskibin.obd2dashboard.action.CLEAR_DTC"
        const val ACTION_RESULT = "com.miskibin.obd2dashboard.action.DTC_CLEAR_RESULT"
    }
}

private suspend fun StateFlow<ConnectionState>.firstConnectedOrError(): ConnectionState =
    first { it is ConnectionState.Connected || it is ConnectionState.Error }
