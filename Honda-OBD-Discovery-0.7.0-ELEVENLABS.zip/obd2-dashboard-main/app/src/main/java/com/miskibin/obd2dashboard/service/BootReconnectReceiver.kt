package com.miskibin.obd2dashboard.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build

/** Requests the persistent foreground connection owner after radio boot or app update. */
class BootReconnectReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED && intent.action != Intent.ACTION_MY_PACKAGE_REPLACED) return
        val service = Intent(context, ObdConnectionService::class.java).setAction(ObdConnectionService.ACTION_BOOT_RECONNECT)
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(service)
            else context.startService(service)
        }
    }
}
