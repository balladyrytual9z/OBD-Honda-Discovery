package com.miskibin.obd2dashboard.data

import android.content.Context
import org.json.JSONObject
import java.io.File

/** Append-only private JSONL archive of actual app snapshots. No fabricated interpolation. */
object LiveDataArchive {
    private const val FILE_NAME = "obd-live-history.jsonl"
    private val lock = Any()

    fun append(context: Context, record: JSONObject) {
        synchronized(lock) {
            val file = File(context.applicationContext.filesDir, FILE_NAME)
            file.appendText(record.toString() + "\n", Charsets.UTF_8)
        }
    }

    /** Returns real archived records in [millis] window, preserving their original JSON. */
    fun readSince(context: Context, millis: Long, maxRecords: Int = 250): List<JSONObject> {
        val file = File(context.applicationContext.filesDir, FILE_NAME)
        if (!file.isFile) return emptyList()
        return synchronized(lock) {
            val tail = java.util.ArrayDeque<JSONObject>()
            file.useLines(Charsets.UTF_8) { lines ->
                lines.forEach { line ->
                    val record = runCatching { JSONObject(line) }.getOrNull() ?: return@forEach
                    if (record.optLong("emittedAtMillis", 0L) >= millis && maxRecords > 0) {
                        if (tail.size >= maxRecords) tail.removeFirst()
                        tail.addLast(record)
                    }
                }
            }
            tail.toList()
        }
    }

    fun file(context: Context): File = File(context.applicationContext.filesDir, FILE_NAME)

    fun makeExportCopy(context: Context): File? = runCatching {
        val source = file(context)
        if (!source.isFile) return null
        val dir = File(context.applicationContext.cacheDir, "exports").apply { mkdirs() }
        File(dir, "honda-obd-live-history.jsonl").also { target -> source.copyTo(target, overwrite = true) }
    }.getOrNull()
}
