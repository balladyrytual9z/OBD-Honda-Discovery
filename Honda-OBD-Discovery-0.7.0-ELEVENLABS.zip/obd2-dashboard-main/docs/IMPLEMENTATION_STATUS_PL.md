# Honda OBD Discovery — zakres tej paczki i status testów

## Zmiany w tej paczce

- Zachowano istniejący silnik `ConnectionManager`, `Obd2Client`, `PidScheduler` oraz transporty BLE/Classic; nowe funkcje korzystają z tego samego właściciela połączenia.
- Ustawiany w aplikacji interwał automatycznego odświeżania DTC: 1, 2, 5, 10, 15, 30, 60, 120 lub 300 sekund; domyślne 10 s. Odczyty są sekwencyjne i współdzielą blokadę schedulera.
- OpenRouter w ustawieniach: zapis klucza, pobieranie listy modeli, ręczne ID modelu lub wybór z listy, zakres raportu 15 min / 24 h / 7 dni / cała historia / własna liczba godzin oraz generowanie raportu z bieżącego snapshotu i próbek archiwalnych.
- Klucz API jest szyfrowany AES-GCM, a klucz szyfrujący znajduje się w Android Keystore. Nie jest to gwarancja ochrony na urządzeniu skompromitowanym.
- Archiwum LIVE zapisuje snapshoty jako JSONL w prywatnym katalogu aplikacji, bez automatycznego limitu retencji. Eksport archiwum odbywa się przez Android Sharesheet. Raport AI dołącza maksymalnie 250 ostatnich próbek z wybranego zakresu, aby ograniczyć wielkość żądania; lokalny plik nie jest w ten sposób obcinany.
- Broadcast `com.miskibin.obd2dashboard.LIVE_DATA`, schema v2, udostępnia wartości PID, parametry rozszerzone i pochodne, jakość i czas próbek, DTC, Mode 06, readiness, freeze frame, liczniki monitorów, VIN/profil, stan połączenia i listy PID obsługiwanych/nierozkodowanych. Opis integracji i kod odbiornika są w `docs/LIVE_DATA_INTEGRATION_PL.md`.
- Dodano lokalny dziennik tankowań: data, przebieg, litry, koszt, oznaczenie pełnego baku, lista ostatnich tankowań, eksport CSV oraz zużycie liczone metodą pełny bak–pełny bak, gdy istnieją co najmniej dwa prawidłowe punkty.
- Dodano receiver startu systemu i aktualizacji aplikacji, który prosi o uruchomienie usługi foreground i automatyczne połączenie z zapisanym adapterem. Android/ESSGOO nadal może ograniczyć uruchomienie w tle, np. przez ustawienia oszczędzania energii.
- Osobna aktywność launchera „Kasuj DTC” próbuje skasować błędy bez dodatkowego okna, ponownie odczytuje kody i zapisuje status. Wysłanie komendy nie jest samo w sobie traktowane jako potwierdzenie sukcesu.
- Manifest deklaruje dwa rzeczywiste Android App Widgets: Misfire Monitor i Kasuj DTC. Ich wyświetlanie zależy od obsługi widżetów przez launcher ESSGOO.
- Podniesiono wersję aplikacji do `0.7.0` / `versionCode 7`.

## Ograniczenia, które trzeba znać

- „Kasuj DTC” jest osobną aktywnością/pozycją launchera w tym samym APK, a nie osobnym pakietem. To pozwala współdzielić właściciela BLE.
- Broadcast emituje snapshot aplikacji, nie surowe ramki CAN/ELM ani wszystkie dane, jakie hipotetycznie potrafiłoby odczytać narzędzie producenta. PID-y nierozkodowane są raportowane oddzielnie.
- Interwał DTC 1 s jest wartością docelową. Czas odpowiedzi ECU, timeouty i współdzielenie łącza mogą wydłużyć realny cykl.
- Zużycie paliwa z tankowań jest obliczane wyłącznie z przebiegu i wpisanych litrów; nie jest kalibracją ECU. Błędny przebieg lub niepełne tankowania zafałszują wynik.
- Archiwum bezterminowe rośnie wraz z użyciem i może zajmować dużo miejsca. Usunięcie danych aplikacji usuwa również tę historię.
- Broadcast jest globalny, żeby inne aplikacje mogły go odbierać. Nie zawiera klucza API, ale zawiera dane pojazdu i diagnostyki; odbiorniki powinny działać tylko wtedy, gdy potrzebują danych.
- Napięcie przekazywane w feedzie jest wartością widzianą przez warstwę adaptera/OBD i nie musi być bezpośrednim pomiarem napięcia na zaciskach akumulatora.

## Weryfikacja

- Wykonano inspekcję kodu bazowego, kontrolę poprawności XML manifestu/zasobów oraz kontrolę składniową Kotlin bez pełnego classpath (nie zastępuje to kompilacji projektu).
- `./gradlew testDebugUnitTest assembleDebug` nie rozpoczął budowania: środowisko nie mogło rozwiązać `services.gradle.org` przez DNS i pobrać Gradle 8.14.3.
- **Nie potwierdzono kompilacji, przejścia testów jednostkowych ani działania na fizycznym radiu ESSGOO.** Należy uruchomić workflow GitHub Actions i przetestować APK na urządzeniu przed uznaniem nowych funkcji za zweryfikowane.


## ElevenLabs: odczyt raportu w tle (0.7.0)
- Dodano lokalny zapis klucza ElevenLabs jako AES-GCM z kluczem w Android Keystore.
- Ustawienia pobierają głosy z `GET /v1/voices`; użytkownik wybiera głos i zapisuje jego ID.
- Po wygenerowaniu raportu przycisk „Czytaj wygenerowany raport” wysyła tekst do `POST /v1/text-to-speech/{voice_id}` (model `eleven_multilingual_v2`) i odtwarza MP3 w usłudze pierwszoplanowej `mediaPlayback`.
- Usługa działa niezależnie od ekranu ustawień i utrzymuje powiadomienie z akcją „Zatrzymaj”. Odtwarzanie kończy usługę po przeczytaniu całości.
- Wymaga działającego Internetu i planu/kredytów ElevenLabs. Dłuższe raporty są dzielone na części po ok. 4 200 znaków i odtwarzane kolejno, bez celowego ucinania końcówki raportu. Nie zweryfikowano kompilacji Androida ani testu na fizycznym ESSGOO z powodu ograniczeń sieci/środowiska; funkcję trzeba potwierdzić buildem CI i testem urządzenia.
