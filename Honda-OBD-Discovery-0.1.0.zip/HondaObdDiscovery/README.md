# Honda OBD Discovery 0.1.0 (wersja robocza)

Aplikacja OBD dla Hondy Civic VIII (L13Z1) na radio ESSGOO (Android 9, ARMv7). Adapter ELM327 przez **BLE** (obsługuje też klasyczny Bluetooth).

## Jak zbudować APK (z iPhone'a)
1. Na GitHub utwórz nowe repozytorium (np. `honda-obd`).
2. Wgraj do niego CAŁĄ zawartość tego zipa (po rozpakowaniu w Plikach). Ważne, żeby został folder `.github/workflows/`.
3. Wejdź w **Actions → Build APK → Run workflow**.
4. Po kilku minutach otwórz zakończone uruchomienie i pobierz **HondaOBD-apk** (w sekcji Artifacts).
5. Rozpakuj, przerzuć `.apk` na radio i zainstaluj.
6. Jeśli build się nie uda, wyślij mi tekst błędu z logu — poprawię.

## Pierwsze uruchomienie
1. Włącz Bluetooth i lokalizację w radiu (Android 9 wymaga lokalizacji do skanowania BLE).
2. Ekran zegarów → **USTAWIENIA** (stopka) → **Adapter OBD** → **Szukaj adapterów BLE** → wybierz adapter.
3. Włącz zapłon. Status w stopce zmieni się na „OBD OK”.

## Wpisy w launcherze
Honda OBD (też jako pulpit), Kasuj DTC, DTC.

## Co jest zrobione
Połączenie BLE/SPP z automatycznym ponawianiem, inicjalizacja ELM327, wykrywanie obsługiwanych PID-ów, odczyt na żywo, zegary UFO (Canvas), panel w stylu CarPlay z lewym dockiem, dane na żywo, wykresy 1–4, DTC (tryby 03/07/04, bez potwierdzenia), Mode 06 (wartości surowe), Raw Terminal, zapis zdarzeń do CSV, ustawienia, osobny „Kasuj DTC”.

## Czego jeszcze NIE ma
Widżet Androida, baza sesji/historia, eksport JSON, Black Box ciągły, koszt podróży/paliwo, Virtual Dyno, przypomnienia serwisowe, Valet, G-meter, Night Shield, shift light z dźwiękiem, usługa pierwszego planu, ikony parametrów w LCD, przeciąganie kart.

## Uczciwy status
Kod **nie został skompilowany** ani uruchomiony (brak sieci i kompilatora w środowisku, w którym powstał). Nie był testowany na radiu, adapterze ani samochodzie. Pierwszy build na GitHubie może wykazać błędy kompilacji do poprawy.
