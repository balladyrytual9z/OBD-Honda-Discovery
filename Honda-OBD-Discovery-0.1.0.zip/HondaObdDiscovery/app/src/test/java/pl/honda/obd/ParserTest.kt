package pl.honda.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import pl.honda.obd.data.DtcDecoder
import pl.honda.obd.data.Param
import pl.honda.obd.obd.CanParser
import pl.honda.obd.obd.PidDecoder

class ParserTest {
    @Test
    fun singleFrameRpm() {
        val pl = CanParser.payloads("7E8 04 41 0C 1A F8\r\r").first()
        assertEquals(0x41, pl[0])
        assertEquals(1726.0, PidDecoder.decode(Param.RPM, pl)!!, 0.01)
    }

    @Test
    fun singleFrameWithoutSpaces() {
        val pl = CanParser.payloads("7E80341057B\r").first()
        assertEquals(83.0, PidDecoder.decode(Param.ECT, pl)!!, 0.01)
    }

    @Test
    fun multiFrameDtc() {
        val resp = "7E8 10 08 43 02 01 33 01 34\r7E8 21 00 00 00 00 00 00 00\r"
        val pl = CanParser.payloads(resp).first()
        assertEquals(8, pl.size)
        assertEquals("P0133", DtcDecoder.code(pl[2], pl[3]))
        assertEquals("P0134", DtcDecoder.code(pl[4], pl[5]))
    }

    @Test
    fun noDataAndSearchingAreIgnored() {
        assertTrue(CanParser.payloads("SEARCHING...\rNO DATA\r").isEmpty())
        assertTrue(CanParser.hasNoData("NO DATA"))
    }

    @Test
    fun dtcLetters() {
        assertEquals("P0303", DtcDecoder.code(0x03, 0x03))
        assertEquals("C1555", DtcDecoder.code(0x55, 0x55))
        assertEquals("U0100", DtcDecoder.code(0xC1, 0x00))
    }

    @Test
    fun fuelTrim() {
        val pl = intArrayOf(0x41, 0x07, 0x80)
        assertEquals(0.0, PidDecoder.decode(Param.LTFT, pl)!!, 0.001)
    }
}
