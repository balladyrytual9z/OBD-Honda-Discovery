package pl.honda.obd.obd

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import java.io.OutputStream
import java.util.UUID

/** Klasyczny Bluetooth (SPP / RFCOMM) – 3 strategie łączenia. */
class SppTransport(private val device: BluetoothDevice, private val scope: CoroutineScope) : ElmTransport {
    override val incoming = Channel<ByteArray>(Channel.UNLIMITED)
    private var socket: BluetoothSocket? = null
    private var out: OutputStream? = null
    private var reader: Job? = null

    @SuppressLint("MissingPermission")
    override suspend fun open() {
        withContext(Dispatchers.IO) {
            val strategies = listOf<() -> BluetoothSocket>(
                { device.createInsecureRfcommSocketToServiceRecord(SPP_UUID) },
                { device.createRfcommSocketToServiceRecord(SPP_UUID) },
                {
                    device.javaClass.getMethod("createRfcommSocket", Int::class.javaPrimitiveType)
                        .invoke(device, 1) as BluetoothSocket
                }
            )
            var last: Exception? = null
            var ok = false
            for (make in strategies) {
                var sock: BluetoothSocket? = null
                try {
                    sock = make()
                    sock.connect()
                    socket = sock
                    out = sock.outputStream
                    ok = true
                    break
                } catch (e: Exception) {
                    last = e
                    try { sock?.close() } catch (_: Exception) { }
                }
            }
            if (!ok) throw IOException("Nie można połączyć (SPP): " + (last?.message ?: "nieznany błąd"))
            val input = socket!!.inputStream
            reader = scope.launch(Dispatchers.IO) {
                val buf = ByteArray(1024)
                try {
                    while (isActive) {
                        val n = input.read(buf)
                        if (n < 0) break
                        if (n > 0) incoming.trySend(buf.copyOf(n))
                    }
                } catch (_: IOException) {
                } finally {
                    incoming.close()
                }
            }
        }
    }

    override suspend fun write(cmd: String) {
        withContext(Dispatchers.IO) {
            val o = out ?: throw IOException("Gniazdo zamknięte")
            o.write((cmd + "\r").toByteArray(Charsets.US_ASCII))
            o.flush()
        }
    }

    override fun close() {
        reader?.cancel()
        try { socket?.close() } catch (_: Exception) { }
        socket = null
        out = null
        incoming.close()
    }

    companion object {
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }
}
