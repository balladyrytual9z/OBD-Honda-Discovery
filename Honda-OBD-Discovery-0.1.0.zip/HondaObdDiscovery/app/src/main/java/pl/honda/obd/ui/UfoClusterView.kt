package pl.honda.obd.ui

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.os.SystemClock
import android.view.MotionEvent
import android.view.View
import androidx.core.graphics.ColorUtils
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.DtcDecoder
import pl.honda.obd.data.Param
import pl.honda.obd.data.Settings
import pl.honda.obd.data.VehicleSnapshot
import java.util.Locale
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * Tryb "Honda OEM UFO Cluster". Rysowanie w przestrzeni 1280 x 720 skalowanej do widoku.
 * Warstwa statyczna jest cache'owana w bitmapie; w onDraw nie tworzymy obiektów.
 */
class UfoClusterView(ctx: Context) : View(ctx) {

    interface Listener {
        fun onDtcTap()
        fun onSaveEvent()
        fun onSwapUi()
        fun onSettings()
        fun onSpeedTap()
        fun onArcLongPress(left: Boolean)
    }

    var listener: Listener? = null

    companion object {
        const val CX = 640f
        const val CY = 400f
        private val C_BG = Color.parseColor("#0A0D14")
        private val C_FACE = Color.parseColor("#05070B")
        private val C_CREAM = Color.parseColor("#FFFEEA")
        private val C_BLUE = Color.parseColor("#0055FF")
        private val C_CYAN = Color.parseColor("#00E5FF")
        private val C_RED = Color.parseColor("#FF0033")
        private val C_GREEN = Color.parseColor("#30D158")
        private val C_AMBER = Color.parseColor("#FF9F0A")
        private val C_GRAY = Color.parseColor("#8E8E93")
        private val C_METAL1 = Color.parseColor("#2A3448")
        private val C_METAL2 = Color.parseColor("#141B29")
        private val C_LCD_BG = Color.parseColor("#5E6F73")
        private val C_LCD_ON = Color.parseColor("#0D1517")
        private val C_LCD_OFF = Color.parseColor("#526266")
        private val C_PANEL = Color.parseColor("#E2E8E4")
        private val C_TRACK = Color.parseColor("#1A2236")
        private val C_FOOT = Color.parseColor("#0F1420")
        private val REV_THRESH = intArrayOf(3000, 3400, 3800, 4200, 4650, 5100, 5550, 6000, 6125, 6250)
    }

    // ---------------------------------------------------------------- farby/pędzle
    private val tfBold = Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD)
    private val tfReg = Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL)
    private val tfMono = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)

    private fun mk(
        color: Int, size: Float = 0f, tf: Typeface? = null,
        align: Paint.Align = Paint.Align.LEFT,
        style: Paint.Style = Paint.Style.FILL, stroke: Float = 0f
    ): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = color
        if (size > 0f) p.textSize = size
        if (tf != null) p.typeface = tf
        p.textAlign = align
        p.style = style
        p.strokeWidth = stroke
        return p
    }

    private val pFill = mk(Color.BLACK)
    private val pStroke = mk(Color.WHITE, style = Paint.Style.STROKE, stroke = 2f)
    private val pTick = mk(C_CREAM, style = Paint.Style.STROKE, stroke = 2f)
    private val pDigit = mk(C_CREAM, 24f, tfBold, Paint.Align.CENTER).also { it.textSkewX = -0.25f }
    private val pSpeed = mk(Color.WHITE, 96f, tfBold, Paint.Align.RIGHT).also { it.textSkewX = -0.25f }
    private val pSpeedUnit = mk(C_GRAY, 26f, tfBold)
    private val pSmall = mk(C_GRAY, 16f, tfBold, Paint.Align.CENTER)
    private val pArcTrack = mk(C_TRACK, style = Paint.Style.STROKE, stroke = 12f).also { it.strokeCap = Paint.Cap.ROUND }
    private val pArcFill = mk(C_BLUE, style = Paint.Style.STROKE, stroke = 12f).also { it.strokeCap = Paint.Cap.ROUND }
    private val pArcLabel = mk(C_GRAY, 18f, tfBold, Paint.Align.CENTER)
    private val pArcValue = mk(Color.WHITE, 26f, tfMono, Paint.Align.CENTER)
    private val pGlow = mk(C_BLUE, style = Paint.Style.STROKE, stroke = 10f)
    private val pRedZone = mk(C_RED, style = Paint.Style.STROKE, stroke = 5f)
    private val pNeedle = mk(Color.WHITE, style = Paint.Style.STROKE, stroke = 5f).also { it.strokeCap = Paint.Cap.ROUND }
    private val pNeedleGlow = mk(C_BLUE, style = Paint.Style.STROKE, stroke = 11f).also { it.strokeCap = Paint.Cap.ROUND }
    private val pLcdName = mk(C_LCD_ON, 12f, tfBold)
    private val pLcdValue = mk(C_LCD_ON, 38f, tfMono, Paint.Align.RIGHT)
    private val pLcdUnit = mk(C_LCD_ON, 14f, tfBold, Paint.Align.RIGHT)
    private val pLcdInfo = mk(Color.BLACK, 10f, tfReg)
    private val pLcdStat = mk(Color.BLACK, 12f, tfBold)
    private val pFootText = mk(Color.WHITE, 17f, tfBold, Paint.Align.CENTER)
    private val pFootSmall = mk(C_GRAY, 14f, tfReg, Paint.Align.CENTER)
    private val pRev = mk(C_BLUE)
    private val pLens = mk(Color.parseColor("#400022AA"))
    private val pHud = mk(C_GRAY, 20f, tfBold, Paint.Align.CENTER)

    private val rect = RectF()
    private val leftOval = RectF(450f - 240f, CY - 240f, 450f + 240f, CY + 240f)
    private val rightOval = RectF(830f - 240f, CY - 240f, 830f + 240f, CY + 240f)

    // ---------------------------------------------------------------- geometria widoku
    private var scale = 1f
    private var offX = 0f
    private var offY = 0f
    private var staticBmp: Bitmap? = null
    private var lastFrame = 0L

    // ---------------------------------------------------------------- stan danych
    private var snap = VehicleSnapshot()
    private var conn = ConnState.OFFLINE
    private var targetRpm = Float.NaN
    private var needle = 0f
    private var redBlend = 0f
    private var redlineRpm = 6300
    private var speedStr = "---"
    private var speedUnit = "km/h"
    private var revLit = 0
    private var ecoOn = false
    private var vtecOn = false

    private class ArcData {
        var label = ""
        var value = "---"
        var lo = 0f
        var hi = 0f
        var alarm = false
        var has = false
    }

    private val leftArc = ArcData()
    private val rightArc = ArcData()
    private val leftLoop = listOf(Param.ECT, Param.MAP, Param.VOLT)
    private val rightLoop = listOf(Param.FUEL, Param.TPS, Param.IAT, Param.LTFT)
    private var leftIdx = 0
    private var rightIdx = 0
    private var leftOverride: Param? = null
    private var rightOverride: Param? = null

    private val midList: List<Param> = run {
        val first = listOf(Param.MAP, Param.ECT, Param.VOLT, Param.TPS, Param.IAT, Param.LTFT)
        first + Param.values().filter {
            it !in first && it != Param.VOLT_ECU && it != Param.VOLT_ADAPTER
        }
    }
    private var midIdx = 0
    private var lcdParam = Param.MAP
    private var lcdName = "---"
    private var lcdValue = "---"
    private var lcdUnit = ""
    private var lcdMax = "N/A"
    private var lcdAvg = "N/A"
    private var lcdHas = false

    private val nP = Param.values().size
    private val statMax = DoubleArray(nP) { -Double.MAX_VALUE }
    private val statSum = DoubleArray(nP)
    private val statCnt = IntArray(nP)
    private val statLastT = LongArray(nP)

    private var dtcText = "DTC: ---"
    private var dtcColor = C_GRAY
    private var obdText = "OFFLINE"
    private var obdColor = C_GRAY
    private var voltText = "--- V"

    // ---------------------------------------------------------------- aktualizacja danych (poza onDraw)
    fun setData(s: VehicleSnapshot, c: ConnState) {
        snap = s
        conn = c
        redlineRpm = Settings.redlineRpm
        val now = System.currentTimeMillis()

        for (p in Param.values()) {
            val r = s.reading(p) ?: continue
            val i = p.ordinal
            if (r.timeMs != statLastT[i]) {
                statLastT[i] = r.timeMs
                if (r.value > statMax[i]) statMax[i] = r.value
                statSum[i] += r.value
                statCnt[i]++
            }
        }

        val rpm = s.fresh(Param.RPM, now)
        targetRpm = rpm?.toFloat() ?: Float.NaN
        val spd = s.fresh(Param.SPEED, now)
        if (Settings.speedMph) {
            speedUnit = "mph"
            speedStr = if (spd == null) "---" else (spd * 0.621371).roundToInt().toString()
        } else {
            speedUnit = "km/h"
            speedStr = if (spd == null) "---" else spd.roundToInt().toString()
        }
        revLit = if (rpm == null) 0 else REV_THRESH.count { rpm >= it }

        val tps = s.fresh(Param.TPS, now)
        val map = s.fresh(Param.MAP, now)
        ecoOn = rpm != null && tps != null && map != null && tps < 18.0 && map < 48.0 && rpm < 2800.0
        vtecOn = rpm != null && rpm >= Settings.vtecRpm

        val lp = leftOverride ?: pick(leftLoop, leftIdx, s)
        val rp = rightOverride ?: pick(rightLoop, rightIdx, s)
        fillArc(leftArc, lp, s, now)
        fillArc(rightArc, rp, s, now)

        val mp = midList[midIdx % midList.size]
        lcdParam = mp
        lcdName = if (mp == Param.VOLT && s.voltageFromAdapter()) "NAPIĘCIE (ADAPTER)" else mp.label
        lcdUnit = mp.unit
        val mv = s.fresh(mp, now)
        if (mv == null) {
            lcdHas = false
            lcdValue = if (mp in s.unsupported) "N/A" else "---"
            lcdMax = "N/A"
            lcdAvg = "N/A"
        } else {
            lcdHas = true
            lcdValue = fmt(mv, mp.decimals)
            val i = mp.ordinal
            lcdMax = if (statCnt[i] > 0) fmt(statMax[i], mp.decimals) else "N/A"
            lcdAvg = if (statCnt[i] > 0) fmt(statSum[i] / statCnt[i], mp.decimals) else "N/A"
        }

        val codes = s.codes
        if (codes != null && codes.isNotEmpty()) {
            dtcText = codes[0] + " – " + DtcDecoder.describe(codes[0])
            dtcColor = C_RED
        } else if (s.milOn == true) {
            dtcText = "CHECK ENGINE (kody: " + (s.dtcCount ?: 0) + ")"
            dtcColor = C_AMBER
        } else if (s.milOn == false) {
            dtcText = "BRAK BŁĘDÓW"
            dtcColor = C_GREEN
        } else {
            dtcText = "DTC: ---"
            dtcColor = C_GRAY
        }
        when (c) {
            ConnState.CONNECTED -> { obdText = "OBD OK"; obdColor = C_GREEN }
            ConnState.CONNECTING -> { obdText = "CONNECTING…"; obdColor = C_AMBER }
            ConnState.ADAPTER_ONLY -> { obdText = "ADAPTER OK, BRAK ECU"; obdColor = C_AMBER }
            ConnState.ERROR -> { obdText = "BŁĄD POŁĄCZENIA"; obdColor = C_RED }
            ConnState.OFFLINE -> { obdText = "OFFLINE"; obdColor = C_GRAY }
        }
        val vv = s.fresh(Param.VOLT, now)
        voltText = if (vv == null) "--- V" else fmt(vv, 1) + " V" + (if (s.voltageFromAdapter()) " (adapter)" else "")
    }

    private fun fmt(v: Double, d: Int): String = String.format(Locale.US, "%." + d + "f", v)

    private fun pick(loop: List<Param>, idx: Int, s: VehicleSnapshot): Param {
        for (k in loop.indices) {
            val p = loop[(idx + k) % loop.size]
            if (p !in s.unsupported) return p
        }
        return loop[idx % loop.size]
    }

    private fun shortName(p: Param): String = when (p) {
        Param.ECT -> "ECT"
        Param.MAP -> "MAP"
        Param.VOLT -> "VOLT"
        Param.FUEL -> "PALIWO"
        Param.TPS -> "TPS"
        Param.IAT -> "IAT"
        Param.LTFT -> "LTFT"
        else -> p.label
    }

    private fun isAlarm(p: Param, v: Double): Boolean = when (p) {
        Param.ECT -> v > Settings.ectAlarm
        Param.IAT -> v > Settings.iatAlarm
        Param.VOLT, Param.VOLT_ECU, Param.VOLT_ADAPTER -> v < Settings.voltLow || v > Settings.voltHigh
        Param.LTFT -> abs(v) > Settings.ltftLimit
        else -> false
    }

    private fun fillArc(a: ArcData, p: Param, s: VehicleSnapshot, now: Long) {
        a.label = shortName(p)
        val v = s.fresh(p, now)
        if (v == null) {
            a.has = false
            a.value = if (p in s.unsupported) "N/A" else "---"
            a.lo = 0f
            a.hi = 0f
            a.alarm = false
            return
        }
        a.has = true
        a.value = fmt(v, p.decimals) + " " + p.unit
        val f = ((v - p.min) / (p.max - p.min)).coerceIn(0.0, 1.0).toFloat()
        if (p.bidirectional) {
            a.lo = min(0.5f, f)
            a.hi = max(0.5f, f)
        } else {
            a.lo = 0f
            a.hi = f
        }
        a.alarm = isAlarm(p, v)
    }

    fun setArcParam(left: Boolean, p: Param) {
        if (left) leftOverride = p else rightOverride = p
        setData(snap, conn)
    }

    // ---------------------------------------------------------------- układ widoku
    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w <= 0 || h <= 0) return
        scale = min(w / 1280f, h / 720f)
        offX = (w - 1280f * scale) / 2f
        offY = (h - 720f * scale) / 2f
        staticBmp?.recycle()
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(C_BG)
        c.translate(offX, offY)
        c.scale(scale, scale)
        buildShaders()
        drawStatic(c)
        staticBmp = bmp
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        staticBmp?.recycle()
        staticBmp = null
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) invalidate()
    }

    private var leftShader: Shader? = null
    private var rightShader: Shader? = null

    private fun buildShaders() {
        // lewy łuk zajmuje kąty 108°–252° (pozycje 0.30–0.70), prawy 288°–72° przez 0°
        val mid = ColorUtils.blendARGB(C_BLUE, C_CYAN, 0.5f)
        leftShader = SweepGradient(
            450f, CY, intArrayOf(C_BLUE, C_BLUE, C_CYAN, C_CYAN), floatArrayOf(0f, 0.30f, 0.70f, 1f)
        )
        rightShader = SweepGradient(
            830f, CY, intArrayOf(mid, C_BLUE, C_CYAN, mid), floatArrayOf(0f, 0.20f, 0.80f, 1f)
        )
    }

    private fun drawStatic(c: Canvas) {
        // soczewka pod prędkością
        rect.set(480f, 138f, 800f, 168f)
        c.drawOval(rect, pLens)

        // szczeliny paska REV
        pFill.color = C_TRACK
        for (i in 0 until 10) {
            val x = 440f + i * 40f
            rect.set(x, 14f, x + 36f, 38f)
            c.drawRect(rect, pFill)
        }

        // obrotomierz: metaliczny pierścień i tarcza
        pFill.shader = LinearGradient(420f, 180f, 860f, 620f, C_METAL1, C_METAL2, Shader.TileMode.CLAMP)
        c.drawCircle(CX, CY, 220f, pFill)
        pFill.shader = null
        pFill.color = C_FACE
        c.drawCircle(CX, CY, 212f, pFill)

        // podziałki
        for (i in 0..80) {
            val rpm = i * 100
            val ang = Math.toRadians(135.0 + 270.0 * rpm / 8000.0).toFloat()
            val major = rpm % 1000 == 0
            val med = rpm % 500 == 0
            val len = if (major) 14f else if (med) 10f else 5f
            pTick.strokeWidth = if (major) 3f else if (med) 2f else 1.2f
            val cs = cos(ang)
            val sn = sin(ang)
            c.drawLine(CX + cs * 206f, CY + sn * 206f, CX + cs * (206f - len), CY + sn * (206f - len), pTick)
        }
        // cyfry 1–8 (pochylone, nieobrócone)
        for (k in 1..8) {
            val ang = Math.toRadians(135.0 + 270.0 * k / 8.0).toFloat()
            c.drawText(k.toString(), CX + cos(ang) * 180f, CY + sin(ang) * 180f + 8f, pDigit)
        }
        c.drawText("x1000 obr/min", CX, 560f, pSmall)

        // LCD MID: ramka, tło, separator, panel statystyk
        pFill.color = C_METAL1
        c.drawRect(528f, 288f, 752f, 512f, pFill)
        pFill.color = C_LCD_BG
        c.drawRect(530f, 290f, 750f, 510f, pFill)
        pFill.color = C_LCD_ON
        c.drawRect(530f, 399f, 750f, 401f, pFill)
        pFill.color = C_PANEL
        c.drawRect(538f, 408f, 742f, 504f, pFill)

        // tory łuków bocznych
        c.drawArc(leftOval, 108f, 144f, false, pArcTrack)
        c.drawArc(rightOval, -72f, 144f, false, pArcTrack)

        // stopka
        pFill.color = C_FOOT
        c.drawRect(0f, 640f, 1280f, 720f, pFill)
        pFill.color = C_METAL1
        for (k in 0..5) c.drawRect(k * 256f - 1f, 640f, k * 256f + 1f, 720f, pFill)
        c.drawRect(0f, 639f, 1280f, 641f, pFill)
        c.drawText("ZAPISZ EVENT", 256f * 1.5f, 688f, pFootText)
        c.drawText("SWAP UI", 256f * 2.5f, 688f, pFootText)
        c.drawText("USTAWIENIA", 256f * 3.5f, 688f, pFootText)
    }

    // ---------------------------------------------------------------- rysowanie dynamiczne
    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        var dt = if (lastFrame == 0L) 0.016f else (now - lastFrame) / 1000f
        if (dt > 0.1f) dt = 0.1f
        lastFrame = now

        // interpolacja niezależna od FPS
        val goal = if (targetRpm.isNaN()) 0f else targetRpm
        needle += (goal - needle) * (1f - exp(-dt / 0.07f))
        val inRed = !targetRpm.isNaN() && targetRpm >= redlineRpm
        redBlend += ((if (inRed) 1f else 0f) - redBlend) * (1f - exp(-dt / 0.15f))

        canvas.drawColor(C_BG)
        val bmp = staticBmp
        if (bmp != null) canvas.drawBitmap(bmp, 0f, 0f, null)
        canvas.save()
        canvas.translate(offX, offY)
        canvas.scale(scale, scale)
        drawDynamic(canvas, now)
        canvas.restore()

        if (isShown) postInvalidateOnAnimation()
    }

    private fun drawDynamic(c: Canvas, now: Long) {
        val accent = ColorUtils.blendARGB(C_BLUE, C_RED, redBlend)

        // REV
        val flash = !targetRpm.isNaN() && targetRpm >= redlineRpm
        val flashOn = (now / 150L) % 2L == 0L
        for (i in 0 until 10) {
            val lit = if (flash) flashOn else i < revLit
            if (!lit) continue
            pRev.color = if (flash) C_RED else if (i < 4) C_CYAN else if (i < 8) C_GREEN else C_AMBER
            val x = 440f + i * 40f
            rect.set(x, 14f, x + 36f, 38f)
            c.drawRect(rect, pRev)
        }
        pHud.color = if (ecoOn) C_GREEN else C_TRACK
        c.drawText("ECO", 400f, 36f, pHud)
        pHud.color = if (vtecOn) C_CYAN else C_TRACK
        c.drawText("VTEC", 880f, 36f, pHud)

        // prędkość i bieg
        c.drawText(speedStr, 690f, 142f, pSpeed)
        c.drawText(speedUnit, 702f, 142f, pSpeedUnit)
        c.drawText("BIEG", 930f, 80f, pSmall)
        pHud.color = C_LCD_OFF
        c.drawText("N/A", 930f, 130f, pHud)

        // poświata i strefa Redline
        pGlow.color = ColorUtils.setAlphaComponent(accent, 110)
        c.drawCircle(CX, CY, 226f, pGlow)
        rect.set(CX - 213f, CY - 213f, CX + 213f, CY + 213f)
        val redStart = 135f + 270f * redlineRpm / 8000f
        c.drawArc(rect, redStart, 405f - redStart, false, pRedZone)

        // wskazówka
        if (!targetRpm.isNaN()) {
            val ang = Math.toRadians(135.0 + 270.0 * needle.coerceIn(0f, 8000f) / 8000.0).toFloat()
            val cs = cos(ang)
            val sn = sin(ang)
            pNeedleGlow.color = ColorUtils.setAlphaComponent(accent, 150)
            pNeedle.color = ColorUtils.blendARGB(Color.WHITE, C_RED, redBlend)
            c.drawLine(CX + cs * 162f, CY + sn * 162f, CX + cs * 204f, CY + sn * 204f, pNeedleGlow)
            c.drawLine(CX + cs * 162f, CY + sn * 162f, CX + cs * 204f, CY + sn * 204f, pNeedle)
        }

        // LCD MID
        val on = if (lcdHas) C_LCD_ON else C_LCD_OFF
        pLcdName.color = on
        pLcdValue.color = on
        pLcdUnit.color = on
        c.drawText(lcdName, 540f, 312f, pLcdName)
        c.drawText(lcdUnit, 738f, 384f, pLcdUnit)
        c.drawText(lcdValue, 738f - pLcdUnit.measureText(lcdUnit) - 4f, 384f, pLcdValue)
        c.drawText("od resetu", 546f, 432f, pLcdInfo)
        c.drawText("(" + lcdUnit + ")", 546f, 446f, pLcdInfo)
        pLcdStat.color = C_BLUE
        c.drawText("MAX: " + lcdMax, 630f, 444f, pLcdStat)
        pLcdStat.color = Color.BLACK
        c.drawText("AVG: " + lcdAvg, 630f, 478f, pLcdStat)

        // łuki boczne
        drawArc(c, leftArc, true)
        drawArc(c, rightArc, false)

        // stopka: DTC i status OBD
        pFootText.color = dtcColor
        pFootText.textSize = 15f
        c.drawText(clip(dtcText, 28), 128f, 684f, pFootText)
        pFootText.textSize = 17f
        pFootText.color = obdColor
        c.drawText(obdText, 256f * 4.5f, 676f, pFootText)
        c.drawText(voltText, 256f * 4.5f, 702f, pFootSmall)
        pFootText.color = Color.WHITE
    }

    private fun clip(s: String, n: Int): String = if (s.length <= n) s else s.substring(0, n - 1) + "…"

    private fun drawArc(c: Canvas, a: ArcData, left: Boolean) {
        val oval = if (left) leftOval else rightOval
        if (a.has && a.hi > a.lo) {
            if (a.alarm) {
                pArcFill.shader = null
                pArcFill.color = C_RED
            } else {
                pArcFill.shader = if (left) leftShader else rightShader
            }
            if (left) {
                c.drawArc(oval, 108f + 144f * a.lo, 144f * (a.hi - a.lo), false, pArcFill)
            } else {
                c.drawArc(oval, 72f - 144f * a.hi, 144f * (a.hi - a.lo), false, pArcFill)
            }
            pArcFill.shader = null
        }
        val x = if (left) 305f else 975f
        pArcLabel.color = C_GRAY
        c.drawText(a.label, x, 380f, pArcLabel)
        pArcValue.color = if (a.alarm) C_RED else if (a.has) Color.WHITE else C_GRAY
        c.drawText(a.value, x, 416f, pArcValue)
    }

    // ---------------------------------------------------------------- dotyk
    private var downX = 0f
    private var downY = 0f
    private var longFired = false
    private val longRunnable = Runnable {
        longFired = true
        onLong(downX, downY)
    }

    private fun inRect(x: Float, y: Float, l: Float, t: Float, r: Float, b: Float) = x >= l && x <= r && y >= t && y <= b

    private fun longMs(x: Float, y: Float): Long = when {
        inRect(x, y, 538f, 408f, 742f, 504f) -> 1500L
        inRect(x, y, 210f, 160f, 390f, 640f) -> 1000L
        inRect(x, y, 890f, 160f, 1070f, 640f) -> 1000L
        else -> 0L
    }

    private fun onLong(x: Float, y: Float) {
        when {
            inRect(x, y, 538f, 408f, 742f, 504f) -> {
                val i = lcdParam.ordinal
                statMax[i] = -Double.MAX_VALUE
                statSum[i] = 0.0
                statCnt[i] = 0
                setData(snap, conn)
            }
            inRect(x, y, 210f, 160f, 390f, 640f) -> listener?.onArcLongPress(true)
            inRect(x, y, 890f, 160f, 1070f, 640f) -> listener?.onArcLongPress(false)
        }
    }

    private fun onTap(x: Float, y: Float) {
        when {
            y >= 640f -> when ((x / 256f).toInt()) {
                0 -> listener?.onDtcTap()
                1 -> listener?.onSaveEvent()
                2 -> listener?.onSwapUi()
                3 -> listener?.onSettings()
                else -> { }
            }
            inRect(x, y, 530f, 290f, 750f, 510f) -> {
                for (k in 1..midList.size) {
                    val i = (midIdx + k) % midList.size
                    if (midList[i] !in snap.unsupported) { midIdx = i; break }
                }
                setData(snap, conn)
            }
            inRect(x, y, 210f, 160f, 390f, 640f) -> {
                leftOverride = null
                leftIdx = (leftIdx + 1) % leftLoop.size
                setData(snap, conn)
            }
            inRect(x, y, 890f, 160f, 1070f, 640f) -> {
                rightOverride = null
                rightIdx = (rightIdx + 1) % rightLoop.size
                setData(snap, conn)
            }
            inRect(x, y, 400f, 40f, 900f, 170f) -> listener?.onSpeedTap()
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        val vx = (e.x - offX) / scale
        val vy = (e.y - offY) / scale
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downX = vx
                downY = vy
                longFired = false
                val ms = longMs(vx, vy)
                if (ms > 0L) postDelayed(longRunnable, ms)
            }
            MotionEvent.ACTION_MOVE -> {
                if (abs(vx - downX) > 30f || abs(vy - downY) > 30f) removeCallbacks(longRunnable)
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longRunnable)
                if (!longFired) onTap(vx, vy)
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longRunnable)
        }
        return true
    }
}
