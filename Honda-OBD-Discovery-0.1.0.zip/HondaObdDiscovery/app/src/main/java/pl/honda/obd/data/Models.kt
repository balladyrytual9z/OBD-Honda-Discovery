package pl.honda.obd.data

enum class ConnState { OFFLINE, CONNECTING, ADAPTER_ONLY, CONNECTED, ERROR }

enum class Param(
    val label: String,
    val unit: String,
    val pid: Int,
    val tier: Int,
    val decimals: Int,
    val min: Double,
    val max: Double,
    val bidirectional: Boolean = false
) {
    RPM("OBROTY", "obr/min", 0x0C, 0, 0, 0.0, 8000.0),
    SPEED("PRĘDKOŚĆ", "km/h", 0x0D, 0, 0, 0.0, 220.0),
    TPS("PRZEPUSTNICA", "%", 0x11, 1, 0, 0.0, 100.0),
    MAP("CIŚNIENIE MAP", "kPa", 0x0B, 1, 0, 0.0, 110.0),
    LOAD("OBCIĄŻENIE", "%", 0x04, 1, 0, 0.0, 100.0),
    LAMBDA("LAMBDA", "λ", 0x34, 1, 2, 0.7, 1.3),
    ECT("TEMP. PŁYNU", "°C", 0x05, 2, 0, 40.0, 120.0),
    IAT("TEMP. SSANIA", "°C", 0x0F, 2, 0, -20.0, 80.0),
    STFT("KOREKTA KRÓTKA", "%", 0x06, 2, 1, -25.0, 25.0, true),
    LTFT("KOREKTA DŁUGA", "%", 0x07, 2, 1, -25.0, 25.0, true),
    TIMING("KĄT ZAPŁONU", "°", 0x0E, 2, 1, -20.0, 60.0),
    BARO("CIŚN. BARO", "kPa", 0x33, 2, 0, 60.0, 110.0),
    FUEL("POZIOM PALIWA", "%", 0x2F, 2, 0, 0.0, 100.0),
    OIL("TEMP. OLEJU", "°C", 0x5C, 2, 0, 40.0, 140.0),
    VOLT_ECU("NAPIĘCIE ECU", "V", 0x42, 2, 1, 10.0, 16.0),
    VOLT_ADAPTER("NAPIĘCIE (ADAPTER)", "V", -1, 3, 1, 10.0, 16.0),
    VOLT("NAPIĘCIE", "V", -1, 3, 1, 10.0, 16.0);

    val isPid: Boolean get() = pid >= 0
}

data class Reading(val value: Double, val timeMs: Long)

data class Sample(val t: Long, val v: Double)

data class VehicleSnapshot(
    val readings: Map<Param, Reading> = emptyMap(),
    val unsupported: Set<Param> = emptySet(),
    val milOn: Boolean? = null,
    val dtcCount: Int? = null,
    val codes: List<String>? = null
) {
    private fun maxAge(p: Param): Long = when (p.tier) {
        0 -> 3000L
        1 -> 6000L
        2 -> 20000L
        else -> 15000L
    }

    /** Napięcie: ECU jeśli jest świeże, w przeciwnym razie napięcie adaptera. */
    fun reading(p: Param): Reading? {
        if (p != Param.VOLT) return readings[p]
        val e = readings[Param.VOLT_ECU]
        if (e != null && System.currentTimeMillis() - e.timeMs <= maxAge(Param.VOLT_ECU)) return e
        return readings[Param.VOLT_ADAPTER]
    }

    fun voltageFromAdapter(): Boolean {
        val e = readings[Param.VOLT_ECU]
        return !(e != null && System.currentTimeMillis() - e.timeMs <= maxAge(Param.VOLT_ECU))
    }

    /** Wartość tylko jeśli świeża; null = brak danych lub dane nieaktualne. */
    fun fresh(p: Param, now: Long = System.currentTimeMillis()): Double? {
        val r = reading(p) ?: return null
        return if (now - r.timeMs <= maxAge(p)) r.value else null
    }

    fun isStale(p: Param): Boolean = reading(p) != null && fresh(p) == null
}
