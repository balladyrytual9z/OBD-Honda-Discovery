package pl.honda.obd

import android.app.Application
import pl.honda.obd.data.Settings
import pl.honda.obd.obd.ObdEngine

class ObdApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Settings.init(this)
        ObdEngine.init(this)
        ObdEngine.start()
    }
}
