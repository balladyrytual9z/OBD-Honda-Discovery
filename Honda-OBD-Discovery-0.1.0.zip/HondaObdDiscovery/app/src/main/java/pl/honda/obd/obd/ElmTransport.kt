package pl.honda.obd.obd

import kotlinx.coroutines.channels.Channel

/** Wspólny interfejs transportu do adaptera ELM327 (klasyczny SPP albo BLE). */
interface ElmTransport {
    /** Surowe bajty przychodzące z adaptera. Kanał zamyka się przy zerwaniu połączenia. */
    val incoming: Channel<ByteArray>

    /** Otwiera połączenie; rzuca IOException przy niepowodzeniu. */
    suspend fun open()

    /** Wysyła komendę (dopisuje \r). */
    suspend fun write(cmd: String)

    fun close()
}
