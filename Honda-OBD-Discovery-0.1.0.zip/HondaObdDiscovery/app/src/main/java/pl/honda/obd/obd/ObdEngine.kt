package pl.honda.obd.obd

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.DtcDecoder
import pl.honda.obd.data.ObdRepository
import pl.honda.obd.data.Param
import pl.honda.obd.data.Settings
import java.io.IOException

data class DtcResult(val stored: List<String>?, val pending: List<String>?, val error: String?)

object ObdEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null

    private lateinit var appCtx: Context
    @Volatile private var session: ElmSession? = null
    @Volatile private var transport: ElmTransport? = null
    @Volatile private var supportedPids: Set<Int> = emptySet()

    private sealed class Q {
        class Ok(val v: Double) : Q()
        object NoData : Q()
        object Timeout : Q()
    }

    fun init(ctx: Context) {
        appCtx = ctx.applicationContext
    }

    fun start() {
        if (job?.isActive == true) return
        job = scope.launch { runLoop() }
    }

    fun restart() {
        job?.cancel()
        closeLink()
        job = scope.launch { runLoop() }
    }

    private fun closeLink() {
        try { session?.close() } catch (_: Exception) { }
        try { transport?.close() } catch (_: Exception) { }
        session = null
        transport = null
    }

    // ------------------------------------------------------------------ pętla główna

    private suspend fun runLoop() {
        var attempt = 0
        while (currentCoroutineContext().isActive) {
            val mac = Settings.adapterMac
            if (mac.isNullOrBlank()) {
                ObdRepository.setState(ConnState.OFFLINE, "Nie wybrano adaptera (Ustawienia)")
                delay(2000)
                continue
            }
            ObdRepository.setState(ConnState.CONNECTING, "Łączenie z adapterem…")
            try {
                link(mac) { attempt = 0 }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ObdRepository.setState(ConnState.ERROR, e.message ?: "Błąd połączenia")
            }
            closeLink()
            val wait = minOf(30_000L, 1000L shl minOf(attempt, 5))
            attempt++
            delay(wait)
        }
    }

    private suspend fun openTransport(dev: BluetoothDevice, kind: String): ElmTransport {
        suspend fun spp(): ElmTransport {
            val t = SppTransport(dev, scope)
            try { t.open() } catch (e: Exception) { t.close(); throw e }
            return t
        }
        suspend fun ble(): ElmTransport {
            val t = BleTransport(appCtx, dev, scope)
            try { t.open() } catch (e: Exception) { t.close(); throw e }
            return t
        }
        return when (kind) {
            "spp" -> spp()
            "ble" -> ble()
            else -> try {
                spp()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ble()
            }
        }
    }

    private suspend fun link(mac: String, onConnected: () -> Unit) {
        val ba = BluetoothAdapter.getDefaultAdapter() ?: throw IOException("Brak Bluetooth w urządzeniu")
        if (!ba.isEnabled) throw IOException("Bluetooth jest wyłączony")
        val dev = ba.getRemoteDevice(mac)
        ba.cancelDiscovery()
        val t = openTransport(dev, Settings.adapterKind)
        transport = t
        val s = ElmSession(t)
        session = s
        onConnected()
        initAdapter(s)
        ObdRepository.setState(ConnState.ADAPTER_ONLY, "Adapter połączony – czekam na ECU (włącz zapłon)")
        while (currentCoroutineContext().isActive) {
            if (!establishEcu(s)) {
                delay(2500)
                continue
            }
            pollLoop(s)
            ObdRepository.setState(ConnState.ADAPTER_ONLY, "ECU nie odpowiada (zapłon wyłączony?)")
        }
    }

    private suspend fun initAdapter(s: ElmSession) {
        ObdRepository.setState(ConnState.CONNECTING, "Inicjalizacja ELM327…")
        val z = s.command("ATZ", 6000)
        val e = s.command("ATE0", 3000)
        if (z == null && e == null) throw IOException("Adapter nie odpowiada na komendy ELM327")
        // ATL0 bez linefeedów, ATS0 bez spacji, ATH1 nagłówki CAN (potrzebne do składania ramek),
        // ATSP0 automatyczny protokół (konfiguracja, która działała wcześniej), ATAT1 adaptacyjny timing
        for (c in listOf("ATL0", "ATS0", "ATH1", "ATSP0", "ATAT1")) s.command(c, 3000)
        val info = s.command("ATI", 2000)
        ObdRepository.adapterInfo.value = info?.replace('\r', ' ')?.replace('\n', ' ')?.trim() ?: ""
    }

    // ------------------------------------------------------------------ ECU

    private suspend fun establishEcu(s: ElmSession): Boolean {
        var mask = parseMask(s.command("0100", 9000), 0x00)
        if (mask == null) {
            s.command("ATSP6", 3000)   // Honda Civic VIII: ISO 15765-4, 11 bit, 500 kbaud
            mask = parseMask(s.command("0100", 12000), 0x00)
            if (mask == null) {
                s.command("ATSP0", 3000)
                readAdapterVoltage(s)
                return false
            }
        }
        val sup = HashSet<Int>()
        addMask(sup, 0x00, mask)
        if (0x20 in sup) parseMask(s.command("0120", 4000), 0x20)?.let { addMask(sup, 0x20, it) }
        if (0x40 in sup) parseMask(s.command("0140", 4000), 0x40)?.let { addMask(sup, 0x40, it) }
        supportedPids = sup
        ObdRepository.setUnsupported(Param.values().filter { it.isPid && it.pid !in sup }.toSet())
        ObdRepository.setState(ConnState.CONNECTED, "OBD OK")
        return true
    }

    private fun parseMask(resp: String?, base: Int): Long? {
        if (resp == null) return null
        val pl = CanParser.payloads(resp).firstOrNull { it.size >= 6 && it[0] == 0x41 && it[1] == base } ?: return null
        return (pl[2].toLong() shl 24) or (pl[3].toLong() shl 16) or (pl[4].toLong() shl 8) or pl[5].toLong()
    }

    private fun addMask(out: MutableSet<Int>, base: Int, mask: Long) {
        for (k in 0 until 32) {
            if (((mask shr (31 - k)) and 1L) == 1L) out.add(base + k + 1)
        }
    }

    // ------------------------------------------------------------------ odpytywanie

    private suspend fun pollLoop(s: ElmSession) {
        val sup = supportedPids
        val byTier = Param.values().filter { it.isPid && it.pid in sup }.groupBy { it.tier }
        var lastMid = 0L
        var lastSlow = 0L
        var lastMil = 0L
        var lastVolt = 0L
        var timeouts = 0
        var noDataStreak = 0
        var rpm: Double? = null
        var volt: Double? = null

        while (currentCoroutineContext().isActive) {
            val now = SystemClock.elapsedRealtime()

            if (now - lastVolt > 2000) {
                val v = readAdapterVoltage(s)
                if (v != null) volt = v
                lastVolt = now
            }
            val vNow = volt
            val rNow = rpm
            // Ochrona rozruchu: napięcie < 11 V lub obroty 1–450 -> tylko szybkie PID-y
            val cranking = (vNow != null && vNow < 11.0) || (rNow != null && rNow >= 1.0 && rNow <= 450.0)

            val batch = ArrayList<Param>()
            batch.addAll(byTier[0].orEmpty())
            if (!cranking) {
                if (now - lastMid >= 500) { batch.addAll(byTier[1].orEmpty()); lastMid = now }
                if (now - lastSlow >= 2000) { batch.addAll(byTier[2].orEmpty()); lastSlow = now }
            }

            for (p in batch) {
                when (val r = queryParam(s, p)) {
                    is Q.Ok -> {
                        timeouts = 0
                        noDataStreak = 0
                        ObdRepository.put(p, r.v)
                        if (p == Param.RPM) rpm = r.v
                    }
                    Q.NoData -> noDataStreak++
                    Q.Timeout -> {
                        timeouts++
                        if (timeouts >= 5) throw IOException("Adapter przestał odpowiadać")
                    }
                }
            }
            if (noDataStreak >= 12) return   // ECU milczy (zapłon wyłączony) – wróć do oczekiwania

            if (!cranking && now - lastMil >= 5000) {
                refreshMil(s)
                lastMil = now
            }
            yield()
        }
    }

    private suspend fun queryParam(s: ElmSession, p: Param): Q {
        val resp = s.command("01" + "%02X".format(p.pid), 2500) ?: return Q.Timeout
        val pl = CanParser.payloads(resp).firstOrNull { it.size >= 3 && it[0] == 0x41 && it[1] == p.pid }
            ?: return Q.NoData
        val v = PidDecoder.decode(p, pl) ?: return Q.NoData
        return Q.Ok(v)
    }

    private suspend fun readAdapterVoltage(s: ElmSession): Double? {
        val resp = s.command("ATRV", 1500) ?: return null
        val m = Regex("(\\d+(?:\\.\\d+)?)").find(resp) ?: return null
        val v = m.groupValues[1].toDoubleOrNull() ?: return null
        if (v < 5.0 || v > 20.0) return null
        ObdRepository.put(Param.VOLT_ADAPTER, v)
        return v
    }

    private suspend fun refreshMil(s: ElmSession) {
        val resp = s.command("0101", 2500) ?: return
        val pl = CanParser.payloads(resp).firstOrNull { it.size >= 3 && it[0] == 0x41 && it[1] == 0x01 } ?: return
        ObdRepository.setMil((pl[2] and 0x80) != 0, pl[2] and 0x7F)
    }

    // ------------------------------------------------------------------ DTC i diagnostyka

    private fun ecuReady(): String? {
        if (session == null) return "Brak połączenia z adapterem"
        if (ObdRepository.connState.value != ConnState.CONNECTED) return "ECU nie odpowiada (włącz zapłon)"
        return null
    }

    suspend fun readDtcs(): DtcResult {
        ecuReady()?.let { return DtcResult(null, null, it) }
        val s = session ?: return DtcResult(null, null, "Brak połączenia z adapterem")
        return try {
            val st = readCodes(s, "03", 0x43)
            val pe = readCodes(s, "07", 0x47)
            if (st != null) ObdRepository.setCodes(st)
            refreshMil(s)
            DtcResult(st, pe, if (st == null) "Brak odpowiedzi ECU na odczyt kodów" else null)
        } catch (e: IOException) {
            DtcResult(null, null, e.message ?: "Błąd łącza")
        }
    }

    private suspend fun readCodes(s: ElmSession, mode: String, ok: Int): List<String>? {
        val resp = s.command(mode, 6000) ?: return null
        val pls = CanParser.payloads(resp)
        val out = ArrayList<String>()
        var any = false
        for (pl in pls) {
            if (pl.isEmpty() || pl[0] != ok) continue
            any = true
            var i = 2 // pomiń kod usługi i licznik kodów
            while (i + 1 < pl.size) {
                val a = pl[i]
                val b = pl[i + 1]
                i += 2
                if (a == 0 && b == 0) continue
                out.add(DtcDecoder.code(a, b))
            }
        }
        if (any) return out.distinct()
        return if (resp.uppercase().contains("NO DATA")) emptyList() else null
    }

    /** Kasuje DTC natychmiast (bez potwierdzeń) i odczytuje status ponownie. */
    suspend fun clearDtcs(): String {
        ecuReady()?.let { return it }
        val s = session ?: return "Brak połączenia z adapterem"
        return try {
            val resp = s.command("04", 8000) ?: return "Adapter nie odpowiedział"
            val ok = CanParser.payloads(resp).any { it.isNotEmpty() && it[0] == 0x44 }
            if (!ok) return "ECU nie potwierdziło kasowania (np. silnik pracuje lub brak zgody ECU)"
            refreshMil(s)
            val codes = readCodes(s, "03", 0x43)
            if (codes != null) ObdRepository.setCodes(codes)
            "Skasowano. Po ponownym odczycie kodów: " + (codes?.size?.toString() ?: "brak danych")
        } catch (e: IOException) {
            e.message ?: "Błąd łącza"
        }
    }

    /** Mode 06 – surowe wyniki testów dla danego MID (bez interpretacji). */
    suspend fun readMode06(mid: Int): List<String> {
        ecuReady()?.let { return listOf(it) }
        val s = session ?: return listOf("Brak połączenia z adapterem")
        return try {
            val resp = s.command("06" + "%02X".format(mid), 6000) ?: return listOf("Brak odpowiedzi")
            val pl = CanParser.payloads(resp).firstOrNull { it.size >= 2 && it[0] == 0x46 && it[1] == mid }
                ?: return listOf("MID " + "%02X".format(mid) + ": niedostępne w tym ECU")
            val out = ArrayList<String>()
            var i = 2
            while (i + 7 < pl.size) {
                val tid = pl[i]
                val value = pl[i + 2] * 256 + pl[i + 3]
                val min = pl[i + 4] * 256 + pl[i + 5]
                val max = pl[i + 6] * 256 + pl[i + 7]
                out.add("TID " + "%02X".format(tid) + ": wartość " + value + " (min " + min + ", max " + max + ")")
                i += 8
            }
            if (out.isEmpty()) listOf("Brak wyników testu") else out
        } catch (e: IOException) {
            listOf(e.message ?: "Błąd łącza")
        }
    }

    suspend fun readVin(): String? {
        if (ecuReady() != null) return null
        val s = session ?: return null
        return try {
            val resp = s.command("0902", 6000) ?: return null
            val pl = CanParser.payloads(resp).firstOrNull { it.size > 3 && it[0] == 0x49 && it[1] == 0x02 } ?: return null
            val chars = StringBuilder()
            for (i in 3 until pl.size) {
                val c = pl[i].toChar()
                if (c.isLetterOrDigit()) chars.append(c)
            }
            if (chars.length >= 11) chars.toString() else null
        } catch (e: IOException) {
            null
        }
    }

    private val rawAllowed = listOf("AT", "01", "02", "03", "06", "07", "09", "0A")

    /** Ręczne polecenie z Raw Terminal – idzie przez tę samą kolejkę co automatyczne zapytania. */
    suspend fun sendRaw(input: String): String {
        val cmd = input.trim().uppercase().replace(" ", "")
        if (cmd.isEmpty()) return "Puste polecenie"
        val s = session ?: return "Brak połączenia z adapterem"
        if (rawAllowed.none { cmd.startsWith(it) }) {
            ObdRepository.log(cmd, "ODRZUCONE: dozwolone tylko AT oraz tryby 01, 02, 03, 06, 07, 09, 0A")
            return "Odrzucono: dozwolone tylko komendy AT i tryby 01, 02, 03, 06, 07, 09, 0A (kasowanie DTC jest w module Błędy)."
        }
        return try {
            s.command(cmd, 6000) ?: "Brak odpowiedzi (timeout)"
        } catch (e: IOException) {
            e.message ?: "Błąd łącza"
        }
    }
}
