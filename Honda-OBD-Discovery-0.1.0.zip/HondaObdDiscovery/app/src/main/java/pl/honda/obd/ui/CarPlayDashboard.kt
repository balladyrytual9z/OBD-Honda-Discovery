package pl.honda.obd.ui

import android.content.Context
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import kotlinx.coroutines.CoroutineScope
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.Settings
import pl.honda.obd.data.VehicleSnapshot

/** Tryb "CarPlay Dashboard": lewy dock + obszar roboczy z modułami. */
class CarPlayDashboard(ctx: Context, private val host: Host, scope: CoroutineScope) : LinearLayout(ctx) {

    interface Host {
        fun swapUi()
        fun saveEvent()
        fun clearDtcQuick()
        fun reconnect()
        fun pickAdapter()
    }

    private val content = FrameLayout(ctx)
    private val dockItems = arrayOfNulls<DockItem>(7)
    private val views = ArrayList<View>()
    private var quickItem: DockItem? = null
    private var current = 0
    private var lastS = VehicleSnapshot()
    private var lastC = ConnState.OFFLINE

    init {
        orientation = HORIZONTAL
        setBackgroundColor(Ui.BG)

        views.add(OverviewView(ctx) { i -> show(i) })
        views.add(LiveDataView(ctx) { })
        views.add(ChartsView(ctx))
        views.add(DtcView(ctx, scope))
        views.add(MisfireView(ctx, scope))
        views.add(SettingsView(ctx, { host.pickAdapter() }, { host.reconnect() }, { refreshTheme() }))
        views.add(RawView(ctx, scope))
        for (v in views) {
            content.addView(v, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        }

        // ---- dock
        val dock = LinearLayout(ctx)
        dock.orientation = VERTICAL
        dock.setBackgroundColor(Ui.DOCK)

        val top = LinearLayout(ctx)
        top.orientation = VERTICAL
        addDockItem(top, 0, Glyph.OVERVIEW, "Przegląd")
        addDockItem(top, 1, Glyph.LIVE, "Dane")
        addDockItem(top, 2, Glyph.CHART, "Wykresy")
        addDockItem(top, 3, Glyph.DTC, "Błędy")
        addDockItem(top, 4, Glyph.MISFIRE, "Zapłony")
        addDockItem(top, 6, Glyph.RAW, "Raw")
        val sv = ScrollView(ctx)
        sv.isVerticalScrollBarEnabled = false
        sv.addView(top)
        dock.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        // dolna, nieruchoma sekcja: szybki przycisk, ustawienia, powrót do zegarów
        val q = DockItem(ctx, Glyph.QUICK, quickLabel())
        q.setOnClickListener { runQuick() }
        quickItem = q
        dock.addView(q, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(70)))
        addDockItem(dock, 5, Glyph.SETTINGS, "Ustawienia", 70)
        val home = DockItem(ctx, Glyph.UFO, "Zegary")
        home.setOnClickListener { host.swapUi() }
        dock.addView(home, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ctx.dp(70)))

        addView(dock, LinearLayout.LayoutParams(ctx.dp(110), ViewGroup.LayoutParams.MATCH_PARENT))
        val sep = View(ctx)
        sep.setBackgroundColor(Ui.BORDER)
        addView(sep, LinearLayout.LayoutParams(ctx.dp(1), ViewGroup.LayoutParams.MATCH_PARENT))
        addView(content, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))

        show(0)
    }

    private fun addDockItem(parent: LinearLayout, idx: Int, g: Glyph, label: String, heightDp: Int = 78) {
        val it = DockItem(context, g, label)
        it.setOnClickListener { show(idx) }
        dockItems[idx] = it
        parent.addView(it, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, context.dp(heightDp)))
    }

    private fun quickLabel(): String = when (Settings.quickAction) {
        "save_event" -> "Zapisz"
        "reconnect" -> "Połącz"
        "clear_dtc" -> "Kasuj DTC"
        else -> "Widok"
    }

    private fun runQuick() {
        when (Settings.quickAction) {
            "save_event" -> host.saveEvent()
            "reconnect" -> host.reconnect()
            "clear_dtc" -> host.clearDtcQuick()
            else -> host.swapUi()
        }
    }

    fun refreshTheme() {
        quickItem?.label = quickLabel()
        quickItem?.invalidate()
        for (d in dockItems) d?.invalidate()
    }

    fun show(i: Int) {
        current = i
        for ((k, v) in views.withIndex()) v.visibility = if (k == i) View.VISIBLE else View.GONE
        for ((k, d) in dockItems.withIndex()) d?.selected = (k == i)
        (views[i] as? Updatable)?.update(lastS, lastC)
    }

    fun showSettings() = show(5)

    fun update(s: VehicleSnapshot, c: ConnState) {
        lastS = s
        lastC = c
        (views[current] as? Updatable)?.update(s, c)
    }
}
