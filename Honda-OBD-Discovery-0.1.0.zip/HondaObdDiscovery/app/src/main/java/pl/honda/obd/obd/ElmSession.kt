package pl.honda.obd.obd

import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withTimeoutOrNull
import pl.honda.obd.data.ObdRepository
import java.io.IOException

/**
 * Sesja ELM327: jedna komenda naraz (mutex – wspólna kolejka dla pętli odczytu, DTC i Raw Terminal).
 * Odpowiedź zbierana jest aż do znaku zachęty '>' (dane mogą przychodzić w wielu pakietach).
 */
class ElmSession(private val transport: ElmTransport) {
    private val mutex = Mutex()

    /** Zwraca tekst odpowiedzi (bez '>') albo null przy przekroczeniu czasu. Rzuca IOException przy zerwaniu łącza. */
    suspend fun command(cmd: String, timeoutMs: Long = 3000L): String? = mutex.withLock {
        var result: String? = null
        var err: String? = null
        try {
            val chan = transport.incoming
            while (chan.tryReceive().isSuccess) { /* wyczyść stare dane */ }
            transport.write(cmd)
            val sb = StringBuilder()
            val ok = withTimeoutOrNull(timeoutMs) {
                var done = false
                while (!done) {
                    val bytes = chan.receiveCatching().getOrNull()
                        ?: throw IOException("Połączenie z adapterem zerwane")
                    sb.append(String(bytes, Charsets.ISO_8859_1))
                    if (sb.indexOf(">") >= 0) done = true
                }
                true
            }
            result = if (ok == null) null else sb.toString().replace(">", "")
        } catch (e: IOException) {
            err = "BŁĄD: " + (e.message ?: "łącze")
            throw e
        } finally {
            ObdRepository.log(cmd, (result ?: err ?: "(brak odpowiedzi – timeout)").trim())
        }
        result
    }

    fun close() {
        transport.close()
    }
}
