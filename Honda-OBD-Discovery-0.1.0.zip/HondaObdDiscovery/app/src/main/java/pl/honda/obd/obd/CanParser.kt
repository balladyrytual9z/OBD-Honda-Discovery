package pl.honda.obd.obd

import pl.honda.obd.data.Param

/** Składa odpowiedzi CAN (ISO 15765-4, nagłówki włączone: ATH1) w komplet danych od każdego ECU. */
object CanParser {
    private val hdr = Regex("^[0-9A-F]{3}([0-9A-F]{2})+$")

    /** Zwraca listę ładunków (pierwszy bajt = kod usługi, np. 0x41). */
    fun payloads(resp: String): List<IntArray> {
        val data = LinkedHashMap<String, ArrayList<Int>>()
        val expected = HashMap<String, Int>()
        for (raw in resp.split('\r', '\n')) {
            val line = raw.replace(" ", "").uppercase().trim()
            if (line.isEmpty() || !hdr.matches(line)) continue
            val id = line.substring(0, 3)
            val n = (line.length - 3) / 2
            val b = IntArray(n) { line.substring(3 + it * 2, 5 + it * 2).toInt(16) }
            val list = data.getOrPut(id) { ArrayList() }
            when (b[0] shr 4) {
                0 -> {
                    val len = b[0] and 0x0F
                    val end = minOf(b.size, 1 + len)
                    for (i in 1 until end) list.add(b[i])
                }
                1 -> {
                    if (b.size >= 2) {
                        expected[id] = ((b[0] and 0x0F) shl 8) or b[1]
                        for (i in 2 until b.size) list.add(b[i])
                    }
                }
                2 -> for (i in 1 until b.size) list.add(b[i])
            }
        }
        val out = ArrayList<IntArray>()
        for ((id, list) in data) {
            val lim = expected[id]
            val arr = if (lim != null && lim < list.size) list.subList(0, lim) else list
            if (arr.isNotEmpty()) out.add(arr.toIntArray())
        }
        return out
    }

    fun hasNoData(resp: String): Boolean {
        val u = resp.uppercase()
        return u.contains("NO DATA") || u.contains("UNABLE TO CONNECT") || u.contains("CAN ERROR") ||
            u.contains("BUS") || u.contains("ERROR")
    }
}

object PidDecoder {
    fun decode(p: Param, payload: IntArray): Double? {
        val a = payload.getOrNull(2) ?: return null
        val b = payload.getOrNull(3)
        return when (p) {
            Param.RPM -> if (b == null) null else (a * 256 + b) / 4.0
            Param.SPEED -> a.toDouble()
            Param.TPS, Param.LOAD, Param.FUEL -> a * 100.0 / 255.0
            Param.MAP, Param.BARO -> a.toDouble()
            Param.ECT, Param.IAT, Param.OIL -> a - 40.0
            Param.STFT, Param.LTFT -> (a - 128) * 100.0 / 128.0
            Param.TIMING -> a / 2.0 - 64.0
            Param.VOLT_ECU -> if (b == null) null else (a * 256 + b) / 1000.0
            Param.LAMBDA -> if (b == null) null else (a * 256 + b) / 32768.0
            else -> null
        }
    }
}
