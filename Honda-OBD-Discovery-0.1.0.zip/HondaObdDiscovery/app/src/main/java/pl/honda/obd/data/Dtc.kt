package pl.honda.obd.data

object DtcDecoder {
    fun code(a: Int, b: Int): String {
        val letter = "PCBU"[(a shr 6) and 3]
        val d1 = (a shr 4) and 3
        val d2 = a and 0x0F
        return letter.toString() + d1 + Integer.toHexString(d2).uppercase() + "%02X".format(b)
    }

    private val db = mapOf(
        "P0100" to "Układ czujnika przepływu/ciśnienia powietrza",
        "P0105" to "Układ czujnika ciśnienia MAP",
        "P0107" to "Czujnik MAP – zbyt niskie napięcie",
        "P0108" to "Czujnik MAP – zbyt wysokie napięcie",
        "P0112" to "Czujnik temp. ssania – zbyt niskie napięcie",
        "P0113" to "Czujnik temp. ssania – zbyt wysokie napięcie",
        "P0117" to "Czujnik temp. płynu – zbyt niskie napięcie",
        "P0118" to "Czujnik temp. płynu – zbyt wysokie napięcie",
        "P0122" to "Czujnik przepustnicy – zbyt niskie napięcie",
        "P0123" to "Czujnik przepustnicy – zbyt wysokie napięcie",
        "P0130" to "Sonda lambda (blok 1, czujnik 1) – usterka obwodu",
        "P0133" to "Sonda lambda (blok 1, czujnik 1) – wolna reakcja",
        "P0134" to "Sonda lambda (blok 1, czujnik 1) – brak aktywności",
        "P0135" to "Sonda lambda (blok 1, czujnik 1) – podgrzewanie",
        "P0141" to "Sonda lambda (blok 1, czujnik 2) – podgrzewanie",
        "P0171" to "Zbyt uboga mieszanka (za mało paliwa) (blok 1)",
        "P0172" to "Zbyt bogata mieszanka (za dużo paliwa)",
        "P0201" to "Wtryskiwacz cyl. 1 – usterka obwodu",
        "P0202" to "Wtryskiwacz cyl. 2 – usterka obwodu",
        "P0203" to "Wtryskiwacz cyl. 3 – usterka obwodu",
        "P0204" to "Wtryskiwacz cyl. 4 – usterka obwodu",
        "P0300" to "Wypadanie zapłonów – wiele cylindrów",
        "P0301" to "Wypadanie zapłonu – cyl. 1",
        "P0302" to "Wypadanie zapłonu – cyl. 2",
        "P0303" to "Wypadanie zapłonu – cyl. 3",
        "P0304" to "Wypadanie zapłonu – cyl. 4",
        "P0325" to "Czujnik spalania stukowego – usterka obwodu",
        "P0335" to "Czujnik położenia wału korbowego – usterka obwodu",
        "P0336" to "Czujnik położenia wału korbowego – zakres",
        "P0340" to "Czujnik położenia wałka rozrządu – usterka obwodu",
        "P0420" to "Sprawność katalizatora poniżej progu (blok 1)",
        "P0442" to "Układ EVAP – mały wyciek",
        "P0446" to "Układ EVAP – zawór odpowietrzenia",
        "P0455" to "Układ EVAP – duży wyciek",
        "P0500" to "Czujnik prędkości pojazdu",
        "P0505" to "Układ regulacji biegu jałowego",
        "P0562" to "Napięcie w układzie – za niskie",
        "P0563" to "Napięcie w układzie – za wysokie"
    )

    fun describe(code: String): String {
        db[code]?.let { return it }
        return if (code.length >= 2 && code[1] == '1') "Kod producenta (Honda) – brak opisu w bazie aplikacji"
        else "Brak opisu w bazie aplikacji"
    }
}
