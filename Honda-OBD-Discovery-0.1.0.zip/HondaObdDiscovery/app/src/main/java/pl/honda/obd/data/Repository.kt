package pl.honda.obd.data

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object ObdRepository {
    val connState = MutableStateFlow(ConnState.OFFLINE)
    val statusText = MutableStateFlow("Brak adaptera")
    val snapshot = MutableStateFlow(VehicleSnapshot())
    val adapterInfo = MutableStateFlow("")

    private val rawLog = ArrayList<String>()
    @Volatile var logVersion = 0

    /** Log komunikacji ELM327 (TX/RX z czasem) – dla Raw Terminal. */
    fun log(tx: String, rx: String) {
        val t = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        synchronized(lock) {
            rawLog.add("$t > $tx")
            rawLog.add("$t < " + rx.replace('\r', ' ').replace('\n', ' '))
            while (rawLog.size > 400) rawLog.removeAt(0)
            logVersion++
        }
    }

    fun logText(max: Int = 80): String = synchronized(lock) { rawLog.takeLast(max).joinToString("\n") }

    private val lock = Any()
    private val history = HashMap<Param, ArrayList<Sample>>()
    private const val KEEP_MS = 10 * 60 * 1000L

    fun setState(s: ConnState, text: String) {
        connState.value = s
        statusText.value = text
    }

    fun put(p: Param, v: Double) {
        val t = System.currentTimeMillis()
        addHistory(p, t, v)
        if (p == Param.VOLT_ECU || p == Param.VOLT_ADAPTER) addHistory(Param.VOLT, t, v)
        snapshot.update { it.copy(readings = it.readings + (p to Reading(v, t))) }
    }

    fun setUnsupported(set: Set<Param>) {
        snapshot.update { it.copy(unsupported = set) }
    }

    fun setMil(on: Boolean, count: Int) {
        snapshot.update { it.copy(milOn = on, dtcCount = count) }
    }

    fun setCodes(codes: List<String>) {
        snapshot.update { it.copy(codes = codes) }
    }

    private fun addHistory(p: Param, t: Long, v: Double) {
        synchronized(lock) {
            val list = history.getOrPut(p) { ArrayList() }
            if (list.isNotEmpty() && t - list[list.size - 1].t < 250) return
            list.add(Sample(t, v))
            while (list.isNotEmpty() && t - list[0].t > KEEP_MS) list.removeAt(0)
        }
    }

    fun history(p: Param, windowMs: Long): List<Sample> {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val list = history[p] ?: return emptyList()
            return list.filter { now - it.t <= windowMs }
        }
    }

    /** Zapisuje ostatnie 30 s telemetrii (wszystkie parametry) do pliku CSV. */
    fun exportEvent(dir: File): File? {
        val now = System.currentTimeMillis()
        val sb = StringBuilder("czas_ms;parametr;wartosc;jednostka\n")
        var rows = 0
        synchronized(lock) {
            for ((p, list) in history) {
                if (p == Param.VOLT) continue
                for (s in list) {
                    if (now - s.t <= 30_000L) {
                        sb.append(s.t).append(';').append(p.name).append(';')
                            .append(String.format(Locale.US, "%.3f", s.v)).append(';')
                            .append(p.unit).append('\n')
                        rows++
                    }
                }
            }
        }
        if (rows == 0) return null
        dir.mkdirs()
        val name = "event_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".csv"
        val f = File(dir, name)
        f.writeText(sb.toString())
        return f
    }
}
