package pl.honda.obd.ui

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.graphics.ColorUtils
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.ObdRepository
import pl.honda.obd.data.Param
import pl.honda.obd.data.Sample
import pl.honda.obd.data.Settings
import pl.honda.obd.data.VehicleSnapshot
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density

object Ui {
    val BG = Color.parseColor("#121212")
    val DOCK = Color.parseColor("#0E0E10")
    val CARD = Color.parseColor("#1C1C1E")
    val BORDER = Color.parseColor("#2C2C2E")
    val TEXT = Color.parseColor("#F5F5F7")
    val SUB = Color.parseColor("#8E8E93")
    val GREEN = Color.parseColor("#30D158")
    val ORANGE = Color.parseColor("#FF9F0A")
    val RED = Color.parseColor("#FF453A")

    fun round(ctx: Context, fill: Int, stroke: Int = BORDER, radiusDp: Int = 16): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(fill)
        g.cornerRadius = ctx.dpf(radiusDp.toFloat())
        g.setStroke(ctx.dp(1), stroke)
        return g
    }

    fun fmt(v: Double, d: Int): String = String.format(Locale.US, "%." + d + "f", v)

    fun text(ctx: Context, s: String, sp: Float, color: Int = TEXT, bold: Boolean = false): TextView {
        val t = TextView(ctx)
        t.text = s
        t.textSize = sp
        t.setTextColor(color)
        if (bold) t.typeface = Typeface.DEFAULT_BOLD
        return t
    }

    fun button(ctx: Context, s: String, color: Int, onClick: () -> Unit): TextView {
        val t = text(ctx, s, 15f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(ctx.dp(18), ctx.dp(12), ctx.dp(18), ctx.dp(12))
        t.background = round(ctx, color, color, 14)
        t.setOnClickListener { onClick() }
        return t
    }

    /** Wartość parametru z uwzględnieniem braku danych / nieaktualności / nieobsługi. */
    fun valueText(s: VehicleSnapshot, p: Param): Pair<String, Int> {
        if (p in s.unsupported) return Pair("nieobsługiwane", SUB)
        val r = s.reading(p) ?: return Pair("---", SUB)
        val f = s.fresh(p)
        val txt = fmt(r.value, p.decimals) + " " + p.unit
        return if (f == null) Pair("$txt (nieaktualne)", ORANGE) else Pair(txt, TEXT)
    }
}

// ----------------------------------------------------------------------------- dock

enum class Glyph { OVERVIEW, LIVE, CHART, DTC, MISFIRE, SETTINGS, UFO, QUICK, RAW }

class DockItem(ctx: Context, private val glyph: Glyph, var label: String) : View(ctx) {
    var selected = false
        set(v) { field = v; invalidate() }

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val path = Path()
    private val r = RectF()

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val d = resources.displayMetrics.density
        if (selected) {
            p.style = Paint.Style.FILL
            p.color = Settings.accent
            r.set(8 * d, 6 * d, w - 8 * d, h - 6 * d)
            c.drawRoundRect(r, 16 * d, 16 * d, p)
        }
        p.color = if (selected) Color.WHITE else Ui.SUB
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2 * d
        p.strokeCap = Paint.Cap.ROUND
        val cx = w / 2f
        val cy = h * 0.40f
        val s = 12 * d
        when (glyph) {
            Glyph.OVERVIEW -> {
                val g = 2 * d
                r.set(cx - s, cy - s, cx - g, cy - g); c.drawRoundRect(r, 3 * d, 3 * d, p)
                r.set(cx + g, cy - s, cx + s, cy - g); c.drawRoundRect(r, 3 * d, 3 * d, p)
                r.set(cx - s, cy + g, cx - g, cy + s); c.drawRoundRect(r, 3 * d, 3 * d, p)
                r.set(cx + g, cy + g, cx + s, cy + s); c.drawRoundRect(r, 3 * d, 3 * d, p)
            }
            Glyph.LIVE -> {
                for (i in -1..1) {
                    val y = cy + i * s * 0.7f
                    c.drawLine(cx - s, y, cx + s, y, p)
                }
            }
            Glyph.CHART -> {
                path.reset()
                path.moveTo(cx - s, cy + s * 0.6f)
                path.lineTo(cx - s * 0.3f, cy - s * 0.1f)
                path.lineTo(cx + s * 0.2f, cy + s * 0.3f)
                path.lineTo(cx + s, cy - s * 0.8f)
                c.drawPath(path, p)
            }
            Glyph.DTC -> {
                path.reset()
                path.moveTo(cx, cy - s)
                path.lineTo(cx + s, cy + s * 0.8f)
                path.lineTo(cx - s, cy + s * 0.8f)
                path.close()
                c.drawPath(path, p)
                c.drawLine(cx, cy - s * 0.2f, cx, cy + s * 0.25f, p)
                c.drawPoint(cx, cy + s * 0.55f, p)
            }
            Glyph.MISFIRE -> {
                c.drawCircle(cx, cy, s, p)
                path.reset()
                path.moveTo(cx - s * 0.5f, cy + s * 0.5f)
                path.lineTo(cx - s * 0.1f, cy - s * 0.4f)
                path.lineTo(cx + s * 0.1f, cy + s * 0.2f)
                path.lineTo(cx + s * 0.5f, cy - s * 0.5f)
                c.drawPath(path, p)
            }
            Glyph.SETTINGS -> {
                c.drawCircle(cx, cy, s * 0.45f, p)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0).toFloat()
                    val ca = Math.cos(a.toDouble()).toFloat()
                    val sa = Math.sin(a.toDouble()).toFloat()
                    c.drawLine(cx + ca * s * 0.75f, cy + sa * s * 0.75f, cx + ca * s, cy + sa * s, p)
                }
            }
            Glyph.UFO -> {
                r.set(cx - s, cy - s, cx + s, cy + s)
                c.drawArc(r, 135f, 270f, false, p)
                c.drawLine(cx, cy, cx + s * 0.5f, cy - s * 0.5f, p)
            }
            Glyph.RAW -> {
                path.reset()
                path.moveTo(cx - s, cy - s * 0.6f)
                path.lineTo(cx - s * 0.1f, cy)
                path.lineTo(cx - s, cy + s * 0.6f)
                c.drawPath(path, p)
                c.drawLine(cx + s * 0.1f, cy + s * 0.7f, cx + s, cy + s * 0.7f, p)
            }
            Glyph.QUICK -> {
                path.reset()
                path.moveTo(cx + s * 0.2f, cy - s)
                path.lineTo(cx - s * 0.5f, cy + s * 0.1f)
                path.lineTo(cx, cy + s * 0.1f)
                path.lineTo(cx - s * 0.2f, cy + s)
                path.lineTo(cx + s * 0.5f, cy - s * 0.1f)
                path.lineTo(cx, cy - s * 0.1f)
                path.close()
                c.drawPath(path, p)
            }
        }
        p.style = Paint.Style.FILL
        p.strokeWidth = 0f
        p.textSize = 11 * d
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.DEFAULT_BOLD
        c.drawText(label, cx, h - 12 * d, p)
    }
}

// ----------------------------------------------------------------------------- karta

class InfoCard(ctx: Context) : LinearLayout(ctx) {
    val title = Ui.text(ctx, "", 13f, Ui.SUB, true)
    val value = Ui.text(ctx, "---", 40f, Ui.TEXT, true)
    val sub = Ui.text(ctx, "", 14f, Ui.SUB)

    init {
        orientation = VERTICAL
        setPadding(ctx.dp(20), ctx.dp(18), ctx.dp(20), ctx.dp(18))
        background = Ui.round(ctx, Ui.CARD)
        gravity = Gravity.CENTER_VERTICAL
        addView(title)
        addView(value)
        addView(sub)
        isClickable = true
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> animate().scaleX(0.97f).scaleY(0.97f).setDuration(80).start()
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> animate().scaleX(1f).scaleY(1f).setDuration(120).start()
        }
        return super.onTouchEvent(e)
    }
}

// ----------------------------------------------------------------------------- wykres

class ChartPanel(ctx: Context, val param: Param) : View(ctx) {
    var windowMs = 60_000L
    private var samples: List<Sample> = emptyList()
    private var minV = 0.0
    private var maxV = 0.0
    private var avgV = 0.0
    private var cur = "---"
    private val line = Path()
    private val fill = Path()
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var grad: Shader? = null

    init {
        background = Ui.round(ctx, Ui.CARD)
    }

    fun refresh() {
        samples = ObdRepository.history(param, windowMs)
        if (samples.isNotEmpty()) {
            var mn = Double.MAX_VALUE
            var mx = -Double.MAX_VALUE
            var sum = 0.0
            for (s in samples) { mn = min(mn, s.v); mx = max(mx, s.v); sum += s.v }
            minV = mn; maxV = mx; avgV = sum / samples.size
            cur = Ui.fmt(samples[samples.size - 1].v, param.decimals) + " " + param.unit
        } else cur = "---"
        invalidate()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val a = Settings.accent
        grad = LinearGradient(0f, 0f, 0f, h.toFloat(), ColorUtils.setAlphaComponent(a, 110), Color.TRANSPARENT, Shader.TileMode.CLAMP)
    }

    override fun onDraw(c: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        p.style = Paint.Style.FILL
        p.shader = null
        p.textAlign = Paint.Align.LEFT
        p.typeface = Typeface.DEFAULT_BOLD
        p.color = Ui.SUB
        p.textSize = 12 * d
        c.drawText(param.label, 14 * d, 22 * d, p)
        p.color = Ui.TEXT
        p.textSize = 26 * d
        c.drawText(cur, 14 * d, 52 * d, p)
        p.textAlign = Paint.Align.RIGHT
        p.textSize = 11 * d
        p.color = Ui.SUB
        if (samples.isNotEmpty()) {
            c.drawText(
                "min " + Ui.fmt(minV, param.decimals) + "   max " + Ui.fmt(maxV, param.decimals) +
                    "   śr " + Ui.fmt(avgV, param.decimals), w - 14 * d, 22 * d, p
            )
        }
        val l = 14 * d
        val r = w - 14 * d
        val t = 64 * d
        val b = h - 14 * d
        if (samples.size < 2 || b - t < 10f) {
            p.textAlign = Paint.Align.CENTER
            p.textSize = 13 * d
            c.drawText("Brak danych", w / 2f, (t + b) / 2f, p)
            return
        }
        var lo = minV
        var hi = maxV
        if (hi - lo < 1e-6) { lo -= 1.0; hi += 1.0 }
        val pad = (hi - lo) * 0.1
        lo -= pad; hi += pad
        val now = System.currentTimeMillis()
        line.reset()
        fill.reset()
        var first = true
        var lastX = l
        for (s in samples) {
            val x = l + ((s.t - (now - windowMs)).toFloat() / windowMs.toFloat()) * (r - l)
            val y = b - ((s.v - lo) / (hi - lo)).toFloat() * (b - t)
            if (first) { line.moveTo(x, y); fill.moveTo(x, b); fill.lineTo(x, y); first = false }
            else { line.lineTo(x, y); fill.lineTo(x, y) }
            lastX = x
        }
        fill.lineTo(lastX, b)
        fill.close()
        p.shader = grad
        c.drawPath(fill, p)
        p.shader = null
        p.style = Paint.Style.STROKE
        p.strokeWidth = 2.5f * d
        p.strokeJoin = Paint.Join.ROUND
        p.color = Settings.accent
        c.drawPath(line, p)
    }
}

/** Wspólny interfejs modułów CarPlay. */
interface Updatable {
    fun update(s: VehicleSnapshot, c: ConnState)
}

fun lp(vertical: Boolean, weight: Float, margin: Int): LinearLayout.LayoutParams {
    val lp = if (vertical) LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, weight)
    else LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight)
    lp.setMargins(margin, margin, margin, margin)
    return lp
}
