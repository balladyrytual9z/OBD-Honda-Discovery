package pl.honda.obd

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.ObdRepository
import pl.honda.obd.data.Settings
import pl.honda.obd.obd.ObdEngine
import pl.honda.obd.ui.Ui
import pl.honda.obd.ui.dp

/** Osobny wpis „Kasuj DTC” / „DTC”: jeden duży przycisk, bez okien potwierdzenia. */
class ClearDtcActivity : AppCompatActivity() {
    private var busy = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER
        col.setBackgroundColor(Ui.BG)
        col.setPadding(dp(32), dp(24), dp(32), dp(24))

        val title = Ui.text(this, "DTC", 28f, Color.WHITE, true)
        val status = Ui.text(this, "", 16f, Ui.SUB)
        val result = Ui.text(this, "Ostatni wynik: brak", 18f, Ui.TEXT, true)
        result.gravity = Gravity.CENTER

        fun doClear() {
            if (busy) return
            busy = true
            result.text = "Kasowanie…"
            lifecycleScope.launch {
                result.text = ObdEngine.clearDtcs()
                busy = false
            }
        }

        val btn: TextView = Ui.button(this, "KASUJ BŁĘDY DTC", Ui.RED) { doClear() }
        btn.textSize = 26f
        btn.setPadding(dp(48), dp(28), dp(48), dp(28))
        val settingsBtn = Ui.button(this, "USTAWIENIA", Ui.BORDER) {
            startActivity(Intent(this, MainActivity::class.java).putExtra("open_settings", true))
        }

        col.addView(title)
        col.addView(status)
        val lp = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp.topMargin = dp(24)
        lp.bottomMargin = dp(16)
        col.addView(btn, lp)
        col.addView(result)
        val lp2 = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
        lp2.topMargin = dp(20)
        col.addView(settingsBtn, lp2)
        setContentView(col)

        ObdEngine.start()
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                ObdRepository.statusText.collect { status.text = it }
            }
        }

        // Opcjonalne, jednorazowe skasowanie po otwarciu (tylko jeśli włączone w Ustawieniach)
        if (savedInstanceState == null && Settings.autoClearOnOpen) {
            busy = true
            result.text = "Czekam na ECU…"
            lifecycleScope.launch {
                val ok = withTimeoutOrNull(20_000) { ObdRepository.connState.first { it == ConnState.CONNECTED } }
                result.text = if (ok == null) "ECU nie odpowiada – nic nie skasowano" else ObdEngine.clearDtcs()
                busy = false
            }
        }
    }
}
