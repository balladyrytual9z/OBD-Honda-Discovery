package pl.honda.obd

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.SystemClock
import android.view.View
import android.widget.FrameLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.ObdRepository
import pl.honda.obd.data.Param
import pl.honda.obd.data.Settings
import pl.honda.obd.obd.ObdEngine
import pl.honda.obd.ui.CarPlayDashboard
import pl.honda.obd.ui.UfoClusterView
import java.io.File
import java.util.Collections

class MainActivity : AppCompatActivity(), UfoClusterView.Listener, CarPlayDashboard.Host {

    private lateinit var ufo: UfoClusterView
    private lateinit var carplay: CarPlayDashboard
    private var ufoMode = true
    private var lastPush = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = FrameLayout(this)
        ufo = UfoClusterView(this)
        ufo.listener = this
        carplay = CarPlayDashboard(this, this, lifecycleScope)
        root.addView(ufo, FrameLayout.LayoutParams(-1, -1))
        root.addView(carplay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        ufoMode = Settings.uiMode == "ufo"
        ufo.visibility = if (ufoMode) View.VISIBLE else View.GONE
        carplay.visibility = if (ufoMode) View.GONE else View.VISIBLE

        handleIntent(intent)

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { ObdRepository.snapshot.collect { push() } }
                launch { ObdRepository.connState.collect { push() } }
                launch {
                    while (true) {
                        delay(250)
                        push(true)
                    }
                }
            }
        }
    }

    private fun handleIntent(i: Intent?) {
        if (i?.getBooleanExtra("open_settings", false) == true) {
            i.removeExtra("open_settings")
            onSettings()
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        handleIntent(intent)
    }

    private fun push(force: Boolean = false) {
        val now = SystemClock.uptimeMillis()
        if (!force && now - lastPush < 50) return
        lastPush = now
        val s = ObdRepository.snapshot.value
        val c = ObdRepository.connState.value
        if (ufoMode) ufo.setData(s, c) else carplay.update(s, c)
    }

    private fun showMode(ufoMode: Boolean) {
        this.ufoMode = ufoMode
        Settings.uiMode = if (ufoMode) "ufo" else "carplay"
        val show: View = if (ufoMode) ufo else carplay
        val hide: View = if (ufoMode) carplay else ufo
        hide.visibility = View.GONE
        show.alpha = 0f
        show.visibility = View.VISIBLE
        show.animate().alpha(1f).setDuration(180).start()
        push(true)
    }

    // ------------------------------------------------------------ tryb pełnoekranowy

    private fun hideSystemUi() {
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_FULLSCREEN
            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN)
    }

    override fun onResume() {
        super.onResume()
        hideSystemUi()
        ObdEngine.start()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) hideSystemUi()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        // Launcher: przycisk Wstecz nic nie robi
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_LONG).show()

    // ------------------------------------------------------------ UfoClusterView.Listener

    override fun onDtcTap() {
        lifecycleScope.launch {
            if (ObdRepository.connState.value == ConnState.CONNECTED) ObdEngine.readDtcs()
            val s = ObdRepository.snapshot.value
            val codes = s.codes
            val msg = when {
                codes == null -> "Brak danych o kodach błędów (ECU nie odpowiada)."
                codes.isEmpty() -> "Brak zapisanych kodów błędów."
                else -> codes.joinToString("\n") { it + " – " + pl.honda.obd.data.DtcDecoder.describe(it) }
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Kody błędów (DTC)")
                .setMessage(msg)
                .setPositiveButton("KASUJ DTC") { _, _ -> clearDtcQuick() }
                .setNegativeButton("Zamknij", null)
                .show()
        }
    }

    override fun onSaveEvent() = saveEvent()

    override fun onSwapUi() = swapUi()

    override fun onSettings() {
        showMode(false)
        carplay.showSettings()
    }

    override fun onSpeedTap() {
        when (Settings.speedTapAction) {
            "units" -> { Settings.speedMph = !Settings.speedMph; push(true) }
            "clear_dtc" -> clearDtcQuick()
            else -> { }
        }
    }

    override fun onArcLongPress(left: Boolean) {
        val s = ObdRepository.snapshot.value
        val opts = Param.values().filter {
            it != Param.RPM && it != Param.SPEED && it != Param.VOLT_ECU && it != Param.VOLT_ADAPTER &&
                it !in s.unsupported
        }
        AlertDialog.Builder(this)
            .setTitle(if (left) "Lewy łuk – parametr" else "Prawy łuk – parametr")
            .setItems(opts.map { it.label }.toTypedArray()) { _, i -> ufo.setArcParam(left, opts[i]) }
            .show()
    }

    // ------------------------------------------------------------ CarPlayDashboard.Host

    override fun swapUi() = showMode(!ufoMode)

    override fun saveEvent() {
        val dir = File(getExternalFilesDir(null) ?: filesDir, "events")
        val f = ObdRepository.exportEvent(dir)
        toast(if (f == null) "Brak danych do zapisania (ostatnie 30 s)" else "Zapisano: " + f.absolutePath)
    }

    override fun clearDtcQuick() {
        lifecycleScope.launch { toast(ObdEngine.clearDtcs()) }
    }

    override fun reconnect() {
        ObdEngine.restart()
        toast("Łączenie z adapterem…")
    }

    override fun pickAdapter() {
        val ba = BluetoothAdapter.getDefaultAdapter()
        if (ba == null || !ba.isEnabled) {
            toast("Włącz Bluetooth w radiu")
            return
        }
        val bonded = ba.bondedDevices?.toList().orEmpty()
        val names = ArrayList<String>()
        names.add("Szukaj adapterów BLE (8 s)…")
        for (d in bonded) names.add((d.name ?: "Urządzenie") + "\n" + d.address + "  (sparowane)")
        AlertDialog.Builder(this)
            .setTitle("Wybierz adapter OBD")
            .setItems(names.toTypedArray()) { _, i ->
                if (i == 0) {
                    scanBle()
                } else {
                    val d = bonded[i - 1]
                    val kind = when (d.type) {
                        BluetoothDevice.DEVICE_TYPE_LE -> "ble"
                        BluetoothDevice.DEVICE_TYPE_CLASSIC -> "spp"
                        else -> "auto"
                    }
                    saveAdapter(d.address, d.name, kind)
                }
            }
            .setNegativeButton("Zamknij", null)
            .show()
    }

    private fun saveAdapter(mac: String, name: String?, kind: String) {
        Settings.adapterMac = mac
        Settings.adapterName = name
        Settings.adapterKind = kind
        ObdEngine.restart()
        toast("Wybrano: " + (name ?: mac))
    }

    private fun scanBle() {
        val ba = BluetoothAdapter.getDefaultAdapter() ?: return
        if (checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 77)
            toast("Zezwól na lokalizację – Android 9 wymaga tego do skanowania BLE")
            return
        }
        val scanner = ba.bluetoothLeScanner
        if (scanner == null) {
            toast("Skaner BLE niedostępny")
            return
        }
        val found = Collections.synchronizedMap(LinkedHashMap<String, String>())
        val cb = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                found[result.device.address] = result.device.name ?: "(bez nazwy)"
            }
        }
        toast("Skanowanie BLE… (8 s)")
        scanner.startScan(cb)
        lifecycleScope.launch {
            delay(8000)
            try { scanner.stopScan(cb) } catch (_: Exception) { }
            val list = synchronized(found) { found.entries.map { it.key to it.value } }
            if (list.isEmpty()) {
                toast("Nie znaleziono urządzeń BLE (sprawdź, czy adapter jest zasilany i czy lokalizacja jest włączona)")
                return@launch
            }
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Znalezione urządzenia BLE")
                .setItems(list.map { it.second + "\n" + it.first }.toTypedArray()) { _, i ->
                    saveAdapter(list[i].first, list[i].second, "ble")
                }
                .setNegativeButton("Zamknij", null)
                .show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 77 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) scanBle()
    }
}
