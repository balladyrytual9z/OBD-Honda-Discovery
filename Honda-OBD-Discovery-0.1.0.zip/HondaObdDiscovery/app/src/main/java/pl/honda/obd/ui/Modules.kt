package pl.honda.obd.ui

import android.content.Context
import android.graphics.Color
import android.os.SystemClock
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import pl.honda.obd.data.ConnState
import pl.honda.obd.data.DtcDecoder
import pl.honda.obd.data.ObdRepository
import pl.honda.obd.data.Param
import pl.honda.obd.data.Settings
import pl.honda.obd.data.VehicleSnapshot
import pl.honda.obd.obd.ObdEngine

// ============================================================================= Przegląd

class OverviewView(ctx: Context, private val openModule: (Int) -> Unit) : LinearLayout(ctx), Updatable {
    private val big = InfoCard(ctx)
    private val power = InfoCard(ctx)
    private val dtc = InfoCard(ctx)

    init {
        orientation = HORIZONTAL
        val m = ctx.dp(8)
        setPadding(ctx.dp(8), ctx.dp(8), ctx.dp(8), ctx.dp(8))
        big.title.text = "OBROTY / PRĘDKOŚĆ"
        big.value.textSize = 54f
        power.title.text = "NAPIĘCIE I TEMPERATURY"
        dtc.title.text = "DIAGNOSTYKA DTC"
        addView(big, lp(false, 1.4f, m))
        val right = LinearLayout(ctx)
        right.orientation = VERTICAL
        right.addView(power, lp(true, 1f, m))
        right.addView(dtc, lp(true, 1f, m))
        addView(right, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
        big.setOnClickListener { openModule(1) }
        power.setOnClickListener { openModule(1) }
        dtc.setOnClickListener { openModule(3) }
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {
        val rpm = s.fresh(Param.RPM)
        val spd = s.fresh(Param.SPEED)
        big.value.text = if (rpm == null) "---" else Ui.fmt(rpm, 0) + " obr/min"
        big.sub.text = "Prędkość: " + (if (spd == null) "---" else Ui.fmt(spd, 0) + " km/h")

        val v = s.fresh(Param.VOLT)
        power.value.text = if (v == null) "---" else Ui.fmt(v, 1) + " V"
        val ect = s.fresh(Param.ECT)
        val iat = s.fresh(Param.IAT)
        power.sub.text = "Płyn: " + (if (ect == null) "---" else Ui.fmt(ect, 0) + " °C") +
            "   Ssanie: " + (if (iat == null) "---" else Ui.fmt(iat, 0) + " °C") +
            (if (v != null && s.voltageFromAdapter()) "\nNapięcie z adaptera (nie z ECU)" else "")

        val n = s.codes?.size ?: s.dtcCount
        dtc.value.text = if (n == null) "---" else "Kody: $n"
        dtc.value.setTextColor(if (n != null && n > 0) Ui.RED else Ui.TEXT)
        dtc.sub.text = ObdRepository.statusText.value
    }
}

// ============================================================================= Dane na żywo

class LiveDataView(ctx: Context, private val onSelectionChanged: () -> Unit) : FrameLayout(ctx), Updatable {
    private val rows = LinkedHashMap<Param, Pair<TextView, TextView>>()
    private val rowViews = LinkedHashMap<Param, LinearLayout>()

    init {
        val sv = ScrollView(ctx)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(12))
        col.addView(Ui.text(ctx, "DANE NA ŻYWO  (dotknij wiersz, aby dodać do wykresów – maks. 4)", 13f, Ui.SUB, true))
        for (p in Param.values()) {
            if (p == Param.VOLT) continue
            val row = LinearLayout(ctx)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
            val name = Ui.text(ctx, p.label, 15f, Ui.TEXT, true)
            val value = Ui.text(ctx, "---", 16f, Ui.SUB, true)
            row.addView(name, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            row.addView(value)
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = ctx.dp(6)
            col.addView(row, lp)
            rows[p] = Pair(name, value)
            rowViews[p] = row
            row.setOnClickListener { toggle(p) }
        }
        sv.addView(col)
        addView(sv)
        paintSelection()
    }

    private fun toggle(p: Param) {
        val list = Settings.chartParams.toMutableList()
        if (p in list) list.remove(p) else {
            list.add(p)
            while (list.size > 4) list.removeAt(0) // decyzja: piąty wybór usuwa najstarszy (FIFO)
        }
        Settings.chartParams = list
        paintSelection()
        onSelectionChanged()
    }

    private fun paintSelection() {
        val sel = Settings.chartParams
        for ((p, row) in rowViews) {
            val on = p in sel
            row.background = Ui.round(context, Ui.CARD, if (on) Settings.accent else Ui.BORDER, 12)
        }
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {
        for ((p, pair) in rows) {
            val (txt, color) = Ui.valueText(s, p)
            pair.second.text = txt
            pair.second.setTextColor(color)
        }
    }
}

// ============================================================================= Wykresy

class ChartsView(ctx: Context) : FrameLayout(ctx), Updatable {
    private val body = FrameLayout(ctx)
    private val panels = ArrayList<ChartPanel>()
    private var lastRefresh = 0L
    private var windowSec = Settings.chartWindowSec

    init {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        val head = LinearLayout(ctx)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        head.setPadding(ctx.dp(16), ctx.dp(10), ctx.dp(16), ctx.dp(2))
        head.addView(Ui.text(ctx, "WYKRESY", 13f, Ui.SUB, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        for ((label, sec) in listOf("30 s" to 30, "1 min" to 60, "5 min" to 300)) {
            val b = Ui.button(ctx, label, Ui.BORDER) {
                windowSec = sec
                Settings.chartWindowSec = sec
                for (pn in panels) pn.windowMs = sec * 1000L
                refreshNow()
            }
            val l = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            l.leftMargin = ctx.dp(8)
            head.addView(b, l)
        }
        col.addView(head)
        col.addView(body, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(col)
        rebuild()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) rebuild()
    }

    fun rebuild() {
        val ctx = context
        body.removeAllViews()
        panels.clear()
        val sel = Settings.chartParams
        if (sel.isEmpty()) {
            val t = Ui.text(ctx, "Wybierz parametry w zakładce „Dane”\n(dotknij wiersz – maks. 4 wykresy).", 16f, Ui.SUB)
            t.gravity = Gravity.CENTER
            body.addView(t, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            return
        }
        for (p in sel) {
            val cp = ChartPanel(ctx, p)
            cp.windowMs = windowSec * 1000L
            panels.add(cp)
        }
        val m = ctx.dp(6)
        val root = LinearLayout(ctx)
        root.orientation = LinearLayout.VERTICAL
        when (panels.size) {
            1 -> root.addView(panels[0], lp(true, 1f, m))
            2 -> {
                root.addView(panels[0], lp(true, 1f, m))
                root.addView(panels[1], lp(true, 1f, m))
            }
            3 -> {
                root.orientation = LinearLayout.HORIZONTAL
                root.addView(panels[0], lp(false, 1.2f, m))
                val r = LinearLayout(ctx)
                r.orientation = LinearLayout.VERTICAL
                r.addView(panels[1], lp(true, 1f, m))
                r.addView(panels[2], lp(true, 1f, m))
                root.addView(r, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f))
            }
            else -> {
                for (row in 0..1) {
                    val h = LinearLayout(ctx)
                    h.orientation = LinearLayout.HORIZONTAL
                    h.addView(panels[row * 2], lp(false, 1f, m))
                    h.addView(panels[row * 2 + 1], lp(false, 1f, m))
                    root.addView(h, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
                }
            }
        }
        body.addView(root, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        refreshNow()
    }

    private fun refreshNow() {
        for (pn in panels) pn.refresh()
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {
        val now = SystemClock.uptimeMillis()
        if (now - lastRefresh < 300) return
        lastRefresh = now
        refreshNow()
    }
}

// ============================================================================= DTC

class DtcView(ctx: Context, private val scope: CoroutineScope) : FrameLayout(ctx), Updatable {
    private val status = Ui.text(ctx, "Stan: ---", 18f, Ui.TEXT, true)
    private val result = Ui.text(ctx, "", 14f, Ui.SUB)
    private val vin = Ui.text(ctx, "", 13f, Ui.SUB)
    private val list = LinearLayout(ctx)
    private var stored: List<String>? = null
    private var pending: List<String>? = null
    private var shown = ""

    init {
        val sv = ScrollView(ctx)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(16))
        col.addView(Ui.text(ctx, "DIAGNOSTYKA DTC", 13f, Ui.SUB, true))
        col.addView(status)
        val btns = LinearLayout(ctx)
        btns.orientation = LinearLayout.HORIZONTAL
        val b1 = Ui.button(ctx, "ODCZYTAJ KODY", Settings.accent) { read() }
        val b2 = Ui.button(ctx, "KASUJ DTC", Ui.RED) { clear() }
        val l1 = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        l1.rightMargin = ctx.dp(8)
        btns.addView(b1, l1)
        btns.addView(b2, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl.topMargin = ctx.dp(12)
        col.addView(btns, bl)
        col.addView(result)
        list.orientation = LinearLayout.VERTICAL
        col.addView(list)
        col.addView(vin)
        sv.addView(col)
        addView(sv)
    }

    private fun read() {
        result.text = "Odczyt kodów…"
        scope.launch {
            val r = ObdEngine.readDtcs()
            stored = r.stored
            pending = r.pending
            result.text = r.error ?: "Odczyt zakończony."
            render()
            val v = ObdEngine.readVin()
            vin.text = if (v != null) "VIN: $v" else ""
        }
    }

    private fun clear() {
        result.text = "Kasowanie…"
        scope.launch {
            result.text = ObdEngine.clearDtcs()
            stored = ObdRepository.snapshot.value.codes
            pending = null
            render()
        }
    }

    private fun render() {
        val ctx = context
        val key = (stored?.joinToString(",") ?: "?") + "|" + (pending?.joinToString(",") ?: "?")
        if (key == shown) return
        shown = key
        list.removeAllViews()
        fun add(title: String, codes: List<String>?) {
            if (codes == null) return
            list.addView(Ui.text(ctx, title, 13f, Ui.SUB, true).also { it.setPadding(0, ctx.dp(12), 0, ctx.dp(4)) })
            if (codes.isEmpty()) list.addView(Ui.text(ctx, "Brak kodów", 15f, Ui.GREEN))
            for (c in codes) {
                val t = Ui.text(ctx, c + " – " + DtcDecoder.describe(c), 15f, Ui.TEXT)
                t.setPadding(ctx.dp(12), ctx.dp(8), ctx.dp(12), ctx.dp(8))
                t.background = Ui.round(ctx, Ui.CARD, Ui.RED, 10)
                val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                lp.topMargin = ctx.dp(4)
                list.addView(t, lp)
            }
        }
        add("ZAPISANE KODY (tryb 03)", stored)
        add("OCZEKUJĄCE KODY (tryb 07)", pending)
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {
        val n = s.dtcCount
        status.text = when {
            s.milOn == null -> "Stan: brak danych z ECU"
            s.milOn == true -> "Kontrolka MIL: ŚWIECI (kody wg ECU: " + (n ?: 0) + ")"
            else -> "Kontrolka MIL: wyłączona"
        }
        status.setTextColor(if (s.milOn == true) Ui.ORANGE else Ui.TEXT)
        if (stored == null && s.codes != null) { stored = s.codes; render() }
    }
}

// ============================================================================= Misfire Lab (surowe Mode 06)

class MisfireView(ctx: Context, private val scope: CoroutineScope) : FrameLayout(ctx), Updatable {
    private val out = Ui.text(ctx, "", 14f, Ui.TEXT)

    init {
        val sv = ScrollView(ctx)
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(16))
        col.addView(Ui.text(ctx, "MISFIRE LAB – TRYB 06 (MID A2–A5)", 13f, Ui.SUB, true))
        col.addView(
            Ui.text(
                ctx,
                "Wartości surowe z ECU, bez interpretacji. Znaczenie TID zależy od producenta – aplikacja niczego nie zgaduje.",
                13f, Ui.SUB
            )
        )
        val b = Ui.button(ctx, "ODCZYTAJ", Settings.accent) { read() }
        val bl = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        bl.topMargin = ctx.dp(12)
        col.addView(b, bl)
        col.addView(out)
        sv.addView(col)
        addView(sv)
    }

    private fun read() {
        out.text = "Odczyt…"
        scope.launch {
            val sb = StringBuilder()
            for ((i, mid) in (0xA2..0xA5).withIndex()) {
                sb.append("\nCylinder ").append(i + 1).append(" (MID ").append("%02X".format(mid)).append(")\n")
                for (l in ObdEngine.readMode06(mid)) sb.append("  ").append(l).append('\n')
            }
            out.text = sb.toString()
        }
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {}
}

// ============================================================================= Raw Terminal

class RawView(ctx: Context, private val scope: CoroutineScope) : FrameLayout(ctx), Updatable {
    private val log = Ui.text(ctx, "", 12f, Ui.TEXT)
    private val input = android.widget.EditText(ctx)
    private var shownVersion = -1
    private val sv = ScrollView(ctx)

    init {
        val col = LinearLayout(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(12))
        col.addView(Ui.text(ctx, "RAW TERMINAL ELM327", 13f, Ui.SUB, true))
        col.addView(Ui.text(ctx, "Nie wpisuj poleceń podczas jazdy. Dozwolone: AT oraz tryby 01, 02, 03, 06, 07, 09, 0A.", 12f, Ui.SUB))
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        input.hint = "np. 010C"
        input.setTextColor(Ui.TEXT)
        input.setHintTextColor(Ui.SUB)
        input.isSingleLine = true
        input.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
        row.addView(input, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(Ui.button(ctx, "WYŚLIJ", Settings.accent) { send() })
        col.addView(row)
        log.typeface = android.graphics.Typeface.MONOSPACE
        log.setTextIsSelectable(true)
        sv.addView(log)
        col.addView(sv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        addView(col)
    }

    private fun send() {
        val cmd = input.text.toString()
        input.setText("")
        scope.launch { ObdEngine.sendRaw(cmd) }
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {
        val v = ObdRepository.logVersion
        if (v == shownVersion) return
        shownVersion = v
        log.text = ObdRepository.logText()
        sv.post { sv.fullScroll(View.FOCUS_DOWN) }
    }
}

// ============================================================================= Ustawienia

class SettingsView(
    ctx: Context,
    private val onPickAdapter: () -> Unit,
    private val onReconnect: () -> Unit,
    private val onThemeChanged: () -> Unit
) : FrameLayout(ctx), Updatable {
    private val col = LinearLayout(ctx)

    init {
        val sv = ScrollView(ctx)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(ctx.dp(16), ctx.dp(12), ctx.dp(16), ctx.dp(16))
        sv.addView(col)
        addView(sv)
        rebuild()
    }

    override fun onVisibilityChanged(changedView: View, visibility: Int) {
        super.onVisibilityChanged(changedView, visibility)
        if (visibility == VISIBLE) rebuild()
    }

    private fun row(title: String, value: String, onClick: () -> Unit) {
        val ctx = context
        val r = LinearLayout(ctx)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.setPadding(ctx.dp(16), ctx.dp(14), ctx.dp(16), ctx.dp(14))
        r.background = Ui.round(ctx, Ui.CARD, Ui.BORDER, 12)
        r.addView(Ui.text(ctx, title, 15f, Ui.TEXT, true), LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        r.addView(Ui.text(ctx, value, 15f, Ui.SUB))
        r.setOnClickListener { onClick() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = ctx.dp(6)
        col.addView(r, lp)
    }

    private fun header(s: String) {
        val t = Ui.text(context, s, 13f, Ui.SUB, true)
        t.setPadding(0, context.dp(14), 0, context.dp(2))
        col.addView(t)
    }

    private fun askNumber(title: String, current: String, onOk: (Double) -> Unit) {
        val et = android.widget.EditText(context)
        et.setText(current)
        et.inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL
        AlertDialog.Builder(context)
            .setTitle(title)
            .setView(et)
            .setPositiveButton("Zapisz") { _, _ ->
                val v = et.text.toString().replace(',', '.').toDoubleOrNull()
                if (v != null) { onOk(v); rebuild() }
            }
            .setNegativeButton("Anuluj", null)
            .show()
    }

    private fun choose(title: String, items: List<String>, onPick: (Int) -> Unit) {
        AlertDialog.Builder(context)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, i -> onPick(i); rebuild() }
            .show()
    }

    fun rebuild() {
        col.removeAllViews()
        col.addView(Ui.text(context, "USTAWIENIA", 13f, Ui.SUB, true))

        header("POŁĄCZENIE OBD")
        row("Adapter OBD (Bluetooth)", Settings.adapterName ?: Settings.adapterMac ?: "nie wybrano") { onPickAdapter() }
        row("Połącz ponownie", "") { onReconnect() }
        row("Informacje o adapterze", ObdRepository.adapterInfo.value.ifEmpty { "brak (nie połączono)" }) { }
        row("Auto-kasowanie DTC po otwarciu „Kasuj DTC”", if (Settings.autoClearOnOpen) "włączone" else "wyłączone") {
            Settings.autoClearOnOpen = !Settings.autoClearOnOpen
            rebuild()
        }

        header("WYGLĄD I INTERFEJS")
        val accents = listOf("Stonowany zielony" to 0xFF5FA777.toInt(), "Niebieski (Apple)" to 0xFF0A84FF.toInt(), "Czerwony (Type-R)" to 0xFFFF3B30.toInt(), "Zielony (Emerald)" to 0xFF30D158.toInt())
        row("Kolor akcentu", accents.firstOrNull { it.second == Settings.accent }?.first ?: "własny") {
            choose("Kolor akcentu", accents.map { it.first }) { i -> Settings.accent = accents[i].second; onThemeChanged() }
        }
        row("Tryb startowy", if (Settings.uiMode == "ufo") "Zegary UFO" else "Panel CarPlay") {
            choose("Tryb startowy", listOf("Zegary UFO", "Panel CarPlay")) { i -> Settings.uiMode = if (i == 0) "ufo" else "carplay" }
        }
        row("Jednostka prędkości", if (Settings.speedMph) "mph" else "km/h") { Settings.speedMph = !Settings.speedMph; rebuild() }
        val speedActs = listOf("Zmień km/h ↔ mph" to "units", "Szybkie kasowanie DTC" to "clear_dtc", "Brak akcji" to "none")
        row("Dotknięcie prędkości", speedActs.firstOrNull { it.second == Settings.speedTapAction }?.first ?: "") {
            choose("Dotknięcie prędkości", speedActs.map { it.first }) { i -> Settings.speedTapAction = speedActs[i].second }
        }
        val quick = listOf("Zapisz event" to "save_event", "Połącz OBD ponownie" to "reconnect", "Szybkie kasowanie DTC" to "clear_dtc", "Przełącz widok (UFO/CarPlay)" to "swap_ui")
        row("Przycisk szybki docka", quick.firstOrNull { it.second == Settings.quickAction }?.first ?: "") {
            choose("Przycisk szybki docka", quick.map { it.first }) { i -> Settings.quickAction = quick[i].second; onThemeChanged() }
        }

        header("PROGI I OSTRZEŻENIA")
        row("Redline (obr/min)", Settings.redlineRpm.toString()) {
            askNumber("Redline (obr/min)", Settings.redlineRpm.toString()) { Settings.redlineRpm = it.toInt() }
        }
        row("Próg wskaźnika VTEC (obr/min)", Settings.vtecRpm.toString()) {
            askNumber("Próg VTEC (obr/min)", Settings.vtecRpm.toString()) { Settings.vtecRpm = it.toInt() }
        }
        row("Alarm temp. płynu (°C)", Settings.ectAlarm.toString()) {
            askNumber("Alarm temp. płynu (°C)", Settings.ectAlarm.toString()) { Settings.ectAlarm = it.toInt() }
        }
        row("Alarm temp. ssania (°C)", Settings.iatAlarm.toString()) {
            askNumber("Alarm temp. ssania (°C)", Settings.iatAlarm.toString()) { Settings.iatAlarm = it.toInt() }
        }
        row("Napięcie – minimum (V)", Settings.voltLow.toString()) {
            askNumber("Napięcie – minimum (V)", Settings.voltLow.toString()) { Settings.voltLow = it.toFloat() }
        }
        row("Napięcie – maksimum (V)", Settings.voltHigh.toString()) {
            askNumber("Napięcie – maksimum (V)", Settings.voltHigh.toString()) { Settings.voltHigh = it.toFloat() }
        }
        row("Limit korekty LTFT (±%)", Settings.ltftLimit.toString()) {
            askNumber("Limit korekty LTFT (±%)", Settings.ltftLimit.toString()) { Settings.ltftLimit = it.toInt() }
        }

        header("O APLIKACJI")
        row("Wersja", "0.1.0 (wersja robocza)") { }
    }

    override fun update(s: VehicleSnapshot, c: ConnState) {}
}
