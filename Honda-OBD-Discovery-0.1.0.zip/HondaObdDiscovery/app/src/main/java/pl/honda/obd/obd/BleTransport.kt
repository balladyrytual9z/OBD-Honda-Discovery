package pl.honda.obd.obd

import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.IOException
import java.util.UUID

/**
 * Transport BLE (GATT) dla adapterów ELM327.
 * Zasady: jedna operacja GATT naraz, twarde timeouty, MTU 185, zapis w paczkach po 20 B,
 * brak CCCD nie jest błędem, czyste zamykanie (disconnect -> odczekanie -> refresh -> close).
 */
class BleTransport(
    private val ctx: Context,
    private val device: BluetoothDevice,
    private val scope: CoroutineScope
) : ElmTransport {

    override val incoming = Channel<ByteArray>(Channel.UNLIMITED)

    private var gatt: BluetoothGatt? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private var writeChar: BluetoothGattCharacteristic? = null

    private val connected = CompletableDeferred<Unit>()
    private val discovered = CompletableDeferred<Boolean>()
    @Volatile private var writeDone: CompletableDeferred<Int>? = null
    @Volatile private var descDone: CompletableDeferred<Int>? = null
    @Volatile private var mtuDone: CompletableDeferred<Int>? = null

    private val cb = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                if (status == BluetoothGatt.GATT_SUCCESS) connected.complete(Unit)
                else connected.completeExceptionally(IOException("Błąd GATT ($status)"))
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                connected.completeExceptionally(IOException("Adapter rozłączony (status $status)"))
                discovered.complete(false)
                writeDone?.complete(-1)
                incoming.close()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            discovered.complete(status == BluetoothGatt.GATT_SUCCESS)
        }

        override fun onMtuChanged(g: BluetoothGatt, mtu: Int, status: Int) {
            mtuDone?.complete(mtu)
        }

        override fun onDescriptorWrite(g: BluetoothGatt, d: BluetoothGattDescriptor, status: Int) {
            descDone?.complete(status)
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, c: BluetoothGattCharacteristic, status: Int) {
            writeDone?.complete(status)
        }

        @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
        override fun onCharacteristicChanged(g: BluetoothGatt, c: BluetoothGattCharacteristic) {
            val v = c.value ?: return
            incoming.trySend(v.copyOf())
        }
    }

    @Suppress("DEPRECATION")
    override suspend fun open() {
        withContext(Dispatchers.Main) {
            gatt = device.connectGatt(ctx, false, cb, BluetoothDevice.TRANSPORT_LE)
        }
        if (withTimeoutOrNull(12_000) { connected.await() } == null) throw IOException("Przekroczono czas łączenia BLE")
        val g = gatt ?: throw IOException("Brak połączenia BLE")
        delay(300)

        // MTU 185 (517 zrywa połączenie w wielu klonach); błąd negocjacji nie jest krytyczny
        try {
            val d = CompletableDeferred<Int>()
            mtuDone = d
            if (g.requestMtu(185)) withTimeoutOrNull(4_000) { d.await() }
        } catch (_: Exception) { }

        if (!g.discoverServices()) throw IOException("Nie można rozpocząć wykrywania usług GATT")
        val ok = withTimeoutOrNull(8_000) { discovered.await() } ?: false
        if (!ok) throw IOException("Nie wykryto usług GATT adaptera")

        pickProfile(g)
        val nc = notifyChar ?: throw IOException("Brak charakterystyki odbioru")
        if (!g.setCharacteristicNotification(nc, true)) throw IOException("Nie można włączyć powiadomień BLE")
        val cccd = nc.getDescriptor(CCCD)
        if (cccd != null) {
            val notify = (nc.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
            cccd.value = if (notify) BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
            else BluetoothGattDescriptor.ENABLE_INDICATION_VALUE
            val d = CompletableDeferred<Int>()
            descDone = d
            if (g.writeDescriptor(cccd)) withTimeoutOrNull(6_000) { d.await() }
        }
        // brak CCCD: wiele klonów mimo to wysyła dane po lokalnym włączeniu powiadomień
    }

    private fun pickProfile(g: BluetoothGatt) {
        for ((svc, n, w) in PROFILES) {
            val s = g.getService(svc) ?: continue
            val nc = s.getCharacteristic(n)
            val wc = s.getCharacteristic(w)
            if (nc != null && wc != null) {
                notifyChar = nc
                writeChar = wc
                return
            }
        }
        // profil nieznany: dowolna usługa z charakterystyką NOTIFY i WRITE
        for (s in g.services) {
            var n: BluetoothGattCharacteristic? = null
            var w: BluetoothGattCharacteristic? = null
            for (c in s.characteristics) {
                val pr = c.properties
                if (n == null && ((pr and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0 ||
                        (pr and BluetoothGattCharacteristic.PROPERTY_INDICATE) != 0)) n = c
                if (w == null && ((pr and BluetoothGattCharacteristic.PROPERTY_WRITE) != 0 ||
                        (pr and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0)) w = c
            }
            if (n != null && w != null) {
                notifyChar = n
                writeChar = w
                return
            }
        }
        throw IOException("Nie rozpoznano usługi UART adaptera BLE")
    }

    @Suppress("DEPRECATION")
    override suspend fun write(cmd: String) {
        val g = gatt ?: throw IOException("Brak połączenia BLE")
        val wc = writeChar ?: throw IOException("Brak charakterystyki zapisu")
        val data = (cmd + "\r").toByteArray(Charsets.US_ASCII)
        val noResp = (wc.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0
        wc.writeType = if (noResp) BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        else BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
        var off = 0
        while (off < data.size) {
            val end = minOf(off + MAX_CHUNK, data.size)
            wc.value = data.copyOfRange(off, end)
            if (noResp) {
                var tries = 0
                while (!g.writeCharacteristic(wc)) {
                    tries++
                    if (tries > 100) throw IOException("Zapis BLE odrzucony przez system")
                    delay(5)
                }
            } else {
                val d = CompletableDeferred<Int>()
                writeDone = d
                if (!g.writeCharacteristic(wc)) throw IOException("Zapis BLE odrzucony przez system")
                val st = withTimeoutOrNull(6_000) { d.await() } ?: throw IOException("Przekroczono czas zapisu BLE")
                if (st != BluetoothGatt.GATT_SUCCESS) throw IOException("Błąd zapisu BLE ($st)")
            }
            off = end
        }
    }

    override fun close() {
        val g = gatt
        gatt = null
        try { g?.disconnect() } catch (_: Exception) { }
        incoming.close()
        if (g != null) {
            scope.launch {
                delay(800)
                try { g.javaClass.getMethod("refresh").invoke(g) } catch (_: Exception) { }
                try { g.close() } catch (_: Exception) { }
            }
        }
    }

    companion object {
        private const val MAX_CHUNK = 20
        private val CCCD: UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

        private fun u16(s: String): UUID = UUID.fromString("0000$s-0000-1000-8000-00805f9b34fb")

        // (usługa, odbiór/notify, zapis/write)
        private val PROFILES = listOf(
            Triple(u16("fff0"), u16("fff1"), u16("fff2")),
            Triple(u16("18f0"), u16("2af0"), u16("2af1")),
            Triple(
                UUID.fromString("e7810a71-73ae-499d-8c15-faa9aef0c3f2"),
                UUID.fromString("bef8d6c9-9c21-4c9e-b632-bd58c1009f9f"),
                UUID.fromString("bef8d6c9-9c21-4c9e-b632-bd58c1009f9f")
            ),
            Triple(u16("ffe0"), u16("ffe1"), u16("ffe1")),
            Triple(
                UUID.fromString("49535343-fe7d-4ae5-8fa9-9fafd205e455"),
                UUID.fromString("49535343-1e4d-4bd9-ba61-23c647249616"),
                UUID.fromString("49535343-8841-43f4-a8d4-ecbe34729bb3")
            ),
            Triple(
                UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e"),
                UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e"),
                UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e")
            )
        )
    }
}
