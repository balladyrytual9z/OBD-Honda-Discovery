package pl.honda.obd.data

import android.content.Context
import android.content.SharedPreferences

object Settings {
    private lateinit var sp: SharedPreferences

    fun init(ctx: Context) {
        sp = ctx.applicationContext.getSharedPreferences("honda_obd", Context.MODE_PRIVATE)
    }

    var adapterMac: String?
        get() = sp.getString("adapter_mac", null)
        set(v) { sp.edit().putString("adapter_mac", v).apply() }

    /** "ble" | "spp" | "auto" (auto = najpierw klasyczny SPP, potem BLE) */
    var adapterKind: String
        get() = sp.getString("adapter_kind", "ble") ?: "ble"
        set(v) { sp.edit().putString("adapter_kind", v).apply() }

    /** Czy „Kasuj DTC” ma skasować kody od razu po otwarciu (jednorazowo, bez pętli). */
    var autoClearOnOpen: Boolean
        get() = sp.getBoolean("auto_clear_open", false)
        set(v) { sp.edit().putBoolean("auto_clear_open", v).apply() }

    var adapterName: String?
        get() = sp.getString("adapter_name", null)
        set(v) { sp.edit().putString("adapter_name", v).apply() }

    /** "ufo" albo "carplay" */
    var uiMode: String
        get() = sp.getString("ui_mode", "ufo") ?: "ufo"
        set(v) { sp.edit().putString("ui_mode", v).apply() }

    var redlineRpm: Int
        get() = sp.getInt("redline", 6300)
        set(v) { sp.edit().putInt("redline", v).apply() }

    var vtecRpm: Int
        get() = sp.getInt("vtec", 5200)
        set(v) { sp.edit().putInt("vtec", v).apply() }

    var ectAlarm: Int
        get() = sp.getInt("ect_alarm", 102)
        set(v) { sp.edit().putInt("ect_alarm", v).apply() }

    var iatAlarm: Int
        get() = sp.getInt("iat_alarm", 65)
        set(v) { sp.edit().putInt("iat_alarm", v).apply() }

    var voltLow: Float
        get() = sp.getFloat("volt_low", 11.8f)
        set(v) { sp.edit().putFloat("volt_low", v).apply() }

    var voltHigh: Float
        get() = sp.getFloat("volt_high", 14.8f)
        set(v) { sp.edit().putFloat("volt_high", v).apply() }

    var ltftLimit: Int
        get() = sp.getInt("ltft_limit", 10)
        set(v) { sp.edit().putInt("ltft_limit", v).apply() }

    var speedMph: Boolean
        get() = sp.getBoolean("speed_mph", false)
        set(v) { sp.edit().putBoolean("speed_mph", v).apply() }

    /** "units" | "clear_dtc" | "none" */
    var speedTapAction: String
        get() = sp.getString("speed_tap", "units") ?: "units"
        set(v) { sp.edit().putString("speed_tap", v).apply() }

    /** "save_event" | "reconnect" | "clear_dtc" | "swap_ui" */
    var quickAction: String
        get() = sp.getString("quick_action", "save_event") ?: "save_event"
        set(v) { sp.edit().putString("quick_action", v).apply() }

    var accent: Int
        get() = sp.getInt("accent", 0xFF0A84FF.toInt())
        set(v) { sp.edit().putInt("accent", v).apply() }

    var chartParams: List<Param>
        get() {
            val s = sp.getString("chart_params", "") ?: ""
            return s.split(",").mapNotNull { n -> Param.values().firstOrNull { it.name == n } }
        }
        set(v) { sp.edit().putString("chart_params", v.joinToString(",") { it.name }).apply() }

    var chartWindowSec: Int
        get() = sp.getInt("chart_window", 60)
        set(v) { sp.edit().putInt("chart_window", v).apply() }
}
