# Honda OBD Discovery

Aplikacja diagnostyczna OBD-II dla Hondy Civic VIII (L13Z1) na radio ESSGOO (Android 9 / API 28 / ARMv7).

## Funkcje

- **Stałe połączenie BLE** z adapterem ELM327 – auto-reconnect w tle bez potwierdzeń
- **UI inspirowane CarPlay** – ciemny motyw, duże karty, dock nawigacyjny
- **Honda OBD Discovery** – główna aplikacja (Overview / Live Data)
- **Kasuj DTC** – osobna pozycja w launcherze, kasowanie jednym kliknięciem (bez dialogu)
- **Misfire Monitor** – widżet Android
- **Ustawienia OBD** – osobny skrót

## Wymagania sprzętowe (ESSGOO)

- Android 9 (API 28)
- ARMv7 (armeabi-v7a only)
- BLE ELM327 (FFF0/FFF1/FFF2 lub auto-probe)
- ~4 GB RAM, Mali-T720

## Budowanie

```bash
./gradlew assembleDebug
# APK: app/build/outputs/apk/debug/app-debug.apk
```

GitHub Actions buduje APK przy każdym pushu (artifact `HondaOBDDiscovery-debug`).

## Pierwsza konfiguracja

1. Zainstaluj APK na radiu.
2. Otwórz **Ustawienia OBD**.
3. Wpisz adres MAC adaptera BLE (np. z aplikacji systemowej Bluetooth).
4. Zapisz i połącz – usługa działa w tle i sama odzyskuje połączenie.

## Uwagi

- Logika BLE/ELM327 wzorowana na sprawdzonych implementacjach (m.in. miskibin/obd2-dashboard).
- Kasowanie DTC bez potwierdzenia – zgodnie z wymaganiami.
- Na MT8163 animacje są ograniczone, UI oparte na Views.
- Mode $06 / Misfire Lab – fundament gotowy, rozszerzenia w kolejnych iteracjach.
