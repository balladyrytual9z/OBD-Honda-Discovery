package com.honda.obd.discovery

import android.content.Context
import android.content.Intent

/**
 * Wysyła napięcie z OBD do Docka (broadcast).
 *
 * Umowa z Dockiem (Ustawienia → Pasek stanu → Źródło napięcia →
 * "Z aplikacji OBD2 Dashboard (broadcast Docka)"):
 *   akcja:  pl.dock.widget.OBD_VOLTAGE
 *   extra:  "voltage" (Float, wolty)
 * Broadcast tylko do pakietu Docka (setPackage), bez uprawnień.
 *
 * Dock uznaje wartość za nieaktualną po 2 minutach bez broadcastu.
 */
object ObdBridge {
    private const val ACTION = "pl.dock.widget.OBD_VOLTAGE"
    private const val DOCK_PACKAGE = "pl.dock.widget"
    private var lastSent = 0L
    private var lastValue = -1f

    fun publish(context: Context, volts: Float) {
        if (volts <= 0f || volts > 40f) return
        val now = System.currentTimeMillis()
        // max 1× / 2 s, chyba że zmiana ≥ 0,1 V
        if (now - lastSent < 2000 && kotlin.math.abs(volts - lastValue) < 0.1f) return
        lastSent = now
        lastValue = volts
        try {
            context.applicationContext.sendBroadcast(
                Intent(ACTION)
                    .setPackage(DOCK_PACKAGE)
                    .putExtra("voltage", volts)
            )
        } catch (_: Throwable) {
        }
    }
}
