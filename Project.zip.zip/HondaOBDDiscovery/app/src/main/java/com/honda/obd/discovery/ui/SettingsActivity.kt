package com.honda.obd.discovery.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.honda.obd.discovery.R
import com.honda.obd.discovery.service.ObdConnectionService

class SettingsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        val prefs = getSharedPreferences("obd_prefs", MODE_PRIVATE)
        val et = findViewById<EditText>(R.id.etBleAddress)
        et.setText(prefs.getString("ble_address", ""))

        findViewById<Button>(R.id.btnSaveConnect).setOnClickListener {
            val addr = et.text.toString().trim().uppercase()
            prefs.edit().putString("ble_address", addr).apply()
            startService(Intent(this, ObdConnectionService::class.java).apply {
                action = ObdConnectionService.ACTION_CONNECT
                putExtra(ObdConnectionService.EXTRA_ADDRESS, addr)
            })
            findViewById<TextView>(R.id.tvAdapterInfo).text = "Adres zapisany. Łączenie w tle…"
        }
    }
}
