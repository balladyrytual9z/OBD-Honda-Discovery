package com.honda.obd.discovery.widget

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import com.honda.obd.discovery.R
import com.honda.obd.discovery.service.ObdConnectionService

class MisfireWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            updateWidget(context, appWidgetManager, id)
        }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == ObdConnectionService.ACTION_DATA_UPDATED ||
            intent.action == "com.honda.obd.discovery.WIDGET_UPDATE"
        ) {
            val mgr = AppWidgetManager.getInstance(context)
            val ids = mgr.getAppWidgetIds(ComponentName(context, MisfireWidgetProvider::class.java))
            onUpdate(context, mgr, ids)
        }
    }

    private fun updateWidget(context: Context, mgr: AppWidgetManager, id: Int) {
        val views = RemoteViews(context.packageName, R.layout.widget_misfire)
        // Widget reads last known values from shared prefs written by service
        val prefs = context.getSharedPreferences("obd_live", Context.MODE_PRIVATE)
        val rpm = prefs.getInt("rpm", -1)
        val ect = prefs.getInt("ect", -999)
        val connected = prefs.getBoolean("connected", false)
        views.setTextViewText(R.id.widgetStatus, if (connected) "Połączono" else "Brak połączenia")
        views.setTextViewText(R.id.widgetRpm, if (rpm >= 0) "$rpm RPM" else "— RPM")
        views.setTextViewText(R.id.widgetEct, if (ect > -100) "ECT $ect °C" else "ECT —")
        mgr.updateAppWidget(id, views)
    }
}
