package com.honda.obd.discovery.ui

import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.honda.obd.discovery.R
import com.honda.obd.discovery.service.ObdConnectionService
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {

    private var service: ObdConnectionService? = null
    private var bound = false
    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    private val dataReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshOverview()
        }
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as ObdConnectionService.LocalBinder).getService()
            bound = true
            refreshOverview()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showFragment(OverviewFragment())

        findViewById<View>(R.id.btnOverview).setOnClickListener { showFragment(OverviewFragment()) }
        findViewById<View>(R.id.btnLive).setOnClickListener { showFragment(OverviewFragment()) }
        findViewById<View>(R.id.btnMisfire).setOnClickListener { showFragment(OverviewFragment()) }
        findViewById<View>(R.id.btnDtc).setOnClickListener {
            startActivity(Intent(this, com.honda.obd.discovery.dtc.ClearDtcActivity::class.java))
        }
        findViewById<View>(R.id.btnSettings).setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
    }

    private fun showFragment(f: Fragment) {
        supportFragmentManager.beginTransaction()
            .setCustomAnimations(
                android.R.anim.slide_in_left,
                android.R.anim.slide_out_right,
                android.R.anim.slide_in_left,
                android.R.anim.slide_out_right
            )
            .replace(R.id.contentContainer, f)
            .commit()
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, ObdConnectionService::class.java), connection, Context.BIND_AUTO_CREATE)
        registerReceiver(dataReceiver, IntentFilter(ObdConnectionService.ACTION_DATA_UPDATED))
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            unbindService(connection)
            bound = false
        }
        try { unregisterReceiver(dataReceiver) } catch (_: Exception) {}
    }

    fun refreshOverview() {
        val frag = supportFragmentManager.findFragmentById(R.id.contentContainer) as? OverviewFragment
            ?: return
        val svc = service ?: return
        frag.update(
            status = when (svc.connectionState.get()) {
                ObdConnectionService.ConnectionState.CONNECTED -> getString(R.string.connected)
                ObdConnectionService.ConnectionState.CONNECTING -> getString(R.string.connecting)
                else -> getString(R.string.disconnected)
            },
            rpm = svc.lastRpm.get(),
            speed = svc.lastSpeed.get(),
            ect = svc.lastEct.get(),
            load = svc.lastLoad.get(),
            voltage = svc.lastVoltage.get(),
            stft = svc.lastStft.get(),
            ltft = svc.lastLtft.get(),
            lastUpdate = svc.lastUpdateMs.get()
        )
    }
}

class OverviewFragment : Fragment(R.layout.fragment_overview) {
    fun update(
        status: String,
        rpm: Int?,
        speed: Int?,
        ect: Int?,
        load: Float?,
        voltage: Float?,
        stft: Float?,
        ltft: Float?,
        lastUpdate: Long
    ) {
        view?.findViewById<TextView>(R.id.tvConnectionStatus)?.apply {
            text = status
            setTextColor(
                resources.getColor(
                    if (status.contains("Połączono", true)) R.color.success else R.color.error,
                    null
                )
            )
        }
        view?.findViewById<TextView>(R.id.tvRpm)?.text = rpm?.toString() ?: "—"
        view?.findViewById<TextView>(R.id.tvSpeed)?.text = speed?.toString() ?: "—"
        view?.findViewById<TextView>(R.id.tvEct)?.text = ect?.toString() ?: "—"
        view?.findViewById<TextView>(R.id.tvLoad)?.text = load?.let { "%.0f".format(it) } ?: "—"
        view?.findViewById<TextView>(R.id.tvVoltage)?.text = voltage?.let { "%.1f".format(it) } ?: "—"
        view?.findViewById<TextView>(R.id.tvStft)?.text = stft?.let { "%+.1f%%".format(it) } ?: "—"
        view?.findViewById<TextView>(R.id.tvLtft)?.text = ltft?.let { "%+.1f%%".format(it) } ?: "—"
        val ago = if (lastUpdate > 0) {
            val s = (System.currentTimeMillis() - lastUpdate) / 1000
            if (s < 5) "teraz" else "${s}s temu"
        } else ""
        view?.findViewById<TextView>(R.id.tvLastUpdate)?.text = ago
    }
}
