package com.honda.obd.discovery.dtc

import android.content.*
import android.os.Bundle
import android.os.IBinder
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.honda.obd.discovery.R
import com.honda.obd.discovery.service.ObdConnectionService

/**
 * Separate launcher entry – one-tap DTC clear, no confirmation dialog.
 */
class ClearDtcActivity : AppCompatActivity() {

    private var service: ObdConnectionService? = null
    private var bound = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            service = (binder as ObdConnectionService.LocalBinder).getService()
            bound = true
            updateStatus()
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            service = null
            bound = false
        }
    }

    private val resultReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val ok = intent?.getBooleanExtra("success", false) ?: false
            val remaining = intent?.getStringArrayListExtra("remaining") ?: emptyList()
            val tv = findViewById<TextView>(R.id.tvResult)
            if (ok) {
                tv.text = if (remaining.isEmpty())
                    "Kody usunięte. Brak aktywnych DTC."
                else
                    "Wysłano kasowanie. Pozostałe: ${remaining.joinToString()}"
                tv.setTextColor(resources.getColor(R.color.success, null))
            } else {
                tv.text = "Błąd kasowania lub brak odpowiedzi ECU"
                tv.setTextColor(resources.getColor(R.color.error, null))
            }
            findViewById<Button>(R.id.btnClear).isEnabled = true
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_clear_dtc)

        findViewById<Button>(R.id.btnClear).setOnClickListener {
            it.isEnabled = false
            findViewById<TextView>(R.id.tvResult).text = "Kasowanie…"
            // No confirmation – as required
            startService(Intent(this, ObdConnectionService::class.java).apply {
                action = ObdConnectionService.ACTION_CLEAR_DTC
            })
        }
    }

    private fun updateStatus() {
        val svc = service ?: return
        val tv = findViewById<TextView>(R.id.tvStatus)
        when (svc.connectionState.get()) {
            ObdConnectionService.ConnectionState.CONNECTED -> {
                tv.text = getString(R.string.connected)
                tv.setTextColor(resources.getColor(R.color.success, null))
            }
            ObdConnectionService.ConnectionState.CONNECTING -> {
                tv.text = getString(R.string.connecting)
                tv.setTextColor(resources.getColor(R.color.warning, null))
            }
            else -> {
                tv.text = getString(R.string.disconnected)
                tv.setTextColor(resources.getColor(R.color.error, null))
            }
        }
    }

    override fun onStart() {
        super.onStart()
        bindService(Intent(this, ObdConnectionService::class.java), connection, Context.BIND_AUTO_CREATE)
        registerReceiver(resultReceiver, IntentFilter(ObdConnectionService.ACTION_DTC_CLEARED))
    }

    override fun onStop() {
        super.onStop()
        if (bound) {
            unbindService(connection)
            bound = false
        }
        try { unregisterReceiver(resultReceiver) } catch (_: Exception) {}
    }
}
