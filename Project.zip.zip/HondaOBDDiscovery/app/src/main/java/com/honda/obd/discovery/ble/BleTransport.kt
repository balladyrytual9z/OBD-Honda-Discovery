package com.honda.obd.discovery.ble

import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import java.util.*
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicBoolean

/**
 * BLE transport layer for ELM327 adapters.
 * Auto-probes common GATT services (FFF0, FFE0, etc.) used by clones.
 * Designed for continuous connection with automatic recovery.
 */
@SuppressLint("MissingPermission")
class BleTransport(private val context: Context) {

    private val tag = "BleTransport"
    private var bluetoothAdapter: BluetoothAdapter? =
        (context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager).adapter

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var notifyChar: BluetoothGattCharacteristic? = null
    private val isConnected = AtomicBoolean(false)
    private val isConnecting = AtomicBoolean(false)
    private val responseBuffer = StringBuilder()
    private val commandQueue = ConcurrentLinkedQueue<Pair<String, (String) -> Unit>>()
    private var currentCallback: ((String) -> Unit)? = null
    private val handler = Handler(Looper.getMainLooper())
    private var responseTimeout: Runnable? = null

    var onConnectionStateChanged: ((Boolean) -> Unit)? = null
    var onDataReceived: ((String) -> Unit)? = null
    var preferredAddress: String? = null

    // Common ELM327 BLE UUIDs
    private val SERVICE_CANDIDATES = listOf(
        UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ffe0-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ffb0-0000-1000-8000-00805f9b34fb")
    )
    private val WRITE_CANDIDATES = listOf(
        UUID.fromString("0000fff2-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ffb1-0000-1000-8000-00805f9b34fb")
    )
    private val NOTIFY_CANDIDATES = listOf(
        UUID.fromString("0000fff1-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ffe1-0000-1000-8000-00805f9b34fb"),
        UUID.fromString("0000ffb2-0000-1000-8000-00805f9b34fb")
    )
    private val CCCD = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    fun isConnected(): Boolean = isConnected.get()

    fun connect(address: String? = preferredAddress) {
        if (isConnecting.get() || isConnected.get()) return
        val addr = address ?: preferredAddress
        if (addr.isNullOrBlank()) {
            Log.w(tag, "No address to connect")
            return
        }
        preferredAddress = addr
        isConnecting.set(true)
        try {
            val device = bluetoothAdapter?.getRemoteDevice(addr)
            if (device == null) {
                isConnecting.set(false)
                scheduleReconnect()
                return
            }
            gatt = device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
        } catch (e: Exception) {
            Log.e(tag, "connect failed", e)
            isConnecting.set(false)
            scheduleReconnect()
        }
    }

    fun disconnect() {
        handler.removeCallbacksAndMessages(null)
        try {
            gatt?.disconnect()
            gatt?.close()
        } catch (_: Exception) {}
        gatt = null
        writeChar = null
        notifyChar = null
        isConnected.set(false)
        isConnecting.set(false)
        onConnectionStateChanged?.invoke(false)
    }

    fun sendCommand(cmd: String, callback: (String) -> Unit) {
        if (!isConnected.get()) {
            callback("NOT CONNECTED")
            return
        }
        commandQueue.offer(cmd to callback)
        processQueue()
    }

    private fun processQueue() {
        if (currentCallback != null) return
        val next = commandQueue.poll() ?: return
        currentCallback = next.second
        responseBuffer.clear()
        val payload = (next.first.trim() + "\r").toByteArray(Charsets.US_ASCII)
        writeChar?.let { ch ->
            ch.value = payload
            gatt?.writeCharacteristic(ch)
            responseTimeout = Runnable {
                val resp = responseBuffer.toString()
                currentCallback?.invoke(if (resp.isBlank()) "TIMEOUT" else resp)
                currentCallback = null
                processQueue()
            }
            handler.postDelayed(responseTimeout!!, 3000)
        } ?: run {
            currentCallback?.invoke("NO WRITE CHAR")
            currentCallback = null
        }
    }

    private fun scheduleReconnect() {
        handler.postDelayed({
            if (!isConnected.get() && !isConnecting.get() && preferredAddress != null) {
                Log.i(tag, "Auto-reconnecting...")
                connect()
            }
        }, 4000)
    }

    private val gattCallback = object : BluetoothGattCallback() {
        override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
            if (newState == BluetoothProfile.STATE_CONNECTED) {
                Log.i(tag, "GATT connected, discovering services")
                g.discoverServices()
            } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                Log.w(tag, "GATT disconnected status=$status")
                isConnected.set(false)
                isConnecting.set(false)
                writeChar = null
                notifyChar = null
                onConnectionStateChanged?.invoke(false)
                try { g.close() } catch (_: Exception) {}
                gatt = null
                scheduleReconnect()
            }
        }

        override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                isConnecting.set(false)
                scheduleReconnect()
                return
            }
            var found = false
            for (svcUuid in SERVICE_CANDIDATES) {
                val service = g.getService(svcUuid) ?: continue
                for (wUuid in WRITE_CANDIDATES) {
                    val wc = service.getCharacteristic(wUuid)
                    if (wc != null) {
                        writeChar = wc
                        break
                    }
                }
                for (nUuid in NOTIFY_CANDIDATES) {
                    val nc = service.getCharacteristic(nUuid)
                    if (nc != null) {
                        notifyChar = nc
                        break
                    }
                }
                if (writeChar != null && notifyChar != null) {
                    found = true
                    break
                }
            }
            // Fallback: scan all
            if (!found) {
                for (service in g.services) {
                    for (ch in service.characteristics) {
                        val props = ch.properties
                        if (writeChar == null && (props and BluetoothGattCharacteristic.PROPERTY_WRITE != 0 ||
                                    props and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE != 0)
                        ) {
                            writeChar = ch
                        }
                        if (notifyChar == null && (props and BluetoothGattCharacteristic.PROPERTY_NOTIFY != 0 ||
                                    props and BluetoothGattCharacteristic.PROPERTY_INDICATE != 0)
                        ) {
                            notifyChar = ch
                        }
                    }
                }
            }
            if (writeChar != null && notifyChar != null) {
                g.setCharacteristicNotification(notifyChar, true)
                val desc = notifyChar!!.getDescriptor(CCCD)
                if (desc != null) {
                    desc.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                    g.writeDescriptor(desc)
                } else {
                    finishConnect()
                }
            } else {
                Log.e(tag, "Could not find write/notify characteristics")
                isConnecting.set(false)
                scheduleReconnect()
            }
        }

        override fun onDescriptorWrite(g: BluetoothGatt, descriptor: BluetoothGattDescriptor, status: Int) {
            finishConnect()
        }

        private fun finishConnect() {
            isConnected.set(true)
            isConnecting.set(false)
            Log.i(tag, "BLE ready")
            onConnectionStateChanged?.invoke(true)
        }

        override fun onCharacteristicChanged(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic) {
            val data = characteristic.value?.toString(Charsets.US_ASCII) ?: return
            responseBuffer.append(data)
            onDataReceived?.invoke(data)
            if (data.contains(">") || data.contains("OK") || data.contains("ERROR") ||
                data.contains("NO DATA") || data.contains("?") || data.contains("UNABLE")
            ) {
                responseTimeout?.let { handler.removeCallbacks(it) }
                val full = responseBuffer.toString()
                currentCallback?.invoke(full)
                currentCallback = null
                processQueue()
            }
        }

        override fun onCharacteristicWrite(g: BluetoothGatt, characteristic: BluetoothGattCharacteristic, status: Int) {
            // write completed
        }
    }
}
