package com.honda.obd.discovery.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.os.Binder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import com.honda.obd.discovery.ObdApplication
import com.honda.obd.discovery.R
import com.honda.obd.discovery.ble.BleTransport
import com.honda.obd.discovery.data.LiveReading
import com.honda.obd.discovery.obd.Elm327Engine
import com.honda.obd.discovery.ui.MainActivity
import kotlinx.coroutines.*
import java.util.concurrent.atomic.AtomicReference

/**
 * Persistent foreground service that keeps BLE connection alive
 * and auto-reconnects without user interaction.
 */
class ObdConnectionService : Service() {

    private val binder = LocalBinder()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private lateinit var transport: BleTransport
    private lateinit var engine: Elm327Engine
    private var wakeLock: PowerManager.WakeLock? = null
    private var pollJob: Job? = null

    val connectionState = AtomicReference(ConnectionState.DISCONNECTED)
    val lastRpm = AtomicReference<Int?>(null)
    val lastSpeed = AtomicReference<Int?>(null)
    val lastEct = AtomicReference<Int?>(null)
    val lastLoad = AtomicReference<Float?>(null)
    val lastVoltage = AtomicReference<Float?>(null)
    val lastStft = AtomicReference<Float?>(null)
    val lastLtft = AtomicReference<Float?>(null)
    val lastDtc = AtomicReference<List<String>>(emptyList())
    val lastUpdateMs = AtomicReference(0L)

    enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

    inner class LocalBinder : Binder() {
        fun getService(): ObdConnectionService = this@ObdConnectionService
    }

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        transport = BleTransport(this)
        engine = Elm327Engine(transport)
        transport.onConnectionStateChanged = { connected ->
            if (connected) {
                connectionState.set(ConnectionState.CONNECTED)
                updateNotification("Połączono z OBD")
                scope.launch {
                    engine.initialize()
                    startPolling()
                }
            } else {
                connectionState.set(ConnectionState.DISCONNECTED)
                updateNotification("Rozłączono – ponawiam…")
                getSharedPreferences("obd_live", MODE_PRIVATE).edit()
                    .putBoolean("connected", false).apply()
                stopPolling()
            }
        }
        val prefs = getSharedPreferences("obd_prefs", MODE_PRIVATE)
        val addr = prefs.getString("ble_address", null)
        if (addr != null) {
            transport.preferredAddress = addr
            connectionState.set(ConnectionState.CONNECTING)
            transport.connect(addr)
        }
        startForeground(NOTIFICATION_ID, buildNotification("Inicjalizacja OBD…"))
        acquireWakeLock()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_CONNECT -> {
                val addr = intent.getStringExtra(EXTRA_ADDRESS)
                    ?: getSharedPreferences("obd_prefs", MODE_PRIVATE).getString("ble_address", null)
                if (addr != null) {
                    getSharedPreferences("obd_prefs", MODE_PRIVATE).edit()
                        .putString("ble_address", addr).apply()
                    transport.preferredAddress = addr
                    connectionState.set(ConnectionState.CONNECTING)
                    transport.connect(addr)
                }
            }
            ACTION_DISCONNECT -> {
                transport.disconnect()
                stopPolling()
            }
            ACTION_CLEAR_DTC -> {
                scope.launch {
                    if (engine.isInitialized) {
                        val ok = engine.clearDtc()
                        val remaining = engine.readDtc()
                        lastDtc.set(remaining)
                        sendBroadcast(Intent(ACTION_DTC_CLEARED).apply {
                            putExtra("success", ok)
                            putStringArrayListExtra("remaining", ArrayList(remaining))
                        })
                    }
                }
            }
        }
        return START_STICKY
    }

    private fun startPolling() {
        stopPolling()
        pollJob = scope.launch {
            while (isActive && transport.isConnected()) {
                try {
                    lastRpm.set(engine.readRpm())
                    lastSpeed.set(engine.readSpeed())
                    lastEct.set(engine.readCoolantTemp())
                    lastLoad.set(engine.readEngineLoad())
                    lastVoltage.set(engine.readVoltage())
                    lastStft.set(engine.readStft())
                    lastLtft.set(engine.readLtft())
                    lastUpdateMs.set(System.currentTimeMillis())
                    // Broadcast voltage to Dock (pl.dock.widget)
                    lastVoltage.get()?.let { v ->
                        com.honda.obd.discovery.ObdBridge.publish(this@ObdConnectionService, v)
                    }
                    // Persist sample + widget cache
                    val db = (application as ObdApplication).database
                    db.readingDao().insert(
                        LiveReading(
                            timestamp = System.currentTimeMillis(),
                            rpm = lastRpm.get(),
                            speed = lastSpeed.get(),
                            ect = lastEct.get(),
                            load = lastLoad.get(),
                            voltage = lastVoltage.get(),
                            stft = lastStft.get(),
                            ltft = lastLtft.get()
                        )
                    )
                    getSharedPreferences("obd_live", MODE_PRIVATE).edit()
                        .putInt("rpm", lastRpm.get() ?: -1)
                        .putInt("ect", lastEct.get() ?: -999)
                        .putBoolean("connected", true)
                        .apply()
                    sendBroadcast(Intent(ACTION_DATA_UPDATED))
                    sendBroadcast(Intent("com.honda.obd.discovery.WIDGET_UPDATE"))

                } catch (e: Exception) {
                    // continue
                }
                delay(800) // ~1.25 Hz – safe for cheap ELM clones
            }
        }
    }

    private fun stopPolling() {
        pollJob?.cancel()
        pollJob = null
    }

    private fun acquireWakeLock() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "HondaOBD::Connection").apply {
            acquire(10 * 60 * 60 * 1000L) // 10h
        }
    }

    private fun buildNotification(text: String): Notification {
        val pending = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, ObdApplication.CHANNEL_ID)
            .setContentTitle("Honda OBD Discovery")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_obd)
            .setContentIntent(pending)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
    }

    private fun updateNotification(text: String) {
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(NOTIFICATION_ID, buildNotification(text))
    }

    override fun onDestroy() {
        stopPolling()
        transport.disconnect()
        wakeLock?.release()
        scope.cancel()
        super.onDestroy()
    }

    fun getEngine(): Elm327Engine = engine
    fun getTransport(): BleTransport = transport

    companion object {
        const val NOTIFICATION_ID = 42
        const val ACTION_CONNECT = "com.honda.obd.discovery.CONNECT"
        const val ACTION_DISCONNECT = "com.honda.obd.discovery.DISCONNECT"
        const val ACTION_CLEAR_DTC = "com.honda.obd.discovery.CLEAR_DTC"
        const val ACTION_DATA_UPDATED = "com.honda.obd.discovery.DATA_UPDATED"
        const val ACTION_DTC_CLEARED = "com.honda.obd.discovery.DTC_CLEARED"
        const val EXTRA_ADDRESS = "address"

        fun start(context: Context) {
            val intent = Intent(context, ObdConnectionService::class.java)
            context.startForegroundService(intent)
        }
    }
}
