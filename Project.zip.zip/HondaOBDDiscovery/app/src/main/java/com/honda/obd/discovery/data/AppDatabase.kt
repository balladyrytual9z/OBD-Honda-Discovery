package com.honda.obd.discovery.data

import android.content.Context
import androidx.room.*

@Entity(tableName = "live_readings")
data class LiveReading(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val timestamp: Long,
    val rpm: Int?,
    val speed: Int?,
    val ect: Int?,
    val load: Float?,
    val voltage: Float?,
    val stft: Float?,
    val ltft: Float?
)

@Dao
interface ReadingDao {
    @Insert
    suspend fun insert(reading: LiveReading)

    @Query("SELECT * FROM live_readings ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getLatest(limit: Int): List<LiveReading>

    @Query("DELETE FROM live_readings WHERE timestamp < :before")
    suspend fun deleteOlderThan(before: Long)
}

@Database(entities = [LiveReading::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun readingDao(): ReadingDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "honda_obd.db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
