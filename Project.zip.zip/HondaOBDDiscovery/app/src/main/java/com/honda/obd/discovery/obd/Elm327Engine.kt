package com.honda.obd.discovery.obd

import android.util.Log
import com.honda.obd.discovery.ble.BleTransport
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

/**
 * ELM327 protocol engine.
 * Init sequence + standard OBD modes.
 * Shared by main app, Clear DTC and widget.
 */
class Elm327Engine(private val transport: BleTransport) {

    private val tag = "Elm327Engine"
    @Volatile var isInitialized = false
        private set

    suspend fun initialize(): Boolean {
        if (!transport.isConnected()) return false
        val cmds = listOf("ATZ", "ATE0", "ATL0", "ATS0", "ATH0", "ATSP0", "ATI")
        for (cmd in cmds) {
            val resp = send(cmd)
            Log.d(tag, "$cmd -> $resp")
            if (cmd == "ATZ") kotlinx.coroutines.delay(1200)
        }
        isInitialized = true
        return true
    }

    suspend fun send(command: String): String = suspendCancellableCoroutine { cont ->
        transport.sendCommand(command) { resp ->
            if (cont.isActive) cont.resume(resp.trim())
        }
    }

    suspend fun readPid(mode: Int, pid: Int): String {
        val cmd = "%02X%02X".format(mode, pid)
        return send(cmd)
    }

    suspend fun getSupportedPidsMode01(): Set<Int> {
        val supported = mutableSetOf<Int>()
        // PID 00, 20, 40, 60, 80, A0
        val ranges = listOf(0x00, 0x20, 0x40, 0x60, 0x80, 0xA0)
        for (base in ranges) {
            val resp = readPid(0x01, base)
            val bytes = parseHexBytes(resp) ?: continue
            if (bytes.size < 4) continue
            for (i in 0 until 4) {
                val b = bytes[i]
                for (bit in 0 until 8) {
                    if ((b.toInt() and (0x80 shr bit)) != 0) {
                        supported.add(base + 1 + i * 8 + bit)
                    }
                }
            }
        }
        return supported
    }

    suspend fun readRpm(): Int? {
        val resp = readPid(0x01, 0x0C)
        val bytes = parseHexBytes(resp) ?: return null
        if (bytes.size < 2) return null
        return ((bytes[0].toInt() and 0xFF) * 256 + (bytes[1].toInt() and 0xFF)) / 4
    }

    suspend fun readSpeed(): Int? {
        val resp = readPid(0x01, 0x0D)
        val bytes = parseHexBytes(resp) ?: return null
        return bytes.getOrNull(0)?.toInt()?.and(0xFF)
    }

    suspend fun readCoolantTemp(): Int? {
        val resp = readPid(0x01, 0x05)
        val bytes = parseHexBytes(resp) ?: return null
        return (bytes.getOrNull(0)?.toInt()?.and(0xFF) ?: return null) - 40
    }

    suspend fun readEngineLoad(): Float? {
        val resp = readPid(0x01, 0x04)
        val bytes = parseHexBytes(resp) ?: return null
        return (bytes.getOrNull(0)?.toInt()?.and(0xFF) ?: return null) * 100f / 255f
    }

    suspend fun readVoltage(): Float? {
        val resp = readPid(0x01, 0x42)
        val bytes = parseHexBytes(resp) ?: return null
        if (bytes.size < 2) return null
        return ((bytes[0].toInt() and 0xFF) * 256 + (bytes[1].toInt() and 0xFF)) / 1000f
    }

    suspend fun readStft(): Float? {
        val resp = readPid(0x01, 0x06)
        val bytes = parseHexBytes(resp) ?: return null
        return ((bytes.getOrNull(0)?.toInt()?.and(0xFF) ?: return null) - 128) * 100f / 128f
    }

    suspend fun readLtft(): Float? {
        val resp = readPid(0x01, 0x07)
        val bytes = parseHexBytes(resp) ?: return null
        return ((bytes.getOrNull(0)?.toInt()?.and(0xFF) ?: return null) - 128) * 100f / 128f
    }

    suspend fun readDtc(): List<String> {
        val resp = send("03")
        return parseDtcResponse(resp)
    }

    suspend fun readPendingDtc(): List<String> {
        val resp = send("07")
        return parseDtcResponse(resp)
    }

    suspend fun clearDtc(): Boolean {
        val resp = send("04")
        return resp.contains("44") || resp.contains("OK") || resp.contains(">")
    }

    suspend fun readMode06(): String {
        return send("06")
    }

    private fun parseHexBytes(raw: String): ByteArray? {
        val clean = raw
            .replace("SEARCHING...", "", ignoreCase = true)
            .replace("STOPPED", "", ignoreCase = true)
            .replace(">", "")
            .replace("\r", "")
            .replace("\n", " ")
            .trim()
        val parts = clean.split(Regex("\\s+")).filter { it.matches(Regex("[0-9A-Fa-f]{2,}")) }
        if (parts.isEmpty()) return null
        // Take last meaningful frame (skip header if present)
        val hex = parts.lastOrNull { it.length >= 2 } ?: return null
        // Response for mode 01 usually starts with 41 xx
        val dataHex = if (hex.length > 4 && hex.startsWith("41", ignoreCase = true)) {
            hex.substring(4)
        } else if (hex.length > 2) {
            hex
        } else return null
        return try {
            dataHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        } catch (_: Exception) {
            null
        }
    }

    private fun parseDtcResponse(raw: String): List<String> {
        val codes = mutableListOf<String>()
        val clean = raw.replace(">", "").replace("\r", " ").replace("\n", " ")
        val hexParts = clean.split(Regex("\\s+")).filter { it.matches(Regex("[0-9A-Fa-f]+")) }
        // Mode 03 response: 43 xx xx xx xx ...
        val data = hexParts.joinToString("").uppercase()
        val start = data.indexOf("43")
        if (start < 0) return codes
        var i = start + 2
        while (i + 3 < data.length) {
            val a = data.substring(i, i + 2).toIntOrNull(16) ?: break
            val b = data.substring(i + 2, i + 4).toIntOrNull(16) ?: break
            if (a == 0 && b == 0) break
            val type = when (a shr 6) {
                0 -> "P"
                1 -> "C"
                2 -> "B"
                else -> "U"
            }
            val code = "%s%01X%02X".format(type, a and 0x3F, b)
            codes.add(code)
            i += 4
        }
        return codes
    }
}
