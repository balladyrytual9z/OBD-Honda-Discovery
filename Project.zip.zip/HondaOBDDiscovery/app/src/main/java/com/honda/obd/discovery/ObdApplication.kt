package com.honda.obd.discovery

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import com.honda.obd.discovery.data.AppDatabase
import com.honda.obd.discovery.service.ObdConnectionService

class ObdApplication : Application() {
    val database by lazy { AppDatabase.getInstance(this) }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        // Auto-start connection service on app launch
        ObdConnectionService.start(this)
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "OBD Connection",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Persistent OBD-II connection status"
                setShowBadge(false)
            }
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "obd_connection_channel"
    }
}
