# Keep OBD classes
-keep class com.honda.obd.discovery.** { *; }
