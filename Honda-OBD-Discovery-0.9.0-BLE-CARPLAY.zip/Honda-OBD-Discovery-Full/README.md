# Honda OBD Discovery 0.9.0

Android OBD-II dashboard based on the supplied `obd2-dashboard` source snapshot, extended for the ESSGOO Android 9 / API 28 head unit and the Honda Civic VIII L13Z1.

## Implemented in this package

- BLE GATT ELM transport with common profiles and fallback characteristic detection; serialized GATT operations, ELM response framing, reconnect/state handling and one shared connection manager.
- SAE J1979 / OBD-II engine data scheduler, supported PID discovery, provenance/quality status, DTC modes, freeze-frame, readiness, Mode 06 tests, VIN/vehicle information where supported, raw connection logs and CSV/trip history.
- Compose dashboard and readable charts with selectable parameter series, trip summaries, diagnostics and connection settings.
- Bottom dock action **KASUJ DTC**: no confirmation dialog. The press animation/ripple and temporary status are confined to the button. It only shows **WYSŁANO** when the ECU accepts Mode 04; it does not claim that a recurring fault is repaired or that permanent DTCs must disappear.
- A second launcher entry **Kasuj DTC** performs the same no-confirmation operation using the process-wide connection, or attempts to auto-connect to the remembered adapter; it never opens a second independent BLE client.
- Persistent foreground connection service during an active OBD session; the service keeps the process around the single shared connection and its reconnect manager. Android/OEM power management can still terminate services, so absolute 24/7 connectivity cannot be guaranteed.
- Live telemetry bridge for external launchers: broadcast action `com.miskibin.obd2dashboard.LIVE_VOLTAGE`, plus read-only provider `content://com.miskibin.obd2dashboard.live/voltage` and provider method `get_live_voltage`.
- Resizable Android home-screen widget with rounded 25dp corners, live voltage/RPM/coolant, last available Mode 06 misfire result and a sparkline drawn only when a new real RPM sample arrives.
- GitHub Actions workflow using Gradle 8.13 and JDK 17, running unit tests and producing a debug APK artifact.

## Launcher voltage integration

A launcher can register a dynamic receiver for `com.miskibin.obd2dashboard.LIVE_VOLTAGE`. Extras:

- `voltage_v` (`double`): latest voltage reported by `ATRV`.
- `timestamp_ms` (`long`): timestamp of that voltage sample.
- `source` (`String`): `ELM327 ATRV / napięcie na gnieździe OBD`.
- `connected` (`boolean`): whether the real OBD session is currently connected.
- `rpm` (`double`), `speed_kmh` (`double`), `coolant_c` (`double`), `engine_load_pct` (`double`), `sample_timestamp_ms` (`long`). Missing metrics are `NaN`, not fabricated zeros.

To read the last cached values without waiting for a broadcast, call:

```kotlin
val uri = android.net.Uri.parse("content://com.miskibin.obd2dashboard.live")
val result = contentResolver.call(uri, "get_live_voltage", null, null)
val voltage = result?.getDouble("voltage_v", Double.NaN)
val timestamp = result?.getLong("timestamp_ms", 0L) ?: 0L
val source = result?.getString("source")
val connected = result?.getBoolean("connected", false) ?: false
```

`ATRV` is the adapter's voltage estimate at the vehicle OBD socket. It is not a separate ECU voltage PID and must be labelled accordingly. A launcher should mark the value stale when the timestamp is old, rather than continue presenting it as live.

## Build

Recommended: push the project to GitHub and run **Actions → Honda OBD Discovery · build and tests → Run workflow**. The workflow installs Gradle 8.14.3 directly, so it does not depend on a local wrapper JAR. For a local CLI build, install Gradle 8.14.3 and JDK 17, then run `gradle :app:assembleDebug`. The text snapshot did not contain the Gradle wrapper JAR, so `./gradlew` is not the supported build path in this package. The artifact is named `Honda-OBD-Discovery-0.9.0-debug`.

## Important verification status

The ZIP is a reconstructed source package from the available text snapshot, not a device-tested release. This environment does not have Gradle or Android SDK tools available, so I have **not** confirmed that the APK compiles, that the UI fits the ESSGOO panel, or that the BLE adapter/ECU works end-to-end. The GitHub Actions build is the next required verification step. Honda-specific PID definitions and Mode 06 cylinder mappings must remain marked unverified until confirmed against actual responses from this ECU.
