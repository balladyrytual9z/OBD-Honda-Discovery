package com.miskibin.obd2dashboard.obd

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class HondaSafetyTest {
    @Test fun blocksUnverifiedWriteAndActuatorServices() {
        assertTrue(SafeObdCommandPolicy.validateReadOnly("2E1234") != null)
        assertTrue(SafeObdCommandPolicy.validateReadOnly("31011001") != null)
        assertTrue(SafeObdCommandPolicy.validateReadOnly("301501") != null)
        assertNull(SafeObdCommandPolicy.validateReadOnly("0133"))
        assertNull(SafeObdCommandPolicy.validateReadOnly("220123"))
    }

    @Test fun rejectsMalformedRawCommands() {
        assertTrue(SafeObdCommandPolicy.validateReadOnly("01 3G") != null)
        assertTrue(SafeObdCommandPolicy.validateReadOnly("013") != null)
        assertTrue(SafeObdCommandPolicy.validateReadOnly("") != null)
    }

    @Test fun crankingGuardRequiresStableRunningAndChargingVoltage() {
        assertFalse(CrankingProtection.mayQuery(250.0, 9.8, 5))
        assertFalse(CrankingProtection.mayQuery(800.0, 12.6, 5))
        assertFalse(CrankingProtection.mayQuery(800.0, 13.5, 2))
        assertTrue(CrankingProtection.mayQuery(800.0, 13.5, 3))
    }

    @Test fun relativeCompressionOnlyReturnsExperimentalSpread() {
        val analyzer = RelativeCompressionAnalyzer()
        repeat(20) { i -> analyzer.recordCrankingSample(i.toLong(), 200 + (i % 3)) }
        val result = analyzer.evaluate()
        assertTrue(result is RelativeCompressionAnalyzer.Result.ExperimentalSpread)
        assertEquals(2, (result as RelativeCompressionAnalyzer.Result.ExperimentalSpread).spreadRpm)
    }
}
