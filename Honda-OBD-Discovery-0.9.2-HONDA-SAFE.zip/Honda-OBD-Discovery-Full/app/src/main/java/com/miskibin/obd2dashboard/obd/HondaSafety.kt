package com.miskibin.obd2dashboard.obd

/** Result of a read-only Honda-enhanced Mode 22 query. Raw bytes are deliberately not decoded
 * unless a vehicle-specific DID definition has been independently verified. */
sealed interface Mode22ReadResult {
    data class Data(val did: String, val bytes: List<Int>) : Mode22ReadResult
    data class Refused(val did: String, val code: Int) : Mode22ReadResult
    data class Blocked(val reason: String) : Mode22ReadResult
    data object NoData : Mode22ReadResult
}

/** Guard for any future raw-command UI. The app must never expose unrestricted ECU writes. */
object SafeObdCommandPolicy {
    private val hexOnly = Regex("^[0-9A-F]+$")
    private val blockedServices = setOf(0x10, 0x11, 0x2E, 0x2F, 0x31, 0x34, 0x36, 0x37, 0x3B, 0x85)

    fun validateReadOnly(command: String): String? {
        val compact = command.filterNot(Char::isWhitespace).uppercase()
        if (compact.isEmpty() || !hexOnly.matches(compact) || compact.length % 2 != 0) {
            return "Polecenie musi być parzystą liczbą bajtów zapisanych szesnastkowo."
        }
        val service = compact.take(2).toIntOrNull(16) ?: return "Nieprawidłowa usługa."
        if (service in blockedServices) return "Usługa zablokowana przez blokadę bezpieczeństwa."
        if (service !in setOf(0x01, 0x02, 0x03, 0x07, 0x09, 0x0A, 0x22)) {
            return "Dozwolone są wyłącznie jawnie obsługiwane usługi odczytu."
        }
        return null
    }
}

/** State machine used by advanced reads to avoid extra traffic during starter cranking. */
object CrankingProtection {
    fun mayQuery(rpm: Double?, adapterVoltage: Double?, stableSamples: Int): Boolean {
        if (rpm == null || !rpm.isFinite()) return false
        if (rpm in 1.0..599.9) return false
        if (adapterVoltage != null && adapterVoltage.isFinite() && adapterVoltage < 10.5) return false
        return rpm >= 600.0 && adapterVoltage != null && adapterVoltage >= 13.2 && stableSamples >= 3
    }
}

