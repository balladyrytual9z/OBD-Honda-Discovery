package com.miskibin.obd2dashboard.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.widget.RemoteViews
import com.miskibin.obd2dashboard.LiveDataProvider
import com.miskibin.obd2dashboard.MainActivity
import com.miskibin.obd2dashboard.R
import java.util.concurrent.TimeUnit
import kotlin.math.max

/** Real resizable Android home-screen widget, updated from the shared live telemetry cache. */
class MisfireMonitorWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { updateOne(context, manager, it) }
    }

    companion object {
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, MisfireMonitorWidgetProvider::class.java))
            ids.forEach { updateOne(context, manager, it) }
        }

        private fun updateOne(context: Context, manager: AppWidgetManager, id: Int) {
            val prefs = context.getSharedPreferences(LiveDataProvider.PREFS, Context.MODE_PRIVATE)
            val views = RemoteViews(context.packageName, R.layout.widget_misfire_monitor)
            val connected = prefs.getBoolean(LiveDataProvider.KEY_CONNECTED, false)
            val voltage = if (prefs.contains(LiveDataProvider.KEY_VOLTAGE)) prefs.getFloat(LiveDataProvider.KEY_VOLTAGE, Float.NaN).toDouble() else Double.NaN
            val rpm = if (prefs.contains(LiveDataProvider.KEY_RPM)) prefs.getFloat(LiveDataProvider.KEY_RPM, Float.NaN).toDouble() else Double.NaN
            val coolant = if (prefs.contains(LiveDataProvider.KEY_COOLANT)) prefs.getFloat(LiveDataProvider.KEY_COOLANT, Float.NaN).toDouble() else Double.NaN
            val at = prefs.getLong(LiveDataProvider.KEY_TIMESTAMP, 0L)
            val age = if (at > 0) System.currentTimeMillis() - at else Long.MAX_VALUE
            val fresh = age < TimeUnit.SECONDS.toMillis(5)
            views.setTextViewText(R.id.widget_connection, when {
                connected && fresh -> "POŁĄCZONO"
                connected -> "DANE STARE"
                at > 0 -> "ROZŁĄCZONO"
                else -> "BRAK DANYCH"
            })
            views.setTextViewText(R.id.widget_voltage, if (voltage.isFinite()) String.format(java.util.Locale.US, "%.1f V", voltage) else "--.- V")
            views.setTextViewText(R.id.widget_rpm, if (rpm.isFinite()) String.format(java.util.Locale.US, "%.0f rpm", rpm) else "-- rpm")
            views.setTextViewText(R.id.widget_coolant, if (coolant.isFinite()) String.format(java.util.Locale.US, "%.0f °C", coolant) else "-- °C")
            val hasMisfire = prefs.contains("misfire_count")
            val misfireCount = prefs.getFloat("misfire_count", Float.NaN).toDouble()
            val misfirePassed = prefs.getBoolean("misfire_passed", false)
            val misfireAt = prefs.getLong("misfire_at", 0L)
            val misfireAge = if (misfireAt > 0) TimeUnit.MILLISECONDS.toMinutes(max(0L, System.currentTimeMillis() - misfireAt)) else 0L
            views.setTextViewText(R.id.widget_misfire, when {
                !hasMisfire -> "Mode 06 · brak odczytu misfire"
                !misfireCount.isFinite() -> "Mode 06 · wynik nieprawidłowy"
                else -> "Mode 06 · misfire ${String.format(java.util.Locale.US, "%.0f", misfireCount)} · ${if (misfirePassed) "PASS" else "CHECK"} · ${misfireAge} min temu"
            })
            views.setTextViewText(R.id.widget_updated, if (at > 0) "Napięcie zmierzone ${TimeUnit.MILLISECONDS.toSeconds(max(0L, age))} s temu · ATRV / gniazdo OBD" else "Czekam na rzeczywiste próbki OBD")
            views.setImageViewBitmap(R.id.widget_rpm_chart, sparkline(context, prefs.getString(KEY_RPM_HISTORY, "").orEmpty()))
            val open = PendingIntent.getActivity(
                context, 100 + id, Intent(context, MainActivity::class.java),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
            )
            views.setOnClickPendingIntent(R.id.widget_root, open)
            manager.updateAppWidget(id, views)
        }

        private fun sparkline(context: Context, encoded: String): Bitmap {
            val density = context.resources.displayMetrics.density
            val width = (600 * density).toInt().coerceAtLeast(300)
            val height = (70 * density).toInt().coerceAtLeast(35)
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val values = encoded.split(',').mapNotNull { it.toFloatOrNull() }.takeLast(30)
            val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.rgb(199, 240, 168)
                style = Paint.Style.STROKE
                strokeWidth = 2.5f * density
                strokeCap = Paint.Cap.ROUND
                strokeJoin = Paint.Join.ROUND
            }
            val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                color = android.graphics.Color.argb(55, 190, 220, 190)
                strokeWidth = 1f * density
            }
            for (i in 1..3) canvas.drawLine(0f, height * i / 4f, width.toFloat(), height * i / 4f, grid)
            if (values.size >= 2) {
                val minV = values.minOrNull() ?: 0f
                val maxV = values.maxOrNull() ?: 1f
                val range = max(1f, maxV - minV)
                val path = Path()
                values.forEachIndexed { index, value ->
                    val x = (width - 8f * density) * index / (values.size - 1).toFloat() + 4f * density
                    val y = height - 5f * density - ((value - minV) / range) * (height - 10f * density)
                    if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                canvas.drawPath(path, line)
            }
            return bitmap
        }

        const val KEY_RPM_HISTORY = "rpm_history"
        const val KEY_RPM_TIMESTAMP = "rpm_history_timestamp"
    }
}
