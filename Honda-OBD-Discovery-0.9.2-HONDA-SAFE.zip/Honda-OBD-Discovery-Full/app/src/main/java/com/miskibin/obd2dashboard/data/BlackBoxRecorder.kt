package com.miskibin.obd2dashboard.data

import android.content.Context
import com.miskibin.obd2dashboard.obd.VehicleSnapshot
import java.io.File
import java.util.ArrayDeque
import java.util.Locale
import org.json.JSONArray
import org.json.JSONObject

/**
 * Small pre-event telemetry recorder. It keeps the last 300 actual snapshots in RAM and,
 * on a sudden speed discontinuity, atomically saves the complete window as a locked event
 * file. This is an anomaly recorder, not a crash detector: OBD sample gaps and wheel-speed
 * filtering can produce false positives, so every file records the trigger and timing.
 */
class BlackBoxRecorder(
    context: Context,
    private val capacity: Int = DEFAULT_CAPACITY,
    private val clock: () -> Long = System::currentTimeMillis,
) {
    data class Sample(
        val atMillis: Long,
        val speedKmh: Double?,
        val rpm: Double?,
        val coolantC: Double?,
        val voltageV: Double?,
        val values: Map<String, Double>,
    )

    private val directory = File(context.applicationContext.filesDir, "blackbox")
    private val samples = ArrayDeque<Sample>(capacity)
    private val lock = Any()
    private var lastEventAt = 0L

    fun accept(snapshot: VehicleSnapshot) {
        val now = snapshot.updatedAtMillis.takeIf { it > 0L } ?: clock()
        val values = linkedMapOf<String, Double>()
        snapshot.readings.values.forEach { reading -> values[reading.name] = reading.value }
        snapshot.extended.forEach { (id, reading) -> values[id] = reading.value }
        val sample = Sample(
            atMillis = now,
            speedKmh = snapshot.valueOf(Metrics.Speed),
            rpm = snapshot.valueOf(Metrics.Rpm),
            coolantC = snapshot.valueOf(Metrics.CoolantTemp),
            voltageV = snapshot.batteryVoltage,
            values = values,
        )
        synchronized(lock) {
            val previous = samples.peekLast()
            // The polling scheduler can publish several times a second; the black-box
            // buffer intentionally samples at 1 Hz so 300 entries represent ~5 minutes.
            if (previous != null && now - previous.atMillis in 0 until SAMPLE_INTERVAL_MS) return
            if (samples.size == capacity) samples.removeFirst()
            samples.addLast(sample)
            val deltaSpeed = if (previous != null && previous.speedKmh != null && sample.speedKmh != null) {
                previous.speedKmh - sample.speedKmh
            } else null
            val deltaMillis = previous?.let { sample.atMillis - it.atMillis }
            val abruptSpeedDrop = deltaSpeed != null && deltaSpeed >= SPEED_DROP_KMH &&
                deltaMillis != null && deltaMillis in 1..MAX_TRIGGER_INTERVAL_MS
            val abruptRpmDropWithoutVoltage = previous?.rpm != null && sample.rpm != null &&
                previous.rpm!! - sample.rpm!! >= RPM_DROP &&
                (sample.voltageV == null || sample.voltageV < LOW_VOLTAGE_V) &&
                deltaMillis != null && deltaMillis in 1..MAX_TRIGGER_INTERVAL_MS
            if ((abruptSpeedDrop || abruptRpmDropWithoutVoltage) && now - lastEventAt >= EVENT_COOLDOWN_MS) {
                lastEventAt = now
                persistLocked(if (abruptSpeedDrop) "speed_drop" else "rpm_drop_low_voltage", deltaMillis ?: 0L)
            }
        }
    }

    fun recentSamples(): List<Sample> = synchronized(lock) { samples.toList() }

    private fun persistLocked(trigger: String, intervalMillis: Long) {
        if (!directory.exists() && !directory.mkdirs()) return
        val payload = JSONObject().apply {
            put("schema", 1)
            put("locked", true)
            put("trigger", trigger)
            put("triggered_at_ms", clock())
            put("sample_interval_ms", intervalMillis)
            put("vehicle", "Honda Civic VIII 1.4 i-VTEC L13Z1 (configured target)")
            put("samples", JSONArray().apply { samples.forEach { put(it.toJson()) } })
        }
        val stamp = clock()
        val target = File(directory, "event-$stamp.json")
        val temp = File(directory, ".event-$stamp.tmp")
        runCatching {
            temp.writeText(payload.toString(2), Charsets.UTF_8)
            if (!temp.renameTo(target)) {
                target.writeText(temp.readText(Charsets.UTF_8), Charsets.UTF_8)
                temp.delete()
            }
        }
    }

    private fun Sample.toJson() = JSONObject().apply {
        put("at_ms", atMillis)
        putNullable("speed_kmh", speedKmh)
        putNullable("rpm", rpm)
        putNullable("coolant_c", coolantC)
        putNullable("voltage_v", voltageV)
        put("values", JSONObject().apply {
            values.forEach { (key, value) -> put(key, value) }
        })
    }

    private fun JSONObject.putNullable(key: String, value: Double?) {
        if (value == null || !value.isFinite()) put(key, JSONObject.NULL) else put(key, String.format(Locale.US, "%.4f", value).toDouble())
    }

    companion object {
        const val DEFAULT_CAPACITY = 300
        private const val SAMPLE_INTERVAL_MS = 1_000L
        private const val SPEED_DROP_KMH = 35.0
        private const val RPM_DROP = 1_500.0
        private const val LOW_VOLTAGE_V = 11.8
        private const val MAX_TRIGGER_INTERVAL_MS = 1_500L
        private const val EVENT_COOLDOWN_MS = 60_000L
    }
}
