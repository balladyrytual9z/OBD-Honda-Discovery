package com.miskibin.obd2dashboard.ui.fuel

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.DateFormat
import java.util.Date
import java.util.Locale

private data class FuelEntry(
    val id: Long,
    val timestamp: Long,
    val liters: Double,
    val costPln: Double,
    val odometerKm: Int,
    val fullTank: Boolean,
)

@Composable
fun FuelLogScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val entries = remember { mutableStateListOf<FuelEntry>().apply { addAll(loadEntries(context)) } }
    var liters by rememberSaveable { mutableStateOf("") }
    var cost by rememberSaveable { mutableStateOf("") }
    var odometer by rememberSaveable { mutableStateOf("") }
    var fullTank by rememberSaveable { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    val lastConsumption = remember(entries.size) { computeConsumption(entries.toList()).lastOrNull() }

    Column(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Column {
            Text("DZIENNIK TANKOWAŃ", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Realne spalanie liczone metodą pełny–pełny. Wartości są zapisywane lokalnie.", style = MaterialTheme.typography.bodySmall)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(liters, { liters = it }, Modifier.weight(1f), label = { Text("Litry") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(cost, { cost = it }, Modifier.weight(1f), label = { Text("Koszt zł") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
            OutlinedTextField(odometer, { odometer = it }, Modifier.weight(1f), label = { Text("Licznik km") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = fullTank, onCheckedChange = { fullTank = it })
            Text("Tankowanie do pełna")
            Spacer(Modifier.weight(1f))
            Button(onClick = {
                val l = liters.replace(',', '.').toDoubleOrNull()
                val c = cost.replace(',', '.').toDoubleOrNull() ?: 0.0
                val o = odometer.toIntOrNull()
                error = when {
                    l == null || l <= 0.0 -> "Podaj prawidłową liczbę litrów."
                    c < 0.0 -> "Koszt nie może być ujemny."
                    o == null || o < 0 -> "Podaj prawidłowy przebieg."
                    entries.lastOrNull()?.let { o < it.odometerKm } == true -> "Przebieg nie może być niższy niż poprzedni wpis."
                    else -> null
                }
                if (error == null) {
                    entries += FuelEntry(System.currentTimeMillis(), System.currentTimeMillis(), l!!, c, o!!, fullTank)
                    saveEntries(context, entries)
                    liters = ""; cost = ""; odometer = ""
                }
            }) { Text("Dodaj") }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("OSTATNIE SPALANIE REALNE", style = MaterialTheme.typography.labelMedium)
                    Text(lastConsumption?.let { String.format(Locale.US, "%.2f l/100 km", it) } ?: "Za mało tankowań pełny–pełny", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text("Wpisy", style = MaterialTheme.typography.labelSmall)
                    Text(entries.size.toString(), style = MaterialTheme.typography.titleMedium)
                }
            }
        }
        LazyColumn(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(entries.sortedByDescending { it.timestamp }, key = { it.id }) { entry ->
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT).format(Date(entry.timestamp)), fontWeight = FontWeight.SemiBold)
                            Text("${entry.liters} l · ${entry.costPln} zł · ${entry.odometerKm} km · ${if (entry.fullTank) "pełny" else "częściowe"}", style = MaterialTheme.typography.bodySmall)
                        }
                        Button(onClick = { entries.remove(entry); saveEntries(context, entries) }) { Text("Usuń") }
                    }
                }
            }
        }
    }
}

private fun computeConsumption(entries: List<FuelEntry>): List<Double> {
    val ordered = entries.sortedBy(FuelEntry::odometerKm)
    val result = mutableListOf<Double>()
    var previousFullIndex = -1
    ordered.forEachIndexed { index, entry ->
        if (entry.fullTank) {
            if (previousFullIndex >= 0) {
                val previous = ordered[previousFullIndex]
                val distance = entry.odometerKm - previous.odometerKm
                val litersUsed = ordered.subList(previousFullIndex + 1, index + 1).sumOf(FuelEntry::liters)
                if (distance > 0 && litersUsed > 0) result += litersUsed / distance * 100.0
            }
            previousFullIndex = index
        }
    }
    return result
}

private fun loadEntries(context: Context): List<FuelEntry> = runCatching {
    val array = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]"))
    (0 until array.length()).map { i ->
        val o = array.getJSONObject(i)
        FuelEntry(o.getLong("id"), o.getLong("timestamp"), o.getDouble("liters"), o.getDouble("cost"), o.getInt("odometer"), o.getBoolean("full"))
    }
}.getOrDefault(emptyList())

private fun saveEntries(context: Context, entries: List<FuelEntry>) {
    val array = JSONArray()
    entries.forEach { entry -> array.put(JSONObject().apply {
        put("id", entry.id); put("timestamp", entry.timestamp); put("liters", entry.liters)
        put("cost", entry.costPln); put("odometer", entry.odometerKm); put("full", entry.fullTank)
    }) }
    context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, array.toString()).apply()
}

private const val PREFS = "fuel_log"
private const val KEY = "entries_json"
