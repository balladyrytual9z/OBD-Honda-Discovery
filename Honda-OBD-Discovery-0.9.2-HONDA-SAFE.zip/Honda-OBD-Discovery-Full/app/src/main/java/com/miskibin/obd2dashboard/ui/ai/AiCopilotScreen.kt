package com.miskibin.obd2dashboard.ui.ai

import android.content.Intent
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.miskibin.obd2dashboard.data.MetricHistory
import com.miskibin.obd2dashboard.data.Metrics
import com.miskibin.obd2dashboard.data.valueOf
import com.miskibin.obd2dashboard.obd.Diagnostics
import com.miskibin.obd2dashboard.obd.VehicleSnapshot
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

private data class ChatLine(val role: String, val text: String)

/** OpenRouter copilot. API keys stay in this screen's memory and are never written to disk/logs. */
@Composable
fun AiCopilotScreen(
    snapshot: VehicleSnapshot,
    history: MetricHistory,
    diagnostics: Diagnostics?,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("ai_copilot_preferences", 0) }
    var apiKey by remember { mutableStateOf("") }
    var model by rememberSaveable { mutableStateOf(prefs.getString("model", "openai/gpt-4o-mini") ?: "openai/gpt-4o-mini") }
    var masterPrompt by rememberSaveable {
        mutableStateOf(prefs.getString("master_prompt", "Jesteś krótkim, rzeczowym asystentem technicznym Hondy Civic VIII 1.4 i-VTEC. Odróżniaj pomiar od hipotezy. Nie wymyślaj danych ani pewnych diagnoz na podstawie pojedynczego PID-u. Odpowiadaj po polsku, zwięźle i bezpiecznie podczas jazdy.") ?: "")
    }
    var query by rememberSaveable { mutableStateOf("") }
    var includeRpm by rememberSaveable { mutableStateOf(true) }
    var includeSpeed by rememberSaveable { mutableStateOf(true) }
    var includeCoolant by rememberSaveable { mutableStateOf(true) }
    var includeVoltage by rememberSaveable { mutableStateOf(true) }
    var includeDtc by rememberSaveable { mutableStateOf(true) }
    var historyRange by rememberSaveable { mutableStateOf("5 min") }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    val messages = remember { mutableStateListOf<ChatLine>() }
    var lastAnswer by remember { mutableStateOf("") }
    var ttsReady by remember { mutableStateOf(false) }
    var ttsEngine by remember { mutableStateOf<TextToSpeech?>(null) }
    val uiScope = rememberCoroutineScope()
    DisposableEffect(context) {
        val engine = TextToSpeech(context) { status ->
            ttsReady = status == TextToSpeech.SUCCESS
            if (status == TextToSpeech.SUCCESS) ttsEngine?.language = Locale("pl", "PL")
        }
        ttsEngine = engine
        if (ttsReady) engine.language = Locale("pl", "PL")
        onDispose {
            runCatching { engine.stop(); engine.shutdown() }
            ttsEngine = null
            ttsReady = false
        }
    }
    val speechLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (result.resultCode == android.app.Activity.RESULT_OK && !spoken.isNullOrBlank()) query = spoken
    }

    fun vehicleContext(): String {
        val now = System.currentTimeMillis()
        val range = when (historyRange) {
            "1 min" -> 60_000L
            "10 min" -> 600_000L
            else -> 300_000L
        }
        val lines = mutableListOf<String>()
        fun addMetric(label: String, id: com.miskibin.obd2dashboard.data.MetricId, enabled: Boolean) {
            if (!enabled) return
            val current = snapshot.valueOf(id)
            val series = history.series(id, range, now)
            if (current != null) {
                val avg = series.map { it.value.toDouble() }.takeIf { it.isNotEmpty() }?.average()
                lines += "$label: aktualnie ${"%.2f".format(Locale.US, current)}; próbki w zakresie=${series.size}" +
                    (avg?.let { "; średnia ${"%.2f".format(Locale.US, it)}" } ?: "")
            } else lines += "$label: brak aktualnego odczytu"
        }
        addMetric("RPM", Metrics.Rpm, includeRpm)
        addMetric("Prędkość km/h", Metrics.Speed, includeSpeed)
        addMetric("Temperatura płynu °C", Metrics.CoolantTemp, includeCoolant)
        if (includeVoltage) lines += "Napięcie adaptera ATRV: ${snapshot.batteryVoltage?.let { "%.2f V (pomiar ${((now - snapshot.batteryAtMillis).coerceAtLeast(0) / 1000)} s temu)" } ?: "brak odczytu"}"
        if (includeDtc) {
            val codes = diagnostics?.all.orEmpty().map { it.code }.distinct()
            lines += "Kody DTC silnika: ${if (codes.isEmpty()) "brak odczytanych kodów / nieodczytane" else codes.joinToString(", ")}"
        }
        return "Kontekst telemetrii Hondy Civic VIII L13Z1. Zakres historii: $historyRange (pamięć aplikacji, nie pełna historia podróży).\n" + lines.joinToString("\n")
    }

    suspend fun send() {
        val userText = query.trim()
        if (loading || userText.isEmpty()) return
        if (apiKey.isBlank()) { error = "Wpisz klucz API OpenRouter. Klucz pozostaje w pamięci ekranu."; return }
        if (model.isBlank()) { error = "Wpisz identyfikator modelu OpenRouter."; return }
        loading = true
        error = null
        query = ""
        messages += ChatLine("user", userText)
        val contextPayload = vehicleContext()
        val conversation = messages.takeLast(12)
        val prompt = masterPrompt.trim().ifBlank { "Odpowiadaj po polsku, krótko i rzeczowo." } + "\n\nDane auta (traktuj jako pomiary z podanym zakresem, nie jako pewną diagnozę):\n" + contextPayload
        val result = withContext(Dispatchers.IO) {
            runCatching {
                val body = JSONObject().apply {
                    put("model", model.trim())
                    put("messages", JSONArray().apply {
                        put(JSONObject().put("role", "system").put("content", prompt))
                        conversation.forEach { put(JSONObject().put("role", it.role).put("content", it.text)) }
                    })
                    put("temperature", 0.2)
                    put("max_tokens", 700)
                }
                val connection = (URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15_000
                    readTimeout = 30_000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer ${apiKey.trim()}")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                    setRequestProperty("HTTP-Referer", "https://github.com/miskibin/obd2-dashboard")
                    setRequestProperty("X-Title", "Honda OBD Discovery")
                }
                try {
                    connection.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                    val status = connection.responseCode
                    val stream = if (status in 200..299) connection.inputStream else connection.errorStream
                    val raw = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
                    if (status !in 200..299) throw IllegalStateException("OpenRouter HTTP $status: ${raw.take(500)}")
                    JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                } finally { connection.disconnect() }
            }
        }
        result.fold(
            onSuccess = { answer -> messages += ChatLine("assistant", answer); lastAnswer = answer },
            onFailure = { error = it.message ?: "Nie udało się połączyć z OpenRouter." },
        )
        loading = false
        prefs.edit().putString("model", model.trim()).putString("master_prompt", masterPrompt).apply()
    }

    Column(
        modifier = modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(14.dp),
        verticalArrangement = Arrangement.spacedBy(9.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Column(Modifier.weight(1f)) {
                Text("AI COPILOT", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("OpenRouter · telemetria na żądanie · TTS/STT", style = MaterialTheme.typography.bodySmall)
            }
            Button(onClick = {
                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pl-PL")
                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Powiedz, o co chcesz zapytać")
                }
                runCatching { speechLauncher.launch(intent) }.onFailure { error = "Brak dostępnego rozpoznawania mowy." }
            }) { Text("🎙 Mów") }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(apiKey, { apiKey = it }, Modifier.weight(1f), label = { Text("Klucz OpenRouter (tylko w pamięci)") }, singleLine = true)
            OutlinedTextField(model, { model = it }, Modifier.weight(1f), label = { Text("Model ID") }, singleLine = true)
        }
        OutlinedTextField(
            value = masterPrompt, onValueChange = { masterPrompt = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text("Master Prompt") }, minLines = 2, maxLines = 3,
        )
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
            Column(Modifier.padding(horizontal = 10.dp, vertical = 6.dp)) {
                Text("KONTEKST POJAZDU", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ContextCheck("RPM", includeRpm) { includeRpm = it }
                    ContextCheck("Prędkość", includeSpeed) { includeSpeed = it }
                    ContextCheck("ECT", includeCoolant) { includeCoolant = it }
                    ContextCheck("Napięcie", includeVoltage) { includeVoltage = it }
                    ContextCheck("DTC", includeDtc) { includeDtc = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("Historia:", style = MaterialTheme.typography.bodySmall)
                    listOf("1 min", "5 min", "10 min").forEach { range ->
                        Button(onClick = { historyRange = range }, enabled = historyRange != range) { Text(range) }
                    }
                    Text("Wartości niedostępne nie są zgadywane.", style = MaterialTheme.typography.labelSmall)
                }
            }
        }
        Card(modifier = Modifier.weight(1f).fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(16.dp)) {
            LazyColumn(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (messages.isEmpty()) item { Text("Zapytaj o dane z auta, diagnostykę lub możliwe kolejne testy. AI nie zastępuje pomiaru ani naprawy.", style = MaterialTheme.typography.bodyMedium) }
                items(messages) { line ->
                    Column(Modifier.fillMaxWidth().background(if (line.role == "user") MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface, RoundedCornerShape(12.dp)).padding(10.dp)) {
                        Text(if (line.role == "user") "TY" else "AI", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(3.dp))
                        Text(line.text, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                if (loading) item { Row(verticalAlignment = Alignment.CenterVertically) { CircularProgressIndicator(); Text("Łączenie z OpenRouter…", Modifier.padding(start = 10.dp)) } }
                error?.let { message -> item { Text(message, color = MaterialTheme.colorScheme.error) } }
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(query, { query = it }, Modifier.weight(1f), label = { Text("Wpisz pytanie") }, maxLines = 2)
            Button(onClick = { uiScope.launch { send() } }, enabled = !loading && query.isNotBlank()) { Text("Wyślij") }
            Button(onClick = {
                if (lastAnswer.isNotBlank() && ttsReady) ttsEngine?.speak(lastAnswer, TextToSpeech.QUEUE_FLUSH, null, "ai-answer")
            }, enabled = lastAnswer.isNotBlank() && ttsReady) { Text("Czytaj") }
        }
    }
}

@Composable
private fun ContextCheck(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Checkbox(checked = checked, onCheckedChange = onChange)
        Text(label, style = MaterialTheme.typography.labelSmall)
    }
}
