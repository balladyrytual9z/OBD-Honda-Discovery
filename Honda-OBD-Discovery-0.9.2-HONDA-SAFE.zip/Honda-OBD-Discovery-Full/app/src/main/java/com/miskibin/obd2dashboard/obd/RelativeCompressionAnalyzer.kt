package com.miskibin.obd2dashboard.obd

/**
 * Experimental RPM fluctuation recorder. It intentionally does not claim to identify a
 * cylinder or prove compression: standard OBD RPM sampling is too slow and unsynchronised.
 */
class RelativeCompressionAnalyzer(private val minimumSamples: Int = 20) {
    private val samples = ArrayList<Pair<Long, Int>>()

    fun recordCrankingSample(timestampMillis: Long, rpm: Int) {
        if (rpm in 150..400 && (samples.lastOrNull()?.first ?: Long.MIN_VALUE) < timestampMillis) {
            samples += timestampMillis to rpm
            if (samples.size > 500) samples.removeAt(0)
        }
    }

    fun evaluate(): Result {
        if (samples.size < minimumSamples) return Result.Insufficient(samples.size, minimumSamples)
        val values = samples.map { it.second }
        return Result.ExperimentalSpread(
            sampleCount = values.size,
            spreadRpm = (values.maxOrNull() ?: 0) - (values.minOrNull() ?: 0),
            warning = "Wskaźnik orientacyjny. Nie wskazuje cylindra i nie zastępuje pomiaru kompresji ani oscyloskopu CKP."
        )
    }

    fun clear() = samples.clear()

    sealed interface Result {
        data class Insufficient(val actual: Int, val required: Int) : Result
        data class ExperimentalSpread(val sampleCount: Int, val spreadRpm: Int, val warning: String) : Result
    }
}
