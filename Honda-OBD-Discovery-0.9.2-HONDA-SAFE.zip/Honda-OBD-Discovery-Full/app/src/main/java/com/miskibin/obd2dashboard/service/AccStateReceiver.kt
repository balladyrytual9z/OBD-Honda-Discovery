package com.miskibin.obd2dashboard.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.miskibin.obd2dashboard.ObdHolder
import com.miskibin.obd2dashboard.data.UsbBackupManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Optional vehicle-head-unit ACC bridge. The vendor actions are not Android standards;
 * they work only on head units whose MCU actually broadcasts these names. On ACC_OFF the
 * OBD session is closed immediately to avoid keeping the BLE radio and polling loop alive.
 */
class AccStateReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            ACTION_ACC_OFF, Intent.ACTION_SHUTDOWN -> {
                ObdHolder.connection.disconnect()
                ObdHolder.recorder.stop()
                // Give the trip writer time to flush its final row before copying app-private
                // CSV/JSON logs to the USB tree the user explicitly selected in Settings.
                ObdHolder.scope.launch {
                    delay(if (intent.action == Intent.ACTION_SHUTDOWN) 0L else 1_200L)
                    runCatching { UsbBackupManager.backupConfigured(context) }
                }
                context.stopService(Intent(context, ObdConnectionService::class.java))
            }
            ACTION_ACC_ON -> {
                val serviceIntent = Intent(context, ObdConnectionService::class.java)
                    .setAction(ObdConnectionService.ACTION_ACC_RECONNECT)
                ContextCompat.startForegroundService(context, serviceIntent)
            }
        }
    }

    companion object {
        const val ACTION_ACC_ON = "com.car.action.ACC_ON"
        const val ACTION_ACC_OFF = "com.car.action.ACC_OFF"
    }
}
