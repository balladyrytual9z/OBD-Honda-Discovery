package com.miskibin.obd2dashboard.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.obd.Mode22ReadResult
import com.miskibin.obd2dashboard.ui.components.ScreenHeader
import com.miskibin.obd2dashboard.ui.components.ScreenPadding
import com.miskibin.obd2dashboard.ui.theme.Chalk
import com.miskibin.obd2dashboard.ui.theme.Slate
import com.miskibin.obd2dashboard.ui.theme.Smoke
import kotlinx.coroutines.launch

@Composable
fun AdvancedDiagnosticsScreen(
    connected: Boolean,
    onBack: () -> Unit,
    onReadStandard: suspend () -> com.miskibin.obd2dashboard.ble.AdvancedStandardData?,
    onReadMode22: suspend (String, Boolean) -> Mode22ReadResult?,
    modifier: Modifier = Modifier,
) {
    val scope = rememberCoroutineScope()
    var experimentalEnabled by rememberSaveable { mutableStateOf(false) }
    var did by rememberSaveable { mutableStateOf("1234") }
    var status by remember { mutableStateOf("Gotowe. Standardowe odczyty są tylko do odczytu.") }
    var baro by remember { mutableStateOf<String?>(null) }
    var lambda by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }

    Column(modifier = modifier.fillMaxSize()) {
        ScreenHeader(
            title = "Diagnostyka rozszerzona",
            subtitle = "Odczyt bez zapisu do ECU",
            onBack = onBack,
        )
        Column(
            modifier = Modifier.verticalScroll(rememberScrollState())
                .padding(horizontal = ScreenPadding).padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoCard(title = "OBD-II: dane standardowe", body = "Odczytuje wyłącznie obsługiwane PID-y. BARO to PID 01 33. Lambda używa PID 01 24 albo 01 34, jeśli ECU zgłosi go jako obsługiwany; nie zakłada danych producenta.")
            Button(onClick = {
                scope.launch {
                    busy = true
                    status = "Odczytuję…"
                    val result = runCatching { onReadStandard() }.getOrNull()
                    baro = result?.barometricPressureKpa?.takeIf { it.isFinite() }?.let { "%.1f kPa".format(it) } ?: "Brak odpowiedzi / PID nieobsługiwany"
                    lambda = result?.lambda?.takeIf { it.isFinite() }?.let { "%.4f λ".format(it) } ?: "Brak odpowiedzi / PID nieobsługiwany"
                    status = if (result == null) "Brak połączenia albo błąd odczytu." else "Odczyt zakończony. Wartości pochodzą z odpowiedzi ECU."
                    busy = false
                }
            }, enabled = connected && !busy, modifier = Modifier.fillMaxWidth()) { Text(if (busy) "Odczyt…" else "Odczytaj parametry") }
            ValueRow("Ciśnienie barometryczne", baro ?: "—")
            ValueRow("Współczynnik lambda", lambda ?: "—")
            Text(status, color = Smoke, style = MaterialTheme.typography.bodySmall)

            InfoCard(title = "Honda Mode 22 · eksperymentalne", body = "Surowy odczyt DID nie ma tu zweryfikowanej skali ani opisu dla ECU L13Z1. Wynik jest pokazywany wyłącznie jako bajty HEX. Używaj tylko identyfikatora z wiarygodnej dokumentacji dla dokładnego ECU.")
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
                    Text("Włącz odczyt eksperymentalny", color = Chalk, style = MaterialTheme.typography.bodyMedium)
                    Text("Wyłączone domyślnie · CAN 11-bit · bez dekodowania zgadywanego PID-u", color = Smoke, style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = experimentalEnabled, onCheckedChange = { experimentalEnabled = it })
            }
            OutlinedTextField(
                value = did,
                onValueChange = { did = it.uppercase().filter { c -> c in "0123456789ABCDEF" }.take(4) },
                label = { Text("DID (4 znaki HEX)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Ascii, capitalization = KeyboardCapitalization.Characters),
                singleLine = true,
                enabled = experimentalEnabled && !busy,
                modifier = Modifier.fillMaxWidth(),
            )
            Button(onClick = {
                scope.launch {
                    busy = true
                    status = "Wysyłam pojedyncze żądanie odczytu Mode 22…"
                    val result = runCatching { onReadMode22(did, experimentalEnabled) }.getOrNull()
                    status = when (result) {
                        is Mode22ReadResult.Data -> "DID ${result.did}: ${result.bytes.joinToString(" ") { "%02X".format(it) }} · surowe dane, bez potwierdzonej interpretacji"
                        is Mode22ReadResult.Refused -> "ECU odmówiło DID ${result.did}; kod NRC 0x%02X".format(result.code)
                        is Mode22ReadResult.Blocked -> result.reason
                        Mode22ReadResult.NoData -> "Brak poprawnej odpowiedzi. Nie uznaję tego za wartość 0."
                        null -> "Brak połączenia albo błąd odczytu."
                    }
                    busy = false
                }
            }, enabled = connected && experimentalEnabled && did.length == 4 && !busy, modifier = Modifier.fillMaxWidth()) { Text("Odczytaj DID") }

            InfoCard(title = "Funkcje serwisowe", body = "Reset adaptacji, reset ECU, test wentylatora i sterowanie EVAP są widoczne jako funkcje zablokowane. Nie wysyłam komend 30/31 ani niezweryfikowanych komend zapisu, ponieważ nie mamy potwierdzonej procedury dla konkretnego ECU.")
            LockedServiceRow("Reset adaptacji / Idle Learn", "Zablokowane · wymaga procedury serwisowej właściwej dla L13Z1")
            LockedServiceRow("Aktywny test wentylatora chłodnicy", "Zablokowane · brak potwierdzonej komendy i warunków testu")
            LockedServiceRow("Test zaworu EVAP", "Zablokowane · brak potwierdzonego identyfikatora sterowania")
            LockedServiceRow("Wysterowanie VTEC / VTC", "Zablokowane · nie wysyłać niezweryfikowanych poleceń")
            InfoCard(title = "Względna kompresja", body = "Analiza z samego rozrzutu RPM nie pozwala wiarygodnie wskazać cylindra ani potwierdzić kompresji. Funkcja nie zgłasza diagnozy na podstawie zwykłych odczytów OBD; do testu potrzebny jest szybki, zsynchronizowany sygnał CKP albo pomiar kompresji.")
            InfoCard(title = "Test liczników / ukryte menu", body = "Aplikacja nie wysyła poleceń do zestawu wskaźników. Sekwencja przycisku Trip, świateł i zapłonu może różnić się między wersjami licznika; przed użyciem sprawdź procedurę dla europejskiego Civica VIII. To instrukcja informacyjna, nie aktywny test ECU.")
            InfoCard(title = "Zasady ochrony", body = "Wspólna sesja ELM serializuje żądania; Mode 22 ma limit formatu i jest blokowany poza CAN. Odpowiedzi negatywne lub brak danych nie są interpretowane jako liczby. Kasowanie DTC pozostaje osobną, świadomą akcją, bo usuwa również ramkę zamrożoną i statusy monitorów.")
        }
    }
}

@Composable
private fun InfoCard(title: String, body: String) {
    Column(Modifier.fillMaxWidth().background(Slate, RoundedCornerShape(14.dp)).padding(14.dp)) {
        Text(title, color = Chalk, style = MaterialTheme.typography.titleSmall)
        Spacer(Modifier.height(5.dp))
        Text(body, color = Smoke, style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
private fun ValueRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().background(Slate, RoundedCornerShape(10.dp)).padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Smoke, modifier = Modifier.weight(1f))
        Text(value, color = Chalk)
    }
}

@Composable
private fun LockedServiceRow(title: String, subtitle: String) {
    Column(Modifier.fillMaxWidth().background(Color(0xFF252321), RoundedCornerShape(10.dp)).padding(12.dp)) {
        Text(title, color = Chalk, style = MaterialTheme.typography.bodyMedium)
        Text(subtitle, color = Color(0xFFD6B16E), style = MaterialTheme.typography.labelSmall)
    }
}
