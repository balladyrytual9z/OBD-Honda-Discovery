package com.miskibin.obd2dashboard

import android.content.ContentProvider
import android.content.ContentValues
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import android.os.Bundle

/**
 * Read-only bridge for an external launcher. It exposes only the last actual OBD-socket
 * voltage sample and its timestamp/source; it never exposes DTCs, VIN, or trip history.
 * Query content://com.miskibin.obd2dashboard.live/voltage or call method
 * LiveDataContract.METHOD_GET_LIVE_VOLTAGE.
 */
class LiveDataProvider : ContentProvider() {
    override fun onCreate(): Boolean = true

    override fun call(method: String, arg: String?, extras: Bundle?): Bundle {
        if (method != LiveDataContract.METHOD_GET_LIVE_VOLTAGE) return Bundle()
        val context = requireNotNull(context)
        val prefs = context.getSharedPreferences(PREFS, 0)
        return Bundle().apply {
            if (prefs.contains(KEY_VOLTAGE)) putDouble(LiveDataContract.EXTRA_VOLTAGE_V, prefs.getFloat(KEY_VOLTAGE, Float.NaN).toDouble())
            putLong(LiveDataContract.EXTRA_TIMESTAMP_MS, prefs.getLong(KEY_TIMESTAMP, 0L))
            putString(LiveDataContract.EXTRA_SOURCE, prefs.getString(KEY_SOURCE, LiveDataContract.SOURCE_ELM_ATRV))
            putBoolean(LiveDataContract.EXTRA_CONNECTED, prefs.getBoolean(KEY_CONNECTED, false))
            if (prefs.contains(KEY_RPM)) putDouble(LiveDataContract.EXTRA_RPM, prefs.getFloat(KEY_RPM, Float.NaN).toDouble())
            if (prefs.contains(KEY_SPEED)) putDouble(LiveDataContract.EXTRA_SPEED, prefs.getFloat(KEY_SPEED, Float.NaN).toDouble())
            if (prefs.contains(KEY_COOLANT)) putDouble(LiveDataContract.EXTRA_COOLANT, prefs.getFloat(KEY_COOLANT, Float.NaN).toDouble())
            if (prefs.contains(KEY_LOAD)) putDouble(LiveDataContract.EXTRA_LOAD, prefs.getFloat(KEY_LOAD, Float.NaN).toDouble())
            putLong(LiveDataContract.EXTRA_SAMPLE_TIMESTAMP_MS, prefs.getLong(KEY_SAMPLE_TIMESTAMP, 0L))
        }
    }

    override fun query(uri: Uri, projection: Array<out String>?, selection: String?, selectionArgs: Array<out String>?, sortOrder: String?): Cursor {
        val columns = arrayOf("voltage_v", "timestamp_ms", "source", "connected")
        val cursor = MatrixCursor(columns, 1)
        if (uri.lastPathSegment == "voltage") {
            val p = requireNotNull(context).getSharedPreferences(PREFS, 0)
            if (p.contains(KEY_VOLTAGE)) cursor.addRow(arrayOf(
                p.getFloat(KEY_VOLTAGE, Float.NaN).toDouble(),
                p.getLong(KEY_TIMESTAMP, 0L),
                p.getString(KEY_SOURCE, LiveDataContract.SOURCE_ELM_ATRV),
                p.getBoolean(KEY_CONNECTED, false),
            ))
        }
        return cursor
    }

    override fun getType(uri: Uri): String = "vnd.android.cursor.item/vnd.com.miskibin.obd2dashboard.voltage"
    override fun insert(uri: Uri, values: ContentValues?): Uri? = throw UnsupportedOperationException("Read-only provider")
    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException("Read-only provider")
    override fun update(uri: Uri, values: ContentValues?, selection: String?, selectionArgs: Array<out String>?): Int = throw UnsupportedOperationException("Read-only provider")

    companion object {
        const val PREFS = "live_telemetry"
        const val KEY_VOLTAGE = "voltage_v"
        const val KEY_TIMESTAMP = "timestamp_ms"
        const val KEY_SOURCE = "source"
        const val KEY_CONNECTED = "connected"
        const val KEY_RPM = "rpm"
        const val KEY_SPEED = "speed_kmh"
        const val KEY_COOLANT = "coolant_c"
        const val KEY_LOAD = "engine_load_pct"
        const val KEY_SAMPLE_TIMESTAMP = "sample_timestamp_ms"
    }
}
