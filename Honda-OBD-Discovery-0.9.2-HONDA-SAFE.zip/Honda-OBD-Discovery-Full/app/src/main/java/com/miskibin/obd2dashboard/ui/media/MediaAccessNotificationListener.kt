package com.miskibin.obd2dashboard.ui.media

import android.service.notification.NotificationListenerService

/** Permission anchor required by MediaSessionManager.getActiveSessions(). */
class MediaAccessNotificationListener : NotificationListenerService()
