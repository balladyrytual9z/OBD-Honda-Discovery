
package com.miskibin.obd2dashboard.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.miskibin.obd2dashboard.MainActivity
import com.miskibin.obd2dashboard.LiveDataContract
import com.miskibin.obd2dashboard.LiveDataProvider
import com.miskibin.obd2dashboard.ObdHolder
import com.miskibin.obd2dashboard.R
import com.miskibin.obd2dashboard.widget.MisfireMonitorWidgetProvider
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.data.LocalePreference
import com.miskibin.obd2dashboard.data.Metrics
import com.miskibin.obd2dashboard.data.valueOf
import com.miskibin.obd2dashboard.data.updatedAtOf
import com.miskibin.obd2dashboard.data.worstMisfire
import com.miskibin.obd2dashboard.obd.VehicleSnapshot
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.conflate
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/**
 * Keeps the BLE link and the polling loop alive while the app is not in front.
 *
 * The service does not own a connection of its own — it holds the process up around the
 * one in [ObdHolder], which is the same instance the UI reads from. Without it Android
 * would freeze the polling coroutines the moment the driver switched to navigation.
 */
class ObdConnectionService : Service() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private lateinit var localised: Context
    private var lastPublishedBatteryAt: Long = -1L
    private var observerStarted: Boolean = false

    override fun onCreate() {
        super.onCreate()
        localised = LocalePreference.wrap(this)
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            ObdHolder.connection.disconnect()
            stopSelf()
            return START_NOT_STICKY
        }
        startInForeground(notification(ObdHolder.connection.state.value, ObdHolder.connection.snapshot.value))
        observeState()
        if (intent?.action == ACTION_ACC_RECONNECT) scope.launch {
            if (ObdHolder.connection.state.value == ConnectionState.Idle) {
                runCatching { ObdHolder.autoConnect(this@ObdConnectionService) }
            }
        }
        // START_STICKY may recreate the service with a null Intent after the process was
        // reclaimed. Only that recovery path auto-connects here; normal starts are initiated
        // by the ViewModel, which already owns the requested connection attempt.
        if (intent == null) scope.launch {
            if (ObdHolder.connection.state.value == ConnectionState.Idle) {
                runCatching { ObdHolder.autoConnect(this@ObdConnectionService) }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    /**
     * Rebuilds the notification at most once a second: the scheduler publishes several
     * snapshots per second and the shade cannot usefully show that.
     */
    private fun observeState() {
        if (observerStarted) return
        observerStarted = true
        combine(
            ObdHolder.connection.state,
            ObdHolder.connection.snapshot,
        ) { state, snapshot -> state to snapshot }
            .conflate()
            .onEach { (state, snapshot) ->
                notificationManager().notify(NOTIFICATION_ID, notification(state, snapshot))
                publishLiveVoltage(state, snapshot)
                delay(NOTIFICATION_REFRESH_MILLIS)
            }
            .launchIn(scope)
    }

    private fun startInForeground(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_CONNECTED_DEVICE,
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun notification(state: ConnectionState, snapshot: VehicleSnapshot): Notification {
        val open = PendingIntent.getActivity(
            this,
            0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        val stop = PendingIntent.getService(
            this,
            1,
            Intent(this, ObdConnectionService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT,
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(titleFor(state))
            .setContentText(liveValues(snapshot))
            .setContentIntent(open)
            .addAction(0, localised.getString(R.string.action_disconnect), stop)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()
    }

    private fun titleFor(state: ConnectionState): String = when (state) {
        is ConnectionState.Connected -> if (state.demo) {
            localised.getString(R.string.status_demo)
        } else {
            localised.getString(R.string.status_connected_to, state.device.name ?: state.device.address)
        }

        is ConnectionState.Connecting -> localised.getString(R.string.status_connecting)
        is ConnectionState.Initializing -> localised.getString(R.string.status_initializing, state.step)
        is ConnectionState.Reconnecting ->
            localised.getString(R.string.status_reconnecting, state.attempt)

        ConnectionState.Scanning -> localised.getString(R.string.status_scanning)
        is ConnectionState.Error -> localised.getString(R.string.status_error)
        ConnectionState.Idle -> localised.getString(R.string.status_disconnected)
    }

    /**
     * Exposes real adapter ATRV samples to a companion launcher. This is the voltage
     * reported by the ELM adapter at the OBD socket, not a separately measured ECU PID.
     * A sample is broadcast only when its own timestamp advances; stale values are retained
     * for display but carry the old timestamp so the launcher can mark them stale.
     */
    private fun publishLiveVoltage(state: ConnectionState, snapshot: VehicleSnapshot) {
        val realConnected = state is ConnectionState.Connected && !state.demo
        val prefs = getSharedPreferences(LiveDataProvider.PREFS, MODE_PRIVATE)
        val rpm = snapshot.valueOf(Metrics.Rpm)
        val speed = snapshot.valueOf(Metrics.Speed)
        val coolant = snapshot.valueOf(Metrics.CoolantTemp)
        val load = snapshot.valueOf(Metrics.EngineLoad)
        val monitorTests = ObdHolder.connection.monitors.value
        val misfire = monitorTests.worstMisfire()
        if (realConnected && misfire != null) {
            prefs.edit()
                .putFloat("misfire_count", misfire.count.toFloat())
                .putBoolean("misfire_passed", misfire.passed)
                .putLong("misfire_at", monitorTests?.capturedAtMillis ?: 0L)
                .apply()
        }
        if (realConnected && snapshot.batteryVoltage != null && snapshot.batteryAtMillis > lastPublishedBatteryAt) {
            lastPublishedBatteryAt = snapshot.batteryAtMillis
            prefs.edit()
                .putFloat(LiveDataProvider.KEY_VOLTAGE, snapshot.batteryVoltage.toFloat())
                .putLong(LiveDataProvider.KEY_TIMESTAMP, snapshot.batteryAtMillis)
                .putString(LiveDataProvider.KEY_SOURCE, LiveDataContract.SOURCE_ELM_ATRV)
                .putBoolean(LiveDataProvider.KEY_CONNECTED, true)
                .apply()
        } else if (!realConnected) {
            prefs.edit().putBoolean(LiveDataProvider.KEY_CONNECTED, false).apply()
        }
        // Cache the latest actual telemetry so a widget can refresh after process wake.
        if (realConnected) {
            val editor = prefs.edit()
            rpm?.let { editor.putFloat(LiveDataProvider.KEY_RPM, it.toFloat()) }
            speed?.let { editor.putFloat(LiveDataProvider.KEY_SPEED, it.toFloat()) }
            coolant?.let { editor.putFloat(LiveDataProvider.KEY_COOLANT, it.toFloat()) }
            load?.let { editor.putFloat(LiveDataProvider.KEY_LOAD, it.toFloat()) }
            editor.putLong(LiveDataProvider.KEY_SAMPLE_TIMESTAMP, snapshot.updatedAtMillis)
            val rpmAt = snapshot.updatedAtOf(Metrics.Rpm)
            if (rpm != null && rpmAt > prefs.getLong(MisfireMonitorWidgetProvider.KEY_RPM_TIMESTAMP, 0L)) {
                val previous = prefs.getString(MisfireMonitorWidgetProvider.KEY_RPM_HISTORY, "").orEmpty()
                val points = (previous.split(',').filter { it.isNotBlank() } + String.format(java.util.Locale.US, "%.1f", rpm)).takeLast(30)
                editor.putString(MisfireMonitorWidgetProvider.KEY_RPM_HISTORY, points.joinToString(","))
                editor.putLong(MisfireMonitorWidgetProvider.KEY_RPM_TIMESTAMP, rpmAt)
            }
            editor.apply()
        }
        // Dynamic receivers in launchers can subscribe to this action. Only live metrics
        // are included; no VIN, DTC list, or trip history is broadcast.
        sendBroadcast(Intent(LiveDataContract.ACTION_LIVE_VOLTAGE).apply {
            putExtra(LiveDataContract.EXTRA_VOLTAGE_V, snapshot.batteryVoltage ?: Double.NaN)
            putExtra(LiveDataContract.EXTRA_TIMESTAMP_MS, snapshot.batteryAtMillis)
            putExtra(LiveDataContract.EXTRA_SOURCE, LiveDataContract.SOURCE_ELM_ATRV)
            putExtra(LiveDataContract.EXTRA_CONNECTED, realConnected)
            putExtra(LiveDataContract.EXTRA_RPM, rpm ?: Double.NaN)
            putExtra(LiveDataContract.EXTRA_SPEED, speed ?: Double.NaN)
            putExtra(LiveDataContract.EXTRA_COOLANT, coolant ?: Double.NaN)
            putExtra(LiveDataContract.EXTRA_LOAD, load ?: Double.NaN)
            putExtra(LiveDataContract.EXTRA_SAMPLE_TIMESTAMP_MS, snapshot.updatedAtMillis)
        })
        runCatching { MisfireMonitorWidgetProvider.updateAll(this) }
    }

    /** RPM and coolant: the two numbers worth glancing at from the shade. */
    private fun liveValues(snapshot: VehicleSnapshot): String {
        val parts = listOfNotNull(
            snapshot.valueOf(Metrics.Rpm)?.let {
                localised.getString(R.string.notification_rpm, it.toInt())
            },
            snapshot.valueOf(Metrics.CoolantTemp)?.let {
                localised.getString(R.string.notification_coolant, it.toInt())
            },
        )
        return if (parts.isEmpty()) {
            localised.getString(R.string.notification_waiting_for_data)
        } else {
            parts.joinToString(SEPARATOR)
        }
    }

    private fun createChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            localised.getString(R.string.notification_channel_name),
            NotificationManager.IMPORTANCE_LOW,
        ).apply {
            description = localised.getString(R.string.notification_channel_description)
            setShowBadge(false)
        }
        notificationManager().createNotificationChannel(channel)
    }

    private fun notificationManager(): NotificationManager =
        getSystemService(NotificationManager::class.java)

    companion object {
        private const val CHANNEL_ID = "obd_connection"
        private const val NOTIFICATION_ID = 1
        private const val ACTION_STOP = "com.miskibin.obd2dashboard.STOP"
        const val ACTION_ACC_RECONNECT = "com.miskibin.obd2dashboard.ACC_RECONNECT"
        private const val NOTIFICATION_REFRESH_MILLIS = 1_000L
        private const val SEPARATOR = "  ·  "

        fun start(context: Context) {
            val intent = Intent(context, ObdConnectionService::class.java)
            runCatching { context.startForegroundService(intent) }
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, ObdConnectionService::class.java))
        }
    }
}

