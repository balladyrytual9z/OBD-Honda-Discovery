package com.miskibin.obd2dashboard

import android.app.Activity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import com.miskibin.obd2dashboard.ble.ConnectionState
import com.miskibin.obd2dashboard.service.ObdConnectionService
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** One-tap launcher entry. It reuses the process-wide connection and never asks to confirm. */
class DtcQuickClearActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        lifecycleScope.launch {
            try {
                var state = ObdHolder.connection.state.value
                if (state !is ConnectionState.Connected || state.demo) {
                    val started = ObdHolder.autoConnect(this@DtcQuickClearActivity)
                    if (!started) {
                        resultToast("Brak zapisanego adaptera OBD. Otwórz najpierw Honda OBD Discovery.")
                        return@launch
                    }
                    ObdConnectionService.start(this@DtcQuickClearActivity)
                    state = withTimeoutOrNull(20_000L) {
                        ObdHolder.connection.state.first { it is ConnectionState.Connected || it is ConnectionState.Error }
                    } ?: run {
                        resultToast("Timeout połączenia z adapterem BLE.")
                        return@launch
                    }
                }
                if (state !is ConnectionState.Connected || state.demo) {
                    resultToast("Brak aktywnej sesji z prawdziwym ECU.")
                    return@launch
                }
                val accepted = ObdHolder.connection.clearDtcs()
                resultToast(if (accepted) "ECU zaakceptowało kasowanie DTC." else "ECU nie potwierdziło kasowania DTC.")
            } catch (t: Throwable) {
                resultToast("Kasowanie DTC nieudane: ${t.message ?: "błąd komunikacji"}")
            } finally {
                finish()
            }
        }
    }

    private fun resultToast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_LONG).show() }
    }
}
