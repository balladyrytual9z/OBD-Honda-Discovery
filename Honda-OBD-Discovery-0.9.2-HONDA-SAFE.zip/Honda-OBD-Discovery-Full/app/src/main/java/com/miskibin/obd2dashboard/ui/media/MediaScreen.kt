package com.miskibin.obd2dashboard.ui.media

import android.content.ComponentName
import android.content.Intent
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

@Composable
fun MediaScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var controller by remember { mutableStateOf<MediaController?>(null) }
    var title by remember { mutableStateOf("Brak aktywnego odtwarzacza") }
    var artist by remember { mutableStateOf("Włącz muzykę w Spotify, YouTube Music lub innej aplikacji") }
    var playing by remember { mutableStateOf(false) }
    var accessError by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        val manager = context.getSystemService(MediaSessionManager::class.java)
        val listener = ComponentName(context, MediaAccessNotificationListener::class.java)
        while (true) {
            try {
                val active = manager.getActiveSessions(listener)
                val current = active.firstOrNull { it.playbackState != null } ?: active.firstOrNull()
                controller = current
                val metadata = current?.metadata
                title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
                    ?: "Brak tytułu utworu"
                artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)?.takeIf { it.isNotBlank() }
                    ?: metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM)?.takeIf { it.isNotBlank() }
                    ?: "Nieznany wykonawca"
                playing = current?.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                accessError = false
            } catch (_: SecurityException) {
                controller = null
                accessError = true
                title = "Brak dostępu do sesji multimediów"
                artist = "Włącz dostęp powiadomień dla Honda OBD Discovery"
            } catch (_: Throwable) {
                controller = null
                title = "Nie znaleziono sesji multimediów"
                artist = "Uruchom odtwarzacz i spróbuj ponownie"
            }
            delay(1_000L)
        }
    }

    Column(modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column {
            Text("MEDIA", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Sterowanie aktywną sesją systemową", style = MaterialTheme.typography.bodySmall)
        }
        Card(Modifier.fillMaxWidth().weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface), shape = RoundedCornerShape(24.dp)) {
            Column(Modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(if (playing) "▶" else "♫", style = MaterialTheme.typography.displayLarge, color = MaterialTheme.colorScheme.primary)
                Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text(artist, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.size(28.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(enabled = controller != null, onClick = { controller?.transportControls?.skipToPrevious() }) { Text("⏮") }
                    Button(enabled = controller != null, onClick = {
                        val c = controller ?: return@Button
                        if (playing) c.transportControls.pause() else c.transportControls.play()
                    }) { Text(if (playing) "❚❚" else "▶") }
                    Button(enabled = controller != null, onClick = { controller?.transportControls?.skipToNext() }) { Text("⏭") }
                }
                if (accessError) {
                    Spacer(Modifier.size(12.dp))
                    Button(onClick = { runCatching { context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)) } }) {
                        Text("Włącz dostęp multimediów")
                    }
                }
            }
        }
        Text("Aplikacja nie przechwytuje dźwięku. Wysyła wyłącznie standardowe polecenia play/pause/next/previous do aktywnej sesji.", style = MaterialTheme.typography.bodySmall)
    }
}
