package com.miskibin.obd2dashboard.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile
import com.miskibin.obd2dashboard.log.ObdLog
import java.io.File
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** SAF-based export to a user-selected USB folder; avoids hard-coded vendor mount paths. */
object UsbBackupManager {
    private const val PREFS = "usb_backup"
    private const val KEY_TREE_URI = "tree_uri"

    fun saveTree(context: Context, uri: Uri) {
        context.applicationContext.contentResolver.takePersistableUriPermission(
            uri,
            android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION,
        )
        context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .edit().putString(KEY_TREE_URI, uri.toString()).apply()
    }

    fun configuredTree(context: Context): Uri? = context.applicationContext
        .getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY_TREE_URI, null)?.let { Uri.parse(it) }

    suspend fun backupConfigured(context: Context): Result<Int> = withContext(Dispatchers.IO) {
        val uri = configuredTree(context) ?: return@withContext Result.failure(IllegalStateException("Nie wybrano folderu USB"))
        runCatching { backup(context.applicationContext, uri) }
    }

    private fun backup(context: Context, treeUri: Uri): Int {
        val root = DocumentFile.fromTreeUri(context, treeUri)
            ?: throw IllegalStateException("Wybrany folder USB jest niedostępny")
        if (!root.canWrite()) throw IllegalStateException("Folder USB nie pozwala na zapis")
        val folder = root.findFile("HondaOBD_Backups") ?: root.createDirectory("HondaOBD_Backups")
            ?: throw IllegalStateException("Nie można utworzyć HondaOBD_Backups")
        val stamp = System.currentTimeMillis()
        val sessionFolder = folder.createDirectory("backup-$stamp")
            ?: throw IllegalStateException("Nie można utworzyć katalogu kopii")
        var copied = 0
        val sources = listOf(File(context.filesDir, "trips"), File(context.filesDir, "blackbox"))
        sources.forEach { source ->
            source.walkTopDown().filter { it.isFile && (it.extension.lowercase() in setOf("csv", "json", "txt")) }.forEach { file ->
                val relative = file.relativeTo(context.filesDir).path.replace(File.separatorChar, '_')
                val target = sessionFolder.createFile(mimeFor(file), relative)
                    ?: throw IllegalStateException("Nie można utworzyć pliku $relative na USB")
                val output = requireNotNull(context.contentResolver.openOutputStream(target.uri, "w")) {
                    "Nie można otworzyć pliku docelowego"
                }
                output.use { out -> file.inputStream().use { input -> input.copyTo(out) } }
                copied++
            }
        }
        val log = sessionFolder.createFile("text/plain", "connection-log.txt")
        if (log != null) {
            context.contentResolver.openOutputStream(log.uri, "w")?.bufferedWriter(Charsets.UTF_8)?.use { it.write(ObdLog.dump()) }
            copied++
        }
        if (copied == 0) throw IllegalStateException("Brak plików do skopiowania")
        return copied
    }

    private fun mimeFor(file: File): String = when (file.extension.lowercase()) {
        "csv" -> "text/csv"
        "json" -> "application/json"
        else -> "text/plain"
    }
}
