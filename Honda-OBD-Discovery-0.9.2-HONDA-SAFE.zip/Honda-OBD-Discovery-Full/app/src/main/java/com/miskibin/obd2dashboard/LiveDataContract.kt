package com.miskibin.obd2dashboard

/** Public, read-only contract for launchers and other companion apps. */
object LiveDataContract {
    const val ACTION_LIVE_VOLTAGE = "com.miskibin.obd2dashboard.LIVE_VOLTAGE"
    const val AUTHORITY = "com.miskibin.obd2dashboard.live"
    const val URI_VOLTAGE = "content://com.miskibin.obd2dashboard.live/voltage"
    const val METHOD_GET_LIVE_VOLTAGE = "get_live_voltage"
    const val EXTRA_VOLTAGE_V = "voltage_v"
    const val EXTRA_TIMESTAMP_MS = "timestamp_ms"
    const val EXTRA_SOURCE = "source"
    const val EXTRA_CONNECTED = "connected"
    const val EXTRA_RPM = "rpm"
    const val EXTRA_SPEED = "speed_kmh"
    const val EXTRA_COOLANT = "coolant_c"
    const val EXTRA_LOAD = "engine_load_pct"
    const val EXTRA_SAMPLE_TIMESTAMP_MS = "sample_timestamp_ms"
    const val SOURCE_ELM_ATRV = "ELM327 ATRV / napięcie na gnieździe OBD"
}
