# Honda OBD Discovery 0.9.2

Android OBD-II dashboard based on the supplied `obd2-dashboard` source snapshot, extended for the ESSGOO Android 9 / API 28 head unit and the Honda Civic VIII L13Z1.

## Implemented in this package

- BLE GATT ELM transport with common profiles and fallback characteristic detection; serialized GATT operations, ELM response framing, reconnect/state handling and one shared connection manager.
- SAE J1979 / OBD-II engine data scheduler, supported PID discovery, provenance/quality status, DTC modes, freeze-frame, readiness, Mode 06 tests, VIN/vehicle information where supported, raw connection logs and CSV/trip history.
- Compose dashboard and readable charts with selectable parameter series, trip summaries, diagnostics and connection settings.
- Fixed left CarPlay-style navigation dock for landscape head units; **KASUJ DTC** is anchored at the bottom of the dock. It has a clipped press/ripple animation and local status only. It only shows **WYSŁANO** when the ECU accepts Mode 04; it does not claim that a recurring fault is repaired or that permanent DTCs must disappear.
- In-app **AI Copilot** screen using OpenRouter HTTPS chat completions, editable model ID and master prompt, selected live/history metrics and DTC context, speech input via the installed Android recognizer and Polish system TTS playback. The API key is held in screen memory and is not persisted; the key is sent to OpenRouter over HTTPS when you explicitly submit a question.
- Local fuel log with liters, cost, odometer, full/partial tank marking and tank-to-tank real consumption calculation. This does not automatically calibrate the ECU/MAF-derived estimate.
- Media screen that controls the active Android media session (previous/play-pause/next) after the user grants notification-listener access.
- Optional USB backup using Android Storage Access Framework: select the USB folder once in Settings; on an ACC_OFF event the app attempts to copy trip CSVs, black-box JSON events and the connection log. It does not copy a Room database because this project currently does not use Room.
- A second launcher entry **Kasuj DTC** performs the same no-confirmation operation using the process-wide connection, or attempts to auto-connect to the remembered adapter; it never opens a second independent BLE client.
- Persistent foreground connection service during an active OBD session; the service keeps the process around the single shared connection and its reconnect manager. Android/OEM power management can still terminate services, so absolute 24/7 connectivity cannot be guaranteed.
- Live telemetry bridge for external launchers: broadcast action `com.miskibin.obd2dashboard.LIVE_VOLTAGE`, plus read-only provider `content://com.miskibin.obd2dashboard.live/voltage` and provider method `get_live_voltage`.
- Resizable Android home-screen widget with rounded 25dp corners, live voltage/RPM/coolant, last available Mode 06 misfire result and a sparkline drawn only when a new real RPM sample arrives. It marks the voltage stale after 5 seconds.
- A 300-sample, 1 Hz black-box ring buffer that saves an atomic, locked JSON event file on a rapid speed drop or RPM drop coincident with low voltage. This is an anomaly log, not a verified crash detector.
- Optional head-unit ACC broadcasts (`com.car.action.ACC_ON` / `com.car.action.ACC_OFF`) and Android shutdown handling. These vendor-specific broadcasts work only if the ESSGOO MCU actually emits those exact actions.
- GitHub Actions workflow using Gradle 8.14.3 and JDK 17, running unit tests and producing a debug APK artifact.

## Launcher voltage integration

A launcher can register a dynamic receiver for `com.miskibin.obd2dashboard.LIVE_VOLTAGE`. Extras:

- `voltage_v` (`double`): latest voltage reported by `ATRV`.
- `timestamp_ms` (`long`): timestamp of that voltage sample.
- `source` (`String`): `ELM327 ATRV / napięcie na gnieździe OBD`.
- `connected` (`boolean`): whether the real OBD session is currently connected.
- `rpm` (`double`), `speed_kmh` (`double`), `coolant_c` (`double`), `engine_load_pct` (`double`), `sample_timestamp_ms` (`long`). Missing metrics are `NaN`, not fabricated zeros.

To read the last cached values without waiting for a broadcast, call:

```kotlin
val uri = android.net.Uri.parse("content://com.miskibin.obd2dashboard.live")
val result = contentResolver.call(uri, "get_live_voltage", null, null)
val voltage = result?.getDouble("voltage_v", Double.NaN)
val timestamp = result?.getLong("timestamp_ms", 0L) ?: 0L
val source = result?.getString("source")
val connected = result?.getBoolean("connected", false) ?: false
```

`ATRV` is the adapter's voltage estimate at the vehicle OBD socket. It is not a separate ECU voltage PID and must be labelled accordingly. A launcher should mark the value stale when the timestamp is old, rather than continue presenting it as live.

## Build

Recommended: push the project to GitHub and run **Actions → Honda OBD Discovery · build and tests → Run workflow**. The workflow installs Gradle 8.14.3 directly, so it does not depend on a local wrapper JAR. For a local CLI build, install Gradle 8.14.3 and JDK 17, then run `gradle :app:assembleDebug`. The text snapshot did not contain the Gradle wrapper JAR, so `./gradlew` is not the supported build path in this package. The artifact is named `Honda-OBD-Discovery-0.9.2-debug`.

## Features not yet completed

The following items from the broader requirements are **not fully implemented in this build** and should not be assumed to work: manual fuel-log UI and tank-to-tank calibration; active media-session controls; SAF-based USB backup; and validated Honda-specific interpretation of Mode 06 MID A2–A5. Critical coolant/low-voltage alerts currently use Android notifications; spoken alerting with Audio Focus is not yet connected. Mode 06 itself is implemented and is read once per BLE session through the scheduler-safe `scanSupportedMonitors()` + `readMonitor(mid)` path. `Obd2Client.readMonitorTests()` also exists; the connection manager intentionally uses the split calls so each request releases the scheduler lock and live gauges do not freeze for a whole multi-monitor sweep.

## Important verification status

The ZIP is an updated source package based on the available project snapshot, not a device-tested release. This environment does not have Gradle or Android SDK tools available, so I have **not** confirmed that the APK compiles, that the UI fits the ESSGOO panel, or that the BLE adapter/ECU works end-to-end. The GitHub Actions build is the next required verification step. Honda-specific PID definitions and Mode 06 cylinder mappings must remain marked unverified until confirmed against actual responses from this ECU.


## Honda enhanced diagnostics and safety (0.9.2)

- Added an advanced diagnostics screen under Settings: standard BARO and wideband lambda reads use only PIDs declared supported by the ECU.
- Added opt-in Mode 22 raw DID reads on 11-bit CAN, with strict four-hex-digit validation, response-marker matching, NRC handling, no guessed decoding, and a default-off switch.
- Mode 22 is blocked unless fresh adapter voltage and RPM indicate stable running for at least three snapshots (RPM >= 600 and voltage >= 13.2 V). This is a conservative guard, not a guarantee of vehicle safety.
- ECU reset/adaptation reset, fan/EVAP actuator tests and unverified VTEC/VTC controls are shown as locked. No unverified Mode 30/31 or ECU-write routine is transmitted.
- Added a raw-command safety policy and experimental relative-RPM spread recorder. The RPM spread is explicitly not a cylinder-specific compression diagnosis.
- Existing Mode 02 freeze-frame reader, readiness parsing and serial request scheduler remain the authoritative implementations; this screen does not synthesize freeze-frame values.

Build status: source-level changes are packaged; a full Android/Compose build and on-device test still need to be confirmed by GitHub Actions and the actual ESSGOO unit.
