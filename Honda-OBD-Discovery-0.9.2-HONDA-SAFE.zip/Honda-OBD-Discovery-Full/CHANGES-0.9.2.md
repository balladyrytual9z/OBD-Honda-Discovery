# 0.9.2 — Honda safe enhanced diagnostics

- Added an advanced diagnostics screen reachable from Settings.
- Added real one-shot reads of standard BARO (01 33) and supported wideband lambda PIDs (01 24 / 01 34), with no fabricated values.
- Added opt-in raw Mode 22 DID read, default off, strict DID validation, only 11-bit CAN profiles, physical request/response headers restored after each exchange, negative response handling and raw-only output.
- Mode 22 additionally requires fresh adapter voltage, RPM >= 600 and three consecutive stable-running snapshots (voltage >= 13.2 V). It is a conservative safeguard, not a promise of zero risk.
- Added a safety policy denying write/programming/routine-control services and a relative RPM spread recorder whose output is explicitly not a cylinder-specific compression diagnosis.
- Reset/Idle Learn, fan control, EVAP duty-cycle, VTEC/VTC actuation are shown discreetly as locked because a verified L13Z1-specific routine is not available. No unverified Mode 30/31 command is transmitted.
- Added unit tests for command blocking, malformed requests, cranking guard and experimental RPM spread.

## Verification status

The new pure Kotlin safety/analyzer classes compile in isolation and XML/TOML/archive checks are run before packaging. Full Android/Compose compilation and physical BLE/ECU behavior remain unverified in this environment because the Android Gradle build toolchain is unavailable; use the included GitHub Actions workflow, then validate on the actual ESSGOO unit. Do not treat a successful Mode 22 read as proof that a DID's meaning is known.
