# 0.9.1 — BLE CarPlay Dock + Copilot + telemetry safeguards

- Replaced the bottom navigation bar with a fixed left-side dock sized for landscape infotainment displays. The no-confirmation `KASUJ DTC` control stays at the bottom of the dock and keeps its press/ripple/status feedback local to the control.
- Added an in-app OpenRouter AI Copilot screen with editable model ID and master prompt, selectable RPM/speed/coolant/adapter-voltage/DTC context, 1/5/10 minute in-memory history window, Android speech recognition input and Polish TTS output. The API key is intentionally not persisted.
- Added a 300-sample 1 Hz black-box ring buffer; suspected sudden speed/RPM-voltage anomalies atomically save a locked JSON event snapshot to app-private storage.
- Added optional vendor-specific ACC ON/OFF broadcast support and shutdown disconnect handling. The exact actions are not standard Android and only work if the head-unit MCU emits them.
- The home-screen widget now marks voltage stale after 5 seconds.
- `Obd2Client.readMonitorTests()` explicitly discovers supported Mode 06 MIDs, reads each monitor and timestamps the completed sweep. The connection manager intentionally uses the same split discovery/read operations under the scheduler lock, one request per turn, to avoid freezing live gauges for the full Mode 06 sweep.

## Not claimed as complete

Manual fuel-log UI and tank-to-tank calibration, active media-session controls, SAF USB backup, and validated Honda-specific MID A2–A5 cylinder interpretation still need implementation/vehicle validation. Mode 06 raw test results are shown as ECU-reported records; no unsupported cylinder mapping is inferred. Full APK compilation and on-radio BLE testing must be run through GitHub Actions and then on the actual ESSGOO adapter.
