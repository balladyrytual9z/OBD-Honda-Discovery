# Honda Mode 22: validation policy for L13Z1

The application must not present a manufacturer-specific value as a live engine measurement
until the request, response address, payload length, scaling, signedness and operating range
have been verified on the target ECU.

The following identifiers appeared in an earlier design proposal, but are **not validated
for the 2010 Civic VIII L13Z1 / Keihin ECU** and therefore must not be registered as working
PIDs or used to drive gauges or alarms without vehicle-side evidence:

- `22 1101` — VTEC solenoid / pressure-switch bitfield
- `22 1104` — VTEC state bitfield
- `22 1410` — injector pulse width
- `22 1143` — ELD voltage
- `22 1746` — knock retard
- `22 115A` — evaporator temperature

The example bit positions, byte lengths, units and conversion formulas associated with those
identifiers are also unverified. A plausible-looking response is not proof that its meaning
or scaling is correct.

## Required validation procedure

1. Record the exact vehicle VIN, ECU identification, adapter chipset/firmware and active OBD
   protocol.
2. Capture the unmodified request and complete response, including CAN headers and ISO-TP
   framing. Do not infer the payload from a response with headers removed.
3. Repeat the request at idle and under controlled, safe changes to one input at a time.
4. Check positive and negative responses, timeout behavior, payload length, signed values,
   scaling, units and plausible physical limits.
5. Compare the candidate value with an independent diagnostic reference or a known physical
   measurement where possible.
6. Store provenance and confidence with the decoder. Keep unknown values visible as
   *unverified* rather than silently converting them into a metric.

## Protocol cautions

- `AT SH 7E0` selects a transmit header on adapters that implement ELM-style commands; it does
  not prove that a particular DID exists or that the ECU accepts the request.
- `AT CRA 7E8` is an adapter receive filter, not an ECU command. It is adapter-dependent and
  must be restored when the session changes modules.
- Do not assume that concatenating several Mode 22 DIDs into one request is supported. Treat
  multi-DID reads as unsupported unless the adapter and ECU behavior are demonstrated.
- A passive CAN capture requires a genuinely listen-only-capable interface. An ordinary ELM327
  `AT MA`/monitor mode is not automatically equivalent to electrically silent listen-only.
- Do not infer a 12-valve/16-valve transition, a fixed VTEC RPM threshold, alternator current,
  knock retard or oil pressure from generic OBD values. Show these only when the relevant
  signal has a validated source and decoder.

The existing standard OBD-II implementation remains authoritative for the parameters it
already decodes. This validation policy deliberately avoids replacing working communication
logic with speculative Honda mappings.
