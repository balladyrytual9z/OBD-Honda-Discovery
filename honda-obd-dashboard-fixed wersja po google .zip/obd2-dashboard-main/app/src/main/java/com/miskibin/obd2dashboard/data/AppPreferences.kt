package com.miskibin.obd2dashboard.data

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.miskibin.obd2dashboard.obd.ExtendedProbe
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/**
 * The adapter the driver connected to last, so the next start needs no interaction.
 *
 * [classic] records which radio it answered on. It is not a detail worth losing: a
 * dual-radio dongle exposes a classic and an LE identity at two different addresses, and
 * reconnecting to the remembered address over the wrong one hangs exactly the way the first
 * connection did.
 */
data class SavedAdapter(
    val address: String,
    val name: String?,
    val classic: Boolean = false,
)

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "obd2_dashboard")

/**
 * Everything the app remembers between launches.
 *
 * Tile and chart selections are stored as `|`-joined [MetricId.storageKey]s rather than
 * JSON — the shape is a flat list, so a serialisation dependency would buy nothing.
 */
class AppPreferences(context: Context) {

    private val store = context.applicationContext.dataStore

    val savedAdapter: Flow<SavedAdapter?> = store.data.map { prefs ->
        val address = prefs[KEY_ADAPTER_ADDRESS] ?: return@map null
        SavedAdapter(address, prefs[KEY_ADAPTER_NAME], prefs[KEY_ADAPTER_CLASSIC] ?: false)
    }

    val tiles: Flow<List<MetricId>> = store.data.map { prefs ->
        prefs[KEY_TILES]?.let(::decodeMetrics)?.takeIf { it.isNotEmpty() } ?: Metrics.defaultTiles
    }

    /** Empty means "the driver has not chosen yet"; the chart screen then picks for them. */
    val chartMetrics: Flow<List<MetricId>> = store.data.map { prefs ->
        prefs[KEY_CHART_METRICS]?.let(::decodeMetrics).orEmpty()
    }

    /**
     * Which parts of the car diagram the driver keeps on it.
     *
     * Empty until the driver ticks a zone on, so a fresh install shows no car drawing at
     * all: the diagram is opt-in, reached through the dashboard menu, rather than a card
     * that arrives unasked and has to be ticked off zone by zone.
     */
    val carZones: Flow<Set<CarZone>> = store.data.map { prefs ->
        prefs[KEY_CAR_ZONES]?.let(CarZone::decode).orEmpty()
    }

    val pollingEnabled: Flow<Boolean> = store.data.map { it[KEY_POLLING_ENABLED] ?: true }

    /** Where the engine-speed bar turns red, in rpm. */
    val redline: Flow<Int> = store.data.map { prefs ->
        (prefs[KEY_REDLINE] ?: Metrics.REDLINE_DEFAULT)
            .coerceIn(Metrics.REDLINE_MIN, Metrics.REDLINE_MAX)
    }

    /** Always the full set of shipped rules; only the driver's edits are stored. */
    val alertRules: Flow<List<AlertRule>> = store.data.map { AlertRules.decode(it[KEY_ALERTS]) }

    /**
     * When each fault code was first and last seen, kept because OBD2 will not say.
     *
     * One log per [SessionKind]: the simulation's codes are a fixture and must never turn
     * up in the history of the car in the driveway.
     */
    fun dtcLog(kind: SessionKind): Flow<List<DtcObservation>> =
        store.data.map { DtcLog.decode(it[dtcKey(kind)]) }

    /** Whether the driver reads speed in miles; everything is polled in km/h regardless. */
    val imperialUnits: Flow<Boolean> = store.data.map { it[KEY_IMPERIAL] ?: false }

    /** Which ground the app draws on; [AppTheme.System] follows the phone. */
    val theme: Flow<AppTheme> = store.data.map { AppTheme.fromKey(it[KEY_THEME]) }

    /**
     * Every car the app has been plugged into, keyed by VIN rather than by adapter.
     *
     * One garage per [SessionKind], for the same reason the code log is split: the
     * simulation reports a VIN, and the car it names does not exist.
     */
    fun vehicles(kind: SessionKind): Flow<List<Vehicle>> =
        store.data.map { Garage.decode(it[vehicleKey(kind)]) }

    /**
     * What the ECU's own self-tests said, every time this app has looked, per car.
     *
     * Mode 06 numbers are only worth anything as a series: one catalyst storage reading is
     * a number and five of them across a year say whether the converter is on its way out.
     */
    fun monitorLog(kind: SessionKind): Flow<List<MonitorSnapshot>> =
        store.data.map { MonitorLog.decode(it[monitorKey(kind)]) }

    /** Which manufacturer-specific parameters each car has already answered for. */
    fun extendedSupport(kind: SessionKind): Flow<Map<String, ExtendedProbe>> =
        store.data.map { ExtendedSupport.decode(it[extendedKey(kind)]) }

    suspend fun saveAdapter(address: String, name: String?, classic: Boolean = false) {
        store.edit { prefs ->
            prefs[KEY_ADAPTER_ADDRESS] = address
            prefs[KEY_ADAPTER_CLASSIC] = classic
            if (name.isNullOrBlank()) prefs.remove(KEY_ADAPTER_NAME) else prefs[KEY_ADAPTER_NAME] = name
        }
    }

    suspend fun forgetAdapter() {
        store.edit { prefs ->
            prefs.remove(KEY_ADAPTER_ADDRESS)
            prefs.remove(KEY_ADAPTER_NAME)
            prefs.remove(KEY_ADAPTER_CLASSIC)
        }
    }

    suspend fun setTiles(tiles: List<MetricId>) {
        store.edit { it[KEY_TILES] = encodeMetrics(tiles) }
    }

    suspend fun setChartMetrics(metrics: List<MetricId>) {
        store.edit { it[KEY_CHART_METRICS] = encodeMetrics(metrics) }
    }

    suspend fun setCarZones(zones: Set<CarZone>) {
        store.edit { it[KEY_CAR_ZONES] = CarZone.encode(zones) }
    }

    suspend fun setPollingEnabled(enabled: Boolean) {
        store.edit { it[KEY_POLLING_ENABLED] = enabled }
    }

    suspend fun setRedline(rpm: Int) {
        store.edit { it[KEY_REDLINE] = rpm.coerceIn(Metrics.REDLINE_MIN, Metrics.REDLINE_MAX) }
    }

    suspend fun setAlertRule(rule: AlertRule) {
        store.edit { prefs ->
            val updated = AlertRules.decode(prefs[KEY_ALERTS])
                .map { if (it.id == rule.id) rule else it }
            prefs[KEY_ALERTS] = AlertRules.encode(updated)
        }
    }

    suspend fun restoreDefaultAlertRules() {
        store.edit { it.remove(KEY_ALERTS) }
    }

    suspend fun setImperialUnits(imperial: Boolean) {
        store.edit { it[KEY_IMPERIAL] = imperial }
    }

    suspend fun setTheme(theme: AppTheme) {
        store.edit { it[KEY_THEME] = theme.storageKey }
    }

    /** Replaces the profile for this VIN, leaving every other car in the garage alone. */
    suspend fun saveVehicle(kind: SessionKind, vehicle: Vehicle) {
        val key = vehicleKey(kind)
        store.edit { prefs ->
            prefs[key] = Garage.encode(Garage.merge(Garage.decode(prefs[key]), vehicle))
        }
    }

    /**
     * Records that these codes were present just now.
     *
     * [previouslyPresent] comes from the previous read of the same session, so a code that
     * has merely stayed stored does not inflate its own occurrence count.
     */
    suspend fun recordDtcSightings(
        kind: SessionKind,
        codes: Collection<String>,
        previouslyPresent: Set<String>,
        nowMillis: Long,
    ) {
        if (codes.isEmpty()) return
        val key = dtcKey(kind)
        store.edit { prefs ->
            prefs[key] = DtcLog.recordInto(prefs[key], codes, previouslyPresent, nowMillis)
        }
    }

    /** Stores one reading of the on-board monitors against the car it came from. */
    suspend fun recordMonitorSnapshot(kind: SessionKind, snapshot: MonitorSnapshot) {
        if (snapshot.isEmpty || snapshot.vin.isBlank()) return
        val key = monitorKey(kind)
        store.edit { prefs -> prefs[key] = MonitorLog.recordInto(prefs[key], snapshot) }
    }

    /**
     * Remembers what one probe established, for one car.
     *
     * Verdicts that could change are dropped by [ExtendedSupport.remember] rather than
     * filtered here, so there is one place that decides what "known" means.
     */
    suspend fun rememberExtendedProbe(
        kind: SessionKind,
        vin: String,
        id: String,
        probe: ExtendedProbe,
    ) {
        if (!ExtendedSupport.isDurable(probe)) return
        val key = extendedKey(kind)
        store.edit { prefs ->
            val known = ExtendedSupport.decode(prefs[key])
            prefs[key] = ExtendedSupport.encode(ExtendedSupport.remember(known, vin, id, probe))
        }
    }

    private companion object {
        fun dtcKey(kind: SessionKind): Preferences.Key<String> =
            stringPreferencesKey(DtcLog.storageKey(kind))

        fun vehicleKey(kind: SessionKind): Preferences.Key<String> =
            stringPreferencesKey(Garage.storageKey(kind))

        fun monitorKey(kind: SessionKind): Preferences.Key<String> =
            stringPreferencesKey(MonitorLog.storageKey(kind))

        fun extendedKey(kind: SessionKind): Preferences.Key<String> =
            stringPreferencesKey(ExtendedSupport.storageKey(kind))

        val KEY_ADAPTER_ADDRESS = stringPreferencesKey("adapter_address")
        val KEY_ADAPTER_NAME = stringPreferencesKey("adapter_name")
        val KEY_ADAPTER_CLASSIC = booleanPreferencesKey("adapter_classic")
        val KEY_TILES = stringPreferencesKey("tiles")
        val KEY_CHART_METRICS = stringPreferencesKey("chart_metrics")
        val KEY_CAR_ZONES = stringPreferencesKey("car_zones")
        val KEY_POLLING_ENABLED = booleanPreferencesKey("polling_enabled")
        val KEY_REDLINE = intPreferencesKey("redline_rpm")
        val KEY_ALERTS = stringPreferencesKey("alert_rules")
        val KEY_IMPERIAL = booleanPreferencesKey("imperial_units")
        val KEY_THEME = stringPreferencesKey("theme")

        const val SEPARATOR = "|"

        fun encodeMetrics(metrics: List<MetricId>): String =
            metrics.joinToString(SEPARATOR) { it.storageKey }

        fun decodeMetrics(raw: String): List<MetricId> =
            raw.split(SEPARATOR).mapNotNull(MetricId::parse).distinct()
    }
}
